

g++ NdmParserMain.cpp -o novadm


