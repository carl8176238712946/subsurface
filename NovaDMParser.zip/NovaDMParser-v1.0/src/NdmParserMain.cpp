// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#include "NdmParser.h"
#include "Ndm2CSV.h"
#include "Ndm2ASP.h"
#include "NdmReader.h"


static int VERSION = 1;
static int VERSION_LOWER = 0;



///


class NdmMainOptions
{
public:
    
    NdmMainOptions()
    {
        write_asp = false;
        write_csv = false;
        print_to_console = false;
        write = false;
        verbose = false;
        stats = false;
    }
    
    bool isOption(std::string s)
    {
        return
            s.size() > 2
        &&  s[0] == '-'
        &&  s[1] == '-'
        ;
    }
    
    bool parseOption(std::string s)
    {
        if(s.compare("--asp") == 0)
        {
            write_asp = true;
            write = true;
            return true;
        }
        
        if(s.compare("--csv") == 0)
        {
            write_csv = true;
            write = true;
            return true;
        }

        if(s.compare("--print") == 0)
        {
            print_to_console = true;
            return true;
        }

        if(s.compare("--verbose") == 0)
        {
            verbose = true;
            return true;
        }

        if(s.compare("--stats") == 0)
        {
            stats = true;
            return true;
        }

        return false;

    }
    
    bool write;
    bool write_asp;
    bool write_csv;
    bool print_to_console;
    bool verbose;
    bool stats;
    
};

void display_usage()
{
    std::cout << std::endl;
    std::cout << "NovaDM Action Tree Parser" << std::endl;
    std::cout << "Version " << VERSION << "." << VERSION_LOWER << std::endl;
    std::cout << std::endl;
    std::cout << "Usage: " << std::endl;
    std::cout << "  novadm <options> <input-file> <output-file>" << std::endl;
    std::cout << std::endl;
    std::cout << "Options: " << std::endl;
    std::cout << "  --asp      Generate ASP NovaDM files." << std::endl;
    std::cout << "  --csv      Generate CSV NovaDM files." << std::endl;
    std::cout << "  --print    Print parsed action tree to the console." << std::endl;
    std::cout << "  --verbose  Display debugging messages during parsing." << std::endl;
    std::cout << "  --stats    Display renovation alterenative statistics." << std::endl;
    std::cout << std::endl;
    
}

int main(int argc, char* argv[])
{
    std::cout << "Options: " << argc << std::endl;
    
    NdmMainOptions opt;
    
    if(argc == 1)
    {
        display_usage();
        return 0;
    }
 
    //- collect options
    int i=1;
    for(; i<argc; ++i)
    {
        std::string s(argv[i]);
        if(opt.isOption(s))
        {
            if(!opt.parseOption(s))
            {
                std::cerr << "Unrecognised option '" << s << "'" << std::endl;
                display_usage();
                return 0;
            }
        } else {
            break;
        }
        
    }
    
//    std::cout << "Index after options: " << i << std::endl;
    
    if(!opt.write && (argc <= i))
    {
        std::cerr << "Expecting <input-filename> after options (please run 'rdm-parser' for usage)." << std::endl;
        return 0;
    }

    
    if(opt.write && (argc <= i + 1))
    {
        std::cerr << "Expecting <input-filename> <output-filename> after options (please run 'rdm-parser' for usage)." << std::endl;
        return 0;
    }
    
    //- input file
    std::string infile(argv[i]);

    //- output file
    std::string outfile(opt.write ? argv[i+1] : "");
    
    
    ///////
    

    if(opt.verbose)
        std::cout << "\nReading file " << infile << "..." << std::endl;

    NdmReader r;
    if(!r.readFile(infile))
    {
        return 0;
    }
    if(opt.verbose)
        std::cout << "Done!" << std::endl;

    if(opt.print_to_console)
    {
        if(opt.verbose)
            std::cout << "\nPrinting to console..." << std::endl;

        NdmWriter w;
        
        ///
        
        for(int i=0; i<r.trees_.size(); ++i)
        {
            std::cout << "\nTree " << i << ": " << std::endl;
            w.write(*(r.trees_[i]));
        }
    }
    
    ///
    
    if(opt.write || opt.stats)
    {
        
        std::vector<NdmFileWriter*> writers;
        
        if(opt.write_asp)
        {
            std::stringstream ss;
            ss << outfile;
            ss << ".lp";
            NdmFileWriter* w = new Ndm2ASP(ss.str());
            writers.push_back(w);
        }

        
        if(opt.write_csv)
        {
            std::stringstream ss;
            ss << outfile;
            ss << ".csv";
            NdmFileWriter* w = new Ndm2CSV(ss.str());
            writers.push_back(w);
        }

        NdmStats stats;
        
        size_t tree_cnt = 0;
        
        for(int i=0; i<r.trees_.size(); ++i)
        {
            if(opt.verbose)
                std::cout << "\nAction-Value Map Walker for tree " << i << ": " << std::endl;
            
            ActionValueMapLeafHandler avm;
//            std::stringstream ss;
//            ss << "r";
//            ss << i;
            avm.parse(*(r.trees_[i]), tree_cnt);
            tree_cnt = avm.last_tree_id_ + 1;
            
            if(opt.verbose)
                avm.print();
            
            if(opt.stats)
                stats.updateStats(avm);
            
            for(int j=0; j<writers.size(); ++j)
            {
                writers[j]->write(avm);
            }
            
//            std::cout << "\nWriting ASP ... ";
//            r2asp.write(avm);
//            std::cout << "Done!" << std::endl;
            
        }
        
        for(int j=0; j<writers.size(); ++j)
        {
            writers[j]->close();
        }
        
        if(opt.stats)
            stats.printStats();


    }
        //r2asp.close();
    
    return 0;
}