// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}

#ifndef RDM2ASP_H_98764532745
#define RDM2ASP_H_98764532745

#include "NdmParser.h"

class Ndm2ASP : public NdmFileWriter
{
public:
    
    
    //- Format:
    //- e.g.: raction(alternative("r1"), action(1;2;3;4;5;6), property(subject), type(building_component), value(window)).
    
    Ndm2ASP(std::string fn):
    NdmFileWriter(fn)
    {}
    
    virtual void write(ActionValueMapLeafHandler& h)
    {
        for(std::map<size_t, std::map<NdmPropertyValue*, std::vector<size_t> > >::iterator outerit = h.tree_action_value_m_.begin();
            outerit != h.tree_action_value_m_.end(); ++outerit)
        {
            
            for(std::map<NdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
                it != outerit->second.end(); ++it)
            {
                NdmPropertyValue* v = it->first;
                
                std::stringstream c;
                if(v->pcat_ == NdmPropertyType::Subject) c << "subject";
                else if(v->pcat_ == NdmPropertyType::Feature) c << "feature";
                else if(v->pcat_ == NdmPropertyType::Criterion) c << "criterion";
                else if(v->pcat_ == NdmPropertyType::Approach) c << "approach";
                
                out_ << "raction(";
                
                //- renovation alternative name
                out_ << "alternative(\"";
//                out_ << h.rname_;
                out_ << "r" << outerit->first;
                out_ << "\"),";
                
                //- actions
                out_ << "action(";
                std::vector<size_t>& vs = it->second;
                for(int i=0; i<vs.size(); ++i)
                {
                    if(i>0) out_ << ";";
                    out_ << vs[i];
                }
                out_ << "),";
                
                //- category
                out_ << "property(";
                out_ << c.str();
                out_ << "),";
                
                if(v->pcat_ != NdmPropertyType::Criterion)
                {
                    //- type
                    out_ << "type(";
                    out_ <<  v->ptype_;
                    out_ << "),";
                }
                
                //- value
                out_ << "value(";
                out_ <<  v->pvalue_;
                out_ << ")).";
                
                //- end of row
                out_ << std::endl;
                
            }
        }
    }
    


};

#endif