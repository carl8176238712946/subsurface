

#ifndef RDMPARSER_H_76318543451823764
#define RDMPARSER_H_76318543451823764

#include <vector>
#include <iostream>
#include <sstream>
#include <map>
#include <fstream>

//////////////////////////////
// RdmFactory

template <class T> class RdmFactory
{
public:
    
    RdmFactory():
    next_(0)
    {}
    
    ~RdmFactory()
    {
        //        std::cout << "Deleting factory" << std::endl;
        typedef typename std::vector<T*>::iterator TListItr;
        for(TListItr it = store_.begin(); it != store_.end(); ++it)
        {
            delete (*it);
        }
    }
    
    void clear()
    {
        next_ = 0;
    }
    
    T* getFresh()
    {
        
        //        std::cout << "GET FRESH size=" << store_.size() << ", next_=" << next_ << std::endl;
        if(store_.size() == next_)
        {
            T* t = new T();
            store_.push_back(t);
            next_++;
            
            //            std::cout << " returning new " << t << std::endl;
            
            return t;
        }
        
        T* t = store_[next_];
        t->clear();
        next_ ++;
        
        //        std::cout << " returning old " << t << std::endl;
        
        return t;
        
    }
    
    size_t getNextIndex() {return next_;}
    
private:
    
    size_t next_;
    
    std::vector<T*> store_;
    
    //TList store_;
};


//////////////////////////////
// RdmPropertyType

class RdmPropertyType
{
public:
    enum Category
    {
        Undefined,
        Subject,
        Approach,
        Feature,
        Criterion
    };
    
    std::string name_;
    Category category_;
    std::vector<std::string> values_;
};


//////////////////////////////
// RdmPropertyValue


class RdmPropertyValue
{
public:
    
    void clear()
    {
        pcat_ = RdmPropertyType::Undefined;
        ptype_ = "(undefined type)";
        pvalue_ = "(undefined value)";
    }
    
    RdmPropertyType::Category pcat_;
    std::string ptype_;
    std::string pvalue_;
};


//////////////////////////////
// RdmNode


class RdmNode
{
public:
    
    enum NodeType
    {
        Xor,
        And,
        Tree
    };
    
    RdmNode():
    type_(Xor)
    {}
    
    ~RdmNode()
    {
        clear();
    }
    
    void clear()
    {
        children_.clear();
        values_.clear();
        type_ = Xor;
    }
    
    /////
    
    void addChild(RdmNode& n) {children_.push_back(&n);}
    size_t childrenCount() {return children_.size();}
    RdmNode* child(size_t i) {return children_[i];}
    
    /////
    
    void addValue(RdmPropertyValue& v) {values_.push_back(&v);}
    size_t valueCount() {return values_.size();}
    RdmPropertyValue* value(size_t i) {return values_[i];}
    
    /////
    
    void setType(NodeType t) {type_=t;}
    NodeType getType() {return type_;}
    
    /////
    
//    void setParent(RdmNode* n) {parent_ = n;}
//    RdmNode* getParent() {return parent_;}
    
private:
    
    std::vector<RdmNode*> children_;  //- no ownership
    std::vector<RdmPropertyValue*> values_;
    NodeType type_;
//    RdmNode* parent_;
    
};


//////////////////////////////
// RdmActionMap


//class RdmAction
//{
//public:
//    std::string rname_;
//    std::vector<std::string> ractions_;
//    RdmPropertyValue* pvalue_;
//};




//class RdmValueActionMap
//{
//    //- maps property values to actions
//    
//    std::map<RdmPropertyValue*, >
//};

class RdmPropertyCollector
{
public:
    
    RdmPropertyCollector():
    tree_id_(0)
    {}

    void pushValues(RdmNode& n)
    {
        for(int i=0; i<n.valueCount(); ++i)
        {
            values_.push_back(n.value(i));
        }
    }
    
    void popValues(RdmNode& n)
    {
        for(int i=0; i<n.valueCount(); ++i)
        {
            values_.pop_back();
        }
    }

    ///
    
    void pushValues(RdmPropertyCollector& n)
    {
        for(int i=0; i<n.values_.size(); ++i)
        {
            values_.push_back(n.values_[i]);
        }
    }
    
    void popValues(RdmPropertyCollector& n)
    {
        for(int i=0; i<n.values_.size(); ++i)
        {
            values_.pop_back();
        }
    }

    ///
    
    void clear()
    {
        values_.clear();
        tree_id_ = 0;
    }
    
    std::vector<RdmPropertyValue*> values_;
    
    size_t tree_id_;
    
};

////

class RdmLeafHandler
{
public:
    virtual void handleLeaf(RdmPropertyCollector& vs) = 0;
};

class RdmTreeWalker : public RdmLeafHandler
{
public:
    //- found complete action when:
    //-   - at a leaf node, and
    //-   - no more "And" children
    
    
    //- create a new walker for each "And" node
    
    void setLeafHandler(RdmLeafHandler& l) {leaf_handler_ = &l;}
    
//    void setNode(RdmNode& n) {node_ = &n;}
    
    void walk()
    {
        walk(*start_node_);
    }
    
    void walk(RdmNode& n)
    {
        values_.pushValues(n);
        
        if(n.childrenCount() == 0)
        {
            //- case: leaf
            leaf_handler_->handleLeaf(values_);

            
            
            ////////////////////////////////////////
        } else if(n.getType() == RdmNode::Xor)
        {
            //- case: Xor node
            for(int i=0; i<n.childrenCount(); ++i)
            {
                walk(*(n.child(i)));
          
            }

            ////////////////////////////////////////
        } else if(n.getType() == RdmNode::And)
        {
            //- case: And node
            
            for(int i=0; i<n.childrenCount(); ++i)
            {
                RdmTreeWalker* w = fcWalkers_.getFresh();
                w->setLeafHandler(*this);
                w->start_node_ = n.child(i);
                and_walkers_.push_back(w);
                
            }
            
            current_and_walker_ = 0;
            
            and_walkers_[current_and_walker_]->walk();
            
            and_walkers_.clear();
            fcWalkers_.clear();
            
            
            ////////////////////////////////////////
        } else if(n.getType() == RdmNode::Tree)
        {
            //- case: Tree node - every child starts a new tree
            
            
            for(int i=0; i<n.childrenCount(); ++i)
            {
                values_.tree_id_++;
                walk(*(n.child(i)));
                
            }
            
//            values_.tree_id_--;
        }

            
            
//            for(int i=0; i<n.childrenCount(); ++i)
//            {
//                RdmTreeWalker* w = fcWalkers_.getFresh();
//                w->setLeafHandler(*this);
//                w->start_node_ = n.child(i);
//                and_walkers_.push_back(w);
//                
//            }
//            
//            current_and_walker_ = 0;
//            
//            and_walkers_[current_and_walker_]->walk();
//            
//            and_walkers_.clear();
        
        
        
        values_.popValues(n);
        
    }
    
    virtual void handleLeaf(RdmPropertyCollector& vs)
    {
        
        values_.pushValues(vs);
        values_.tree_id_ += vs.tree_id_;

        current_and_walker_ ++;
        
        if(current_and_walker_ >= and_walkers_.size())
        {
            leaf_handler_->handleLeaf(values_);
        } else
        {
            RdmTreeWalker* w = and_walkers_[current_and_walker_];
           // w->reset();
            w->walk();
        }

        current_and_walker_--;
        
        values_.tree_id_ -= vs.tree_id_;
        values_.popValues(vs);

    }
    
    
    void clear()
    {
        reset();
        leaf_handler_ = NULL;
        start_node_ = NULL;
        tree_count_ = 0;
    }
    
    void reset()
    {
        values_.clear();
        fcWalkers_.clear();
        and_walkers_.clear();
        current_and_walker_ = 0;
    }
    
    RdmPropertyCollector values_;
    RdmLeafHandler* leaf_handler_;
    
    RdmNode* start_node_;
    
    RdmFactory<RdmTreeWalker> fcWalkers_;
    std::vector<RdmTreeWalker*> and_walkers_;
    size_t current_and_walker_;
    
    size_t tree_count_;
    
};





//////////////////////////////
// RdmTreeBuilder


class RdmTreeBuilder
{
public:
    
    void clear()
    {
        fcRdmNode_.clear();
        fcRdmPropertyValue_.clear();
    }
    
    RdmNode*            getFreshNode()              {return (RdmNode*)          fcRdmNode_.getFresh();    }
    RdmPropertyValue*   getFreshPropertyValue()     {return (RdmPropertyValue*) fcRdmPropertyValue_.getFresh();    }

    void addPropertyValue(RdmNode* n, RdmPropertyType::Category c, std::string ptyp, std::string pval)
    {
        RdmPropertyValue* v = getFreshPropertyValue();
        v->pcat_ = c;
        v->ptype_ = ptyp;
        v->pvalue_ = pval;
        
        n->addValue(*v);
    }
    
    

    
private:
    RdmFactory<RdmNode>             fcRdmNode_;
    RdmFactory<RdmPropertyValue>    fcRdmPropertyValue_;
};


//////////////////////////////
// RdmWriter

class RdmWriter
{
public:
    
    RdmWriter():
    out_(std::cout)
    {
        indent_marker_ = " ";
        indent_ = 0;
//        out_ = std::cout;
    }
    
    void write(RdmNode& n)
    {
        indent_ = 0;
        write_(&n);
        out_.flush();
    }

    
private:
    
    
    void write_(RdmPropertyValue* v)
    {
        std::stringstream c;
        if(v->pcat_ == RdmPropertyType::Subject) c << "subject";
        else if(v->pcat_ == RdmPropertyType::Feature) c << "feature";
        else if(v->pcat_ == RdmPropertyType::Approach) c << "approach";
        else if(v->pcat_ == RdmPropertyType::Criterion) c << "criterion";
        
        if(v->pcat_ == RdmPropertyType::Criterion || v->pcat_ == RdmPropertyType::Approach)
        {
//            out_ << c.str() << "=" << v->pvalue_;
            out_ << c.str() << ":" << v->pvalue_;
        } else
        {
            out_ << c.str() << ":" << v->ptype_ << "=" << v->pvalue_;
        }
    }
    
    void write_(RdmNode* n)
    {
        std::stringstream ss;
        makeIndent(ss);
//        out_->operator<<(ss.str().c_str());
//        out_->operator<<("- ");
//        out_->operator<<(std::endl);

        out_ << ss.str();

        //- write node type
        if(n->getType() == RdmNode::Xor) out_ << "- ";
        else if(n->getType() == RdmNode::And) out_ << "+ ";
        else if(n->getType() == RdmNode::Tree) out_ << "* ";
        else out_ << "(unrecognised node type) ";
        
        //- write values
        
        out_ << "[";
        for(int i=0; i<n->valueCount(); ++i)
        {
            if(i>0) out_ << ", ";
            write_(n->value(i));
        }

        out_ << "]";
        out_ << std::endl;

        //- write children
        
        indent_++;
        for(int i=0; i<n->childrenCount(); ++i)
        {
            write_(n->child(i));
        }
        indent_--;
    }
    
    void makeIndent(std::stringstream& ss)
    {
        for(int i=0; i<indent_; ++i)
        {
//            ss->operator<<(indent_marker_.c_str());
            ss << indent_marker_;
        }
    }

    size_t indent_;
    std::string indent_marker_;
    
    std::ostream& out_;
    

};


//////////////////////////////
// PrinterLeafHandler

class PrinterLeafHandler : public RdmLeafHandler
{
public:
    PrinterLeafHandler()
    {
        walker_.setLeafHandler(*this);
    }
    
    void parse(RdmNode& n, std::string nm)
    {
        std::cout << "Renovation Alternative: " << nm << std::endl;
        
        action_count_ = 0;
        rname_ = nm;
        walker_.walk(n);
    }
    
    virtual void handleLeaf(RdmPropertyCollector& vs)
    {
        action_count_ ++;

        std::cout << "\n  Action: " << action_count_ << std::endl;

        for(int i=0; i<vs.values_.size(); ++i)
        {
            RdmPropertyValue* v = vs.values_[i];
            
            std::stringstream c;
            if(v->pcat_ == RdmPropertyType::Subject) c << "subject";
            else if(v->pcat_ == RdmPropertyType::Feature) c << "feature";
            else if(v->pcat_ == RdmPropertyType::Approach) c << "approach";
            else if(v->pcat_ == RdmPropertyType::Criterion) c << "criterion";

            if((v->pcat_ == RdmPropertyType::Criterion) || (v->pcat_ == RdmPropertyType::Approach))
            {
                std::cout << "  " << c.str() << ":" << v->pvalue_ << std::endl;
                
            }
            else
            {
                std::cout << "  " << c.str() << ":" << v->ptype_ << "=" << v->pvalue_ << std::endl;
            }
        }
    }

    RdmTreeWalker walker_;
    std::string rname_;
    size_t action_count_;
    
//    RdmPropertyType::Category pcat_;
//    std::string ptype_;
//    std::string pvalue_;

};


//////////////////////////////
// ActionValueMapLeafHandler


class ActionValueMapLeafHandler : public RdmLeafHandler
{
public:
    ActionValueMapLeafHandler()
    {
        walker_.setLeafHandler(*this);
    }
    
//    void parse(RdmNode& n, std::string nm)
    void parse(RdmNode& n, size_t tree_count)
    {
        //std::cout << "Renovation Alternative: " << nm << std::endl;
        
        //action_count_ = 0;
        tree_action_count_.clear();
        start_tree_count_ = tree_count;
//        rname_ = nm;
        walker_.walk(n);
    }
    
    virtual void handleLeaf(RdmPropertyCollector& vs)
    {
        size_t tree_id = start_tree_count_ + vs.tree_id_;
        
        last_tree_id_ = std::max(last_tree_id_, tree_id);
        
        if(tree_action_count_.find(tree_id) == tree_action_count_.end()) tree_action_count_[tree_id] = 0;
        tree_action_count_[tree_id]++;
        
//        action_count_ ++;
        
        //std::cout << "\n  Action: " << action_count_ << std::endl;
        
        for(int i=0; i<vs.values_.size(); ++i)
        {
            RdmPropertyValue* v = vs.values_[i];
            
            tree_action_value_m_[tree_id][v].push_back(tree_action_count_[tree_id]);
            
        }
    }
    
    void print()
    {
        for(std::map<size_t, std::map<RdmPropertyValue*, std::vector<size_t> > >::iterator outerit = tree_action_value_m_.begin();
            outerit != tree_action_value_m_.end(); ++outerit)
        {
            
            std::cout << "Renovation Alternative " << outerit->first << ":" << std::endl;
            
            for(std::map<RdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
                it != outerit->second.end(); ++it)
            {
                RdmPropertyValue* v = it->first;
                
                std::stringstream c;
                if(v->pcat_ == RdmPropertyType::Subject) c << "subject";
                else if(v->pcat_ == RdmPropertyType::Feature) c << "feature";
                else if(v->pcat_ == RdmPropertyType::Approach) c << "approach";
                else if(v->pcat_ == RdmPropertyType::Criterion) c << "criterion";
                
                if((v->pcat_ == RdmPropertyType::Criterion) || (v->pcat_ == RdmPropertyType::Approach))
                {
                    std::cout << "  " << c.str() << ":" << v->pvalue_ << "[";
                } else
                {
                    std::cout << "  " << c.str() << ":" << v->ptype_ << "=" << v->pvalue_ << "[";
                }
                
                std::vector<size_t>& vs = it->second;
                
                for(int i=0; i<vs.size(); ++i)
                {
                    if(i>0) std::cout << ", ";
                    std::cout << vs[i];
                }
                
                std::cout << "]" << std::endl;
                
            }
        }
    }

    std::map<size_t, std::map<RdmPropertyValue*, std::vector<size_t> > > tree_action_value_m_;

    RdmTreeWalker walker_;
//    std::string rname_;
//    size_t tree_count_;
    
    size_t start_tree_count_;
    size_t last_tree_id_;

    std::map<size_t, size_t> tree_action_count_;
//    size_t action_count_;
    
};


//////////////////////////////
// RdmStats

class RdmStats
{
public:
    
    class StatItem
    {
    public:
        size_t s_actions_;
        
        size_t s_subjects_;
        size_t s_feature_;
        size_t s_approaches_;
        size_t s_criteria_;
        
        size_t id_;
        
        void clear()
        {
            s_actions_  = 0;
            
            s_subjects_  = 0;
            s_feature_  = 0;
            s_approaches_  = 0;
            s_criteria_  = 0;
            
            id_ = 0;
        }
    };
    

    RdmStats()
    {
        clear();
    }
    
//    void setActionValueMap(ActionValueMapLeafHandler& avm) {h_ = &avm;}
    
    void clear()
    {
//        s_trees_  = 0;
        stat_item_.clear();
        items_.clear();
        fcStatItems_.clear();

//        s_actions_  = 0;
//        
//        s_subjects_  = 0;
//        s_feature_  = 0;
//        s_approaches_  = 0;
//        s_criteria_  = 0;
    }
    
    void printStats()
    {
        std::vector<std::string> lbls;
        lbls.push_back("Alt");
        lbls.push_back("   Actions");
        lbls.push_back(" Subjects");
        lbls.push_back(" Approaches");
        lbls.push_back(" Features");
        lbls.push_back(" Criteria");
        
        std::vector<size_t> lbl_sz;
        for(int i=0; i<lbls.size(); ++i)
        {
            lbl_sz.push_back(lbls[i].size());
        }

        std::cout << std::endl;
        std::cout << "=========================" << std::endl;
        std::cout << "Statistics:" << std::endl;
        std::cout << "  Alternatives: " << items_.size() << std::endl;
        std::cout << "  Actions:      " << stat_item_.s_actions_ << std::endl;
        std::cout << std::endl;
        std::cout << "  Subjects:   " << stat_item_.s_subjects_ << std::endl;
        std::cout << "  Approaches: " << stat_item_.s_approaches_ << std::endl;
        std::cout << "  Features:   " << stat_item_.s_feature_ << std::endl;
        std::cout << "  Criteria:   " << stat_item_.s_criteria_ << std::endl;
        std::cout << "=========================" << std::endl;
        std::cout << std::endl;
        std::cout << "-------------------------------------------" << std::endl;
        for(int i=0; i<lbls.size(); ++i)
        {
            //if(i > 0) std::cout << " ";
            std::cout << lbls[i];
        }
        std::cout << std::endl;
        std::cout << "-------------------------------------------" << std::endl;
        std::cout << std::endl;
        for(int i=0; i<items_.size(); ++i)
        {
            StatItem* si = items_[i];
            std::cout << right_align(si->id_, lbl_sz[0]);
            std::cout << right_align(si->s_actions_, lbl_sz[1]);

            std::cout << right_align(si->s_subjects_, lbl_sz[2]);
            std::cout << right_align(si->s_approaches_, lbl_sz[3]);
            std::cout << right_align(si->s_feature_, lbl_sz[4]);
            std::cout << right_align(si->s_criteria_, lbl_sz[5]);
            
            std::cout << std::endl;
        }
        std::cout << "-------------------------------------------" << std::endl;

        
    }
    
    std::string right_align(size_t s, size_t len)
    {
        std::stringstream ss;
        ss.width(len);
        ss.fill(' ');
        ss << s;
        return ss.str();
    }
    
//    ActionValueMapLeafHandler* h_; //- no ownership
    
    void updateStats(ActionValueMapLeafHandler& h)
    {
        
        for(std::map<size_t, std::map<RdmPropertyValue*, std::vector<size_t> > >::iterator outerit = h.tree_action_value_m_.begin();
            outerit != h.tree_action_value_m_.end(); ++outerit)
        {
            
//            s_trees_++;
            
            StatItem* si = fcStatItems_.getFresh();
            items_.push_back(si);

            si->id_ = outerit->first;
            si->s_actions_ = h.tree_action_count_[outerit->first];
            
            
            for(std::map<RdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
                it != outerit->second.end(); ++it)
            {
                RdmPropertyValue* v = it->first;
                
                if(v->pcat_ == RdmPropertyType::Subject)   si->s_subjects_++;
                else if(v->pcat_ == RdmPropertyType::Feature)   si->s_feature_++;
                else if(v->pcat_ == RdmPropertyType::Approach)  si->s_approaches_++;
                else if(v->pcat_ == RdmPropertyType::Criterion) si->s_criteria_++;
            }
            
            stat_item_.s_actions_    += si->s_actions_;
            stat_item_.s_subjects_   += si->s_subjects_;
            stat_item_.s_feature_    += si->s_feature_;
            stat_item_.s_approaches_ += si->s_approaches_;
            stat_item_.s_criteria_   += si->s_criteria_;

//            stat_item_.s_actions_ += h.tree_action_count_[outerit->first];
//            
//            
//            for(std::map<RdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
//                it != outerit->second.end(); ++it)
//            {
//                RdmPropertyValue* v = it->first;
//                
//                if(v->pcat_ == RdmPropertyType::Subject)   stat_item_.s_subjects_++;
//                else if(v->pcat_ == RdmPropertyType::Feature)   stat_item_.s_feature_++;
//                else if(v->pcat_ == RdmPropertyType::Approach)  stat_item_.s_approaches_++;
//                else if(v->pcat_ == RdmPropertyType::Criterion) stat_item_.s_criteria_++;
//            }
        }
        
    }

    
    
    //- stats
    
//    size_t s_trees_;
    
    StatItem stat_item_;
    
    RdmFactory<StatItem> fcStatItems_;
    std::vector<StatItem*> items_;

//    size_t s_actions_;
//    
//    size_t s_subjects_;
//    size_t s_feature_;
//    size_t s_approaches_;
//    size_t s_criteria_;
    
    
    
};




//////////////////////////////
// RdmFileWriter


class RdmFileWriter
{
public:
    RdmFileWriter(std::string fn):
    out_(fn.c_str())
    {}
    
    void close() {out_.close();}
    
    virtual void write(ActionValueMapLeafHandler& h) = 0;
    
    std::ofstream out_;
};


#endif