

g++ RDMParserMain.cpp -o rdm-parser

