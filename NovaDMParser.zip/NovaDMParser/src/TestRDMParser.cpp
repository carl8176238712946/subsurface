

#include "RDMParser.h"
#include "Rdm2CSV.h"
#include "Rdm2ASP.h"
#include "RDMReader.h"


void test_node1()
{
    std::cout << "\n\n TEST: test_node1 \n\n";
    
    // - [subject:building_component=window]
    //  + [feature:material=plastic]
    RdmNode n1;
    RdmNode n2;
    n1.addChild(n2);
    
    n2.setType(RdmNode::And);
    
    ////
    
    RdmPropertyValue v1;
    v1.pcat_ = RdmPropertyType::Subject;
    v1.ptype_ = "building_component";
    v1.pvalue_ = "window";

    RdmPropertyValue v2;
    v2.pcat_ = RdmPropertyType::Criterion;
    v2.ptype_ = "";
    v2.pvalue_ = "indoor_comfort";

    RdmPropertyValue v3;
    v3.pcat_ = RdmPropertyType::Feature;
    v3.ptype_ = "material";
    v3.pvalue_ = "plastic";

    n1.addValue(v1);
    n1.addValue(v2);
    n2.addValue(v3);

    
    ////
    
    RdmWriter w;
    w.write(n1);
    
    
    
}


void test_walker1()
{
    std::cout << "\n\n TEST: test_walker1 \n\n";

    // - [subject:building_component=window]
    //  - [feature:material=plastic]
    //    - [feature:glazing=double]
    //  - [feature:material=wood]
    RdmNode n1;
    RdmNode n2;
    RdmNode n2b;
    RdmNode n3;
    n1.addChild(n2);
    n1.addChild(n3);
    n2.addChild(n2b);
    
//    n2.setType(RdmNode::And);
    
    ////
    
    RdmPropertyValue v1;
    v1.pcat_ = RdmPropertyType::Subject;
    v1.ptype_ = "building_component";
    v1.pvalue_ = "window";
    
    RdmPropertyValue v2;
    v2.pcat_ = RdmPropertyType::Criterion;
    v2.ptype_ = "";
    v2.pvalue_ = "indoor_comfort";
    
    RdmPropertyValue v3;
    v3.pcat_ = RdmPropertyType::Feature;
    v3.ptype_ = "material";
    v3.pvalue_ = "plastic";

    RdmPropertyValue v4;
    v4.pcat_ = RdmPropertyType::Feature;
    v4.ptype_ = "material";
    v4.pvalue_ = "wood";

    RdmPropertyValue v5;
    v5.pcat_ = RdmPropertyType::Feature;
    v5.ptype_ = "glazing";
    v5.pvalue_ = "double";

    n1.addValue(v1);
    n1.addValue(v2);
    n2.addValue(v3);
    n3.addValue(v4);
    n2b.addValue(v5);
    
    
    ////
    
    std::cout << "\nTree: " << std::endl;
    RdmWriter w;
    w.write(n1);

    ////
    
    std::cout << "\nWalker: " << std::endl;
    PrinterLeafHandler l;
    l.parse(n1, "r1");
    
    
}


///


void test_walker2()
{
    
    std::cout << "\n\n TEST: test_walker2 \n\n";

    // + [subject:building_component=window]
    //  -
    //    - [feature:material=plastic]
    //    - [feature:material=wood]
    //  -
    //    - [feature:glazing=double]
    //    - [feature:glazing=triple]
    
    
    RdmTreeBuilder tb;
    
    RdmNode* n1 = tb.getFreshNode();
    n1->setType(RdmNode::And);

    RdmNode* n2a = tb.getFreshNode();
    RdmNode* n2b = tb.getFreshNode();
    
    RdmNode* n2a1 = tb.getFreshNode();
    RdmNode* n2a2 = tb.getFreshNode();

    RdmNode* n2b1 = tb.getFreshNode();
    RdmNode* n2b2 = tb.getFreshNode();

    ///
    
    n1->addChild(*n2a);
    n1->addChild(*n2b);

    n2a->addChild(*n2a1);
    n2a->addChild(*n2a2);

    n2b->addChild(*n2b1);
    n2b->addChild(*n2b2);

    ///
    
    tb.addPropertyValue(n1,  RdmPropertyType::Subject, "building_component", "window");

    tb.addPropertyValue(n2a1, RdmPropertyType::Feature, "material", "plastic");
    tb.addPropertyValue(n2a2, RdmPropertyType::Feature, "material", "wood");

    tb.addPropertyValue(n2b1, RdmPropertyType::Feature, "glazing", "double");
    tb.addPropertyValue(n2b2, RdmPropertyType::Feature, "glazing", "triple");
    
    ////
    
    std::cout << "\nTree: " << std::endl;
    RdmWriter w;
    w.write(*n1);
    
    ////
    
    std::cout << "\nWalker: " << std::endl;
    PrinterLeafHandler l;
    l.parse(*n1, "r1");
    
    ////
    
    std::cout << "\nAction-Value Map Walker: " << std::endl;
    ActionValueMapLeafHandler avm;
    avm.parse(*n1, "r1");
    avm.print();
    
    ////
    
    std::cout << "\nWriting CSV ... ";
    Rdm2CSV r2csv("rdm_test.csv");
    r2csv.write(avm);
    r2csv.close();
    std::cout << "Done!" << std::endl;

    ////
    
    std::cout << "\nWriting ASP ... ";
    Rdm2ASP r2asp("rdm_test.lp");
    r2asp.write(avm);
    r2asp.close();
    std::cout << "Done!" << std::endl;

}

///

void test_rdm_reader1()
{
    RdmReader r;
    r.readFile("tree1.rdm");
    
    RdmWriter w;

    ///
    
    for(int i=0; i<r.trees_.size(); ++i)
    {
        std::cout << "\nTree " << i << ": " << std::endl;
        w.write(*(r.trees_[i]));
    }
    
    ///
    
    Rdm2ASP r2asp("rdm_test2.lp");

    for(int i=0; i<r.trees_.size(); ++i)
    {
        std::cout << "\nAction-Value Map Walker for tree " << i << ": " << std::endl;
        ActionValueMapLeafHandler avm;
        std::stringstream ss;
        ss << "r";
        ss << i;
        avm.parse(*(r.trees_[i]), ss.str());
        avm.print();
        
        std::cout << "\nWriting ASP ... ";
        r2asp.write(avm);
        std::cout << "Done!" << std::endl;

    }
    
    r2asp.close();



}


///

int main(int argc, char* argv[])
{
    
//    test_node1();
//    test_walker1();
//    test_walker2();
    test_rdm_reader1();
    
    return 0;
}