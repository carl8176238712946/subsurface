

#include "RDMParser.h"
#include "Rdm2CSV.h"
#include "Rdm2ASP.h"
#include "RDMReader.h"


static int VERSION = 1;
static int VERSION_LOWER = 0;



///


class RdmMainOptions
{
public:
    
    RdmMainOptions()
    {
        write_asp = false;
        write_csv = false;
        print_to_console = false;
        write = false;
        verbose = false;
        stats = false;
    }
    
    bool isOption(std::string s)
    {
        return
            s.size() > 2
        &&  s[0] == '-'
        &&  s[1] == '-'
        ;
    }
    
    bool parseOption(std::string s)
    {
        if(s.compare("--asp") == 0)
        {
            write_asp = true;
            write = true;
            return true;
        }
        
        if(s.compare("--csv") == 0)
        {
            write_csv = true;
            write = true;
            return true;
        }

        if(s.compare("--print") == 0)
        {
            print_to_console = true;
            return true;
        }

        if(s.compare("--verbose") == 0)
        {
            verbose = true;
            return true;
        }

        if(s.compare("--stats") == 0)
        {
            stats = true;
            return true;
        }

        return false;

    }
    
    bool write;
    bool write_asp;
    bool write_csv;
    bool print_to_console;
    bool verbose;
    bool stats;
    
};

void display_usage()
{
    std::cout << std::endl;
    std::cout << "RDM Action Tree Parser" << std::endl;
    std::cout << "Version " << VERSION << "." << VERSION_LOWER << std::endl;
    std::cout << std::endl;
    std::cout << "Usage: " << std::endl;
    std::cout << "  rdm-parser <options> <input-file> <output-file>" << std::endl;
    std::cout << std::endl;
    std::cout << "Options: " << std::endl;
    std::cout << "  --asp      Generate ASP RDM files." << std::endl;
    std::cout << "  --csv      Generate CSV RDM files." << std::endl;
    std::cout << "  --print    Print parsed action tree to the console." << std::endl;
    std::cout << "  --verbose  Display debugging messages during parsing." << std::endl;
    std::cout << "  --stats    Display renovation alterenative statistics." << std::endl;
    std::cout << std::endl;
    
}

int main(int argc, char* argv[])
{
    std::cout << "Options: " << argc << std::endl;
    
    RdmMainOptions opt;
    
    if(argc == 1)
    {
        display_usage();
        return 0;
    }
 
    //- collect options
    int i=1;
    for(; i<argc; ++i)
    {
        std::string s(argv[i]);
        if(opt.isOption(s))
        {
            if(!opt.parseOption(s))
            {
                std::cerr << "Unrecognised option '" << s << "'" << std::endl;
                display_usage();
                return 0;
            }
        } else {
            break;
        }
        
    }
    
//    std::cout << "Index after options: " << i << std::endl;
    
    if(!opt.write && (argc <= i))
    {
        std::cerr << "Expecting <input-filename> after options (please run 'rdm-parser' for usage)." << std::endl;
        return 0;
    }

    
    if(opt.write && (argc <= i + 1))
    {
        std::cerr << "Expecting <input-filename> <output-filename> after options (please run 'rdm-parser' for usage)." << std::endl;
        return 0;
    }
    
    //- input file
    std::string infile(argv[i]);

    //- output file
    std::string outfile(opt.write ? argv[i+1] : "");
    
    
    ///////
    

    if(opt.verbose)
        std::cout << "\nReading file " << infile << "..." << std::endl;

    RdmReader r;
    if(!r.readFile(infile))
    {
        return 0;
    }
    if(opt.verbose)
        std::cout << "Done!" << std::endl;

    if(opt.print_to_console)
    {
        if(opt.verbose)
            std::cout << "\nPrinting to console..." << std::endl;

        RdmWriter w;
        
        ///
        
        for(int i=0; i<r.trees_.size(); ++i)
        {
            std::cout << "\nTree " << i << ": " << std::endl;
            w.write(*(r.trees_[i]));
        }
    }
    
    ///
    
    if(opt.write || opt.stats)
    {
        
        std::vector<RdmFileWriter*> writers;
        
        if(opt.write_asp)
        {
            std::stringstream ss;
            ss << outfile;
            ss << ".lp";
            RdmFileWriter* w = new Rdm2ASP(ss.str());
            writers.push_back(w);
        }

        
        if(opt.write_csv)
        {
            std::stringstream ss;
            ss << outfile;
            ss << ".csv";
            RdmFileWriter* w = new Rdm2CSV(ss.str());
            writers.push_back(w);
        }

        RdmStats stats;
        
        size_t tree_cnt = 0;
        
        for(int i=0; i<r.trees_.size(); ++i)
        {
            if(opt.verbose)
                std::cout << "\nAction-Value Map Walker for tree " << i << ": " << std::endl;
            
            ActionValueMapLeafHandler avm;
//            std::stringstream ss;
//            ss << "r";
//            ss << i;
            avm.parse(*(r.trees_[i]), tree_cnt);
            tree_cnt = avm.last_tree_id_ + 1;
            
            if(opt.verbose)
                avm.print();
            
            if(opt.stats)
                stats.updateStats(avm);
            
            for(int j=0; j<writers.size(); ++j)
            {
                writers[j]->write(avm);
            }
            
//            std::cout << "\nWriting ASP ... ";
//            r2asp.write(avm);
//            std::cout << "Done!" << std::endl;
            
        }
        
        for(int j=0; j<writers.size(); ++j)
        {
            writers[j]->close();
        }
        
        if(opt.stats)
            stats.printStats();


    }
        //r2asp.close();
    
    return 0;
}