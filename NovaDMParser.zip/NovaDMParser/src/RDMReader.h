

#ifndef RDMReader_H_3874268763514827364
#define RDMReader_H_3874268763514827364

#include "RDMParser.h"

class RdmReader
{
public:
    
    
    void clear()
    {
        trees_.clear();
        tree_builder_.clear();
        //fcNode_.clear();
    }
    
    bool readFile(std::string fn)
    {
        std::ifstream infile(fn.c_str());

        if(!infile.good())
        {
            std::cerr << "Could not open file: " << fn << std::endl;
            return false;
        }
        
        
        bool parse_error = false;
        last_node_at_indent_level_.clear();
        bool reading_node = false;
        current_indent_ = 0;

        size_t line_num = 0;
        std::string line;

        bool in_block_comment = false;

//        while (std::getline(infile, line))
        while (safeGetline(infile, line))
        {
            line_num++;
            
//            std::cout << "LINE #" << line_num << ":[" << line << "]" << std::endl;

            replace_all(line, '\t', ' ');
            
            //- handle block comments
            if(in_block_comment)
            {
                size_t cmt = line.find("*%");
                if(cmt  != std::string::npos)
                {
                    line = line.substr(cmt + 2);
                    in_block_comment = false;
                }
                else
                    continue;
            }


            size_t cmtA = line.find("%*");
            size_t cmtB = line.find("*%");
            
            while(cmtA  != std::string::npos && cmtB  != std::string::npos && ((cmtA + 2) <= cmtB))
            {
                line.erase(cmtA, (cmtB + 2 - cmtA));
                cmtA = line.find("%*");
                cmtB = line.find("*%");
            }
            
//            int cmt = line.find("%*");
            if(cmtA  != std::string::npos)
            {
                line = line.substr(0,cmtA);
                in_block_comment = true;
            }

            
//
//            if(!in_block_comment)
//            {
//                int cmt = line.find("%*");
//                if(cmt  != std::string::npos)
//                {
//                    //- also handle case where block comment is only within the line
//                    int cmt2 = line.find("*%", cmt + 2);
//                    
//                    if(cmt2  != std::string::npos)
//                    {
//                        line.erase(cmt, (cmt2 + 2 - cmt));
//                    } else
//                    {
//                        line = line.substr(0,cmt);
//                        in_block_comment = true;
//                    }
//                }
//            }
//
//            
            
            
            
            //- remove substring after comment symbol
            size_t cmt = line.find('%');
            if(cmt  != std::string::npos)
                line = line.substr(0,cmt);
            
//            std::cout << "LINE #" << line_num << " (trimmed size " << trim(line).size() <<"):[" << trim(line) << "]" << std::endl;
            
            if(trim(line).size() == 0)
            {
                continue;
            }
            

            
            if(isNode(line))
            {
                reading_node = true;
                
                size_t ilvl = 0;
                
                if(!read_indent_level(line, ilvl))
                {
                    parse_fail("expected node symbol, but did not find one after the initial spaces", line_num, line);
                    parse_error = true;
                    break;
                }

                //- indent level is at most one step higher than current
                if((ilvl > current_indent_) && (ilvl - current_indent_) > 2)
                {
                    parse_fail("node indentation can only increase by one space per line", line_num, line);
                    parse_error = true;
                    break;
                }
                
                //- create node
                
                current_node_ = tree_builder_.getFreshNode();
                
                if(!read_node(line))
                {
                    parse_fail("failed to parse node properties list", line_num, line);
                    parse_error = true;
                    break;
                }

                
                //- if new indent level is zero then starting a new tree
                if(ilvl == 0)
                {
                    last_node_at_indent_level_.clear();
                    trees_.push_back(current_node_);
                } else
                {
                    //- add node to parent
                    last_node_at_indent_level_[ilvl - 1]->addChild(*current_node_);
                }

                last_node_at_indent_level_[ilvl] = current_node_;
                current_indent_ = ilvl;

                
            } else
            {
                parse_fail("Unrecognised symbols (cannot interpret as an RDM tree node)", line_num, line);
                parse_error = true;
                break;
                
            }

        }

        infile.close();

        if(parse_error)
        {
            clear();
            return false;
        }
        return true;
        
    }
    
    ////////////////////////////////////////////////////////////
    // Safe getline
    //  Adapted from:
    //  https://stackoverflow.com/questions/6089231/getting-std-ifstream-to-handle-lf-cr-and-crlf#6089413
    //  Original code by:  user763305
    ////////////////////////////////////////////////////////////
    std::istream& safeGetline(std::istream& is, std::string& t)
    {
        t.clear();
        
        // The characters in the stream are read one-by-one using a std::streambuf.
        // That is faster than reading them one-by-one using the std::istream.
        // Code that uses streambuf this way must be guarded by a sentry object.
        // The sentry object performs various tasks,
        // such as thread synchronization and updating the stream state.
        
        std::istream::sentry se(is, true);
        std::streambuf* sb = is.rdbuf();
        
        for(;;) {
            int c = sb->sbumpc();
            
            if(c == '\n') return is;
            else if(c == '\r')
            {
                if(sb->sgetc() == '\n')
                    sb->sbumpc();
                return is;
                
            } else if(c == '\r' || c == std::streambuf::traits_type::eof())
            {
                // Also handle the case when the last line has no line ending
                if(t.empty())
                    is.setstate(std::ios::eofbit);
                return is;
            }
            t += (char)c;
        }
    }
    ////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////

    
    void replace_all(std::string& s, char from, char to)
    {
        if(from == to)
        {
            std::cerr << "RDMReader error: trying to replace char with same char in string." << std::endl;
            return;
        }
        
        size_t f = s.find(from);
        while(f != std::string::npos)
        {
            s[f] = to;
            f = s.find(from);
        }
    }
    
    
//    bool removedBlockComment(std::string& line, bool in_block_comment)
//    {
////        bool did_remove = false;
//        
//        //- handle block comments
//        if(!in_block_comment)
//        {
//            int cmt = line.find("%*");
//            if(cmt  != std::string::npos)
//            {
//                std::string remainder = line.substr(cmt + 2);
//                line = line.substr(0,cmt);
//                return removedBlockComment(remainder, true);
//            }
//        }
//        
//        if(in_block_comment)
//        {
//            int cmt = line.find("*%");
//            if(cmt  != std::string::npos)
//            {
//                line = line.substr(cmt + 2);
//                return removedBlockComment(line, false);
//            }
//        }
//        
//        return in_block_comment;
//    }
    
    bool read_indent_level(std::string line, size_t& ilvl)
    {
        //- count number of empty spaces before node symbol
        for(int i=0; i<line.size(); ++i)
        {
            if(line[i] == ' ')
                continue;
            
            if(isNodeSymbol(line[i]))
            {
                ilvl = i;
                return true;
            } else
            {
                return false;
            }

        }

        return false;
    }
    
    bool isNodeSymbol(char c)
    {
        return
            (c == '-')
        ||  (c == '+')
        ||  (c == '*')
        ;
    }
    
    bool read_node(std::string line)
    {
        //- get node symbol
        char c = trim(line)[0];
        if(c == '-')
            current_node_->setType(RdmNode::Xor);
        else if(c == '+')
            current_node_->setType(RdmNode::And);
        else if(c == '*')
            current_node_->setType(RdmNode::Tree);
        else
            return false;
        
        //- parse properties
        size_t f1 = line.find('[');
        size_t f2 = line.find_last_of(']');
        
        if(f2 <= f1)
        {
            return false;
        }
        
        std::string propsStr = line.substr(f1+1,(f2 - f1) - 1);
        
//        std::cout << "PROPS: {" << propsStr << "}" << std::endl;
        
        std::vector<std::string> toks;
        tokenise(propsStr, toks, ",");
        
        //- parse each property
        for(int i=0; i<toks.size(); ++i)
        {
            std::string prop = trim(toks[i]);
            size_t pos1 = prop.find(':');
            size_t pos2 = prop.find('=');
            
            if(pos1 <= 0)
            {
                parse_property_fail("Failure before ':' symbol", i, prop);
                return false;
            }

            if(pos2 != 0 && pos2 < pos1)
            {
                parse_property_fail("Symbol '=' comes before symbol ':'", i, prop);
                return false;
            }
            
            std::string catStr = trim(prop.substr(0,pos1));
            
            RdmPropertyType::Category cat = parseCategory(catStr);
            
            if(cat == RdmPropertyType::Undefined)
            {
                parse_property_fail("Unrecognised property category", i, catStr);
                return false;
            }

            std::string typStr = "";
            std::string valStr = "";
            
            if(cat == RdmPropertyType::Criterion || cat == RdmPropertyType::Approach)
            {
                valStr = trim(prop.substr(pos1+1));
            } else
            {
                typStr = trim(prop.substr(pos1+1, (pos2 - pos1) - 1));
                valStr = trim(prop.substr(pos2+1));
                
            }
            
            //- check if value string is a disjunction of alternatives
            
            if(isDisjunctiveValueList(valStr))
            {
                size_t p1 = valStr.find('(');
                size_t p2 = valStr.find_last_of(')');
                
                if(p2 <= p1)
                {
                    parse_property_fail("Problem parsing list of disjunctive property values, brackets expected (..)", i, valStr);
                    return false;
                }
                
                std::string dvalsStr = valStr.substr(p1+1,(p2 - p1) - 1);
                
                
                std::vector<std::string> vtoks;
                tokenise(dvalsStr, vtoks, ";");

                //- parse each value
                for(int j=0; j<vtoks.size(); ++j)
                {
                    std::string dval = trim(vtoks[j]);
                    
                    RdmNode* dn = tree_builder_.getFreshNode();
                    tree_builder_.addPropertyValue(dn, cat, typStr, dval);
                    current_node_->addChild(*dn);
                    
                }

            } else
            {
                tree_builder_.addPropertyValue(current_node_, cat, typStr, valStr);
            }

            //tree_builder_.addPropertyValue(current_node_, cat, "", valStr);


            
//            if(cat == RdmPropertyType::Criterion || cat == RdmPropertyType::Approach)
//            {
//                std::string valStr = trim(prop.substr(pos1+1));
//                tree_builder_.addPropertyValue(current_node_, cat, "", valStr);
//            } else
//            {
//                std::string typStr = trim(prop.substr(pos1+1, (pos2 - pos1) - 1));
//                std::string valStr = trim(prop.substr(pos2+1));
//                tree_builder_.addPropertyValue(current_node_, cat, typStr, valStr);
//            }
            
            
        }

        
        return true;
        
    }
    
    

    RdmPropertyType::Category parseCategory(std::string s)
    {
        if((s.compare("subject") == 0) || (s.compare("s") == 0))
            return RdmPropertyType::Subject;
        else if((s.compare("feature") == 0) || (s.compare("f") == 0))
            return RdmPropertyType::Feature;
        else if((s.compare("approach") == 0) || (s.compare("a") == 0))
            return RdmPropertyType::Approach;
        else if((s.compare("criterion") == 0) || (s.compare("c") == 0))
            return RdmPropertyType::Criterion;
        else
            return RdmPropertyType::Undefined;
    }
    
    bool isDisjunctiveValueList(std::string s)
    {
        //std::string ts = trim(s);
        return trim(s)[0] == '(';
    }
    
    bool isNode(std::string line)
    {
        return isRootNode(trim(line));
    }
    
    bool isRootNode(std::string line)
    {
        return
        line.size() > 0 && isNodeSymbol(line[0]);
        
//        ((line[0] == '-') || (line[0] == '+'));
    }
    
    
    /////////////////////////////////
    /// Utils
    
    void parse_fail(std::string msg, int line_num, std::string ln)
    {
        std::cerr << "Parsing error (line " << line_num << "): " << msg << std::endl;
        std::cerr << "   \""<<ln << "\""<< std::endl;
        
    }

    void parse_property_fail(std::string msg, int property_num, std::string tok)
    {
        std::cerr << "Property parsing error (property number " << property_num << " in list): " << msg << std::endl;
        std::cerr << "   \""<<tok << "\""<< std::endl;
        
    }

    
    ////
    
    std::string trim(const std::string& str)
    {
        size_t first = str.find_first_not_of(' ');
        if (std::string::npos == first)
        {
            return "";
        }
        size_t last = str.find_last_not_of(' ');
        
//        std::cout << "TRIMMING pos: " << first << " to " << last << std::endl;
        
        return str.substr(first, (last - first + 1));
    }
    
    ////
    
    void tokenise(std::string s, std::vector<std::string>& args, std::string delim)
    {
        //- assumes at least one argument
        
        size_t f = 0;
        while((f = s.find(delim))  != std::string::npos)
        {
            std::string a = trim(s.substr(0,f));
            if(a.length() > 0) args.push_back(a);
            s = s.substr(f+1);
            
            //            std::cout << "a=[" << a << "]" << std::endl;
            //            std::cout << "t=[" << util_.trim(a) << "]" << std::endl;
            //            std::cout << "s=[" << s << "]" << std::endl;
            //            std::cout << "f=[" << f << "]" << std::endl;
        }
        
        s = trim(s);
        if(s.length() > 0)
            args.push_back(s);
        
        //s = s.substr(f+1);
        
    }

//    std::vector<RdmNode*> current_tree_nodes_;
    
    std::map<size_t, RdmNode*> last_node_at_indent_level_;
    RdmNode* current_node_;
    size_t current_indent_;
    
    std::vector<RdmNode*> trees_;
    
    RdmTreeBuilder tree_builder_;
    
//    RdmFactory<RdmNode> fcNode_;
};

#endif