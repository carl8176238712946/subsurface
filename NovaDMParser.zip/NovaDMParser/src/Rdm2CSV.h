

#ifndef RDM2CSV_H_4325418723456513
#define RDM2CSV_H_4325418723456513

#include "RDMParser.h"

class Rdm2CSV : public RdmFileWriter
{
public:
    
    
    //- Format:
    //-   <Renovation-name>, (<list-of-actions>), <property-catgory>, <property-type>, <property-value>
    
    Rdm2CSV(std::string fn):
    RdmFileWriter(fn)
    {}
    
    virtual void write(ActionValueMapLeafHandler& h)
    {

        for(std::map<size_t, std::map<RdmPropertyValue*, std::vector<size_t> > >::iterator outerit = h.tree_action_value_m_.begin();
            outerit != h.tree_action_value_m_.end(); ++outerit)
        {

            for(std::map<RdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
                it != outerit->second.end(); ++it)
            {
                RdmPropertyValue* v = it->first;
                
                std::stringstream c;
                if(v->pcat_ == RdmPropertyType::Subject) c << "subject";
                else if(v->pcat_ == RdmPropertyType::Feature) c << "feature";
                else if(v->pcat_ == RdmPropertyType::Criterion) c << "criterion";
                else if(v->pcat_ == RdmPropertyType::Approach) c << "approach";
                
                //- renovation alternative name
//                out_ << "r" << h.rname_;
                out_ << "r" << outerit->first;
                out_ << ",";
                
                //- actions
                out_ << "(";
                std::vector<size_t>& vs = it->second;
                for(int i=0; i<vs.size(); ++i)
                {
                    if(i>0) out_ << ";";
                    out_ << vs[i];
                }
                out_ << ")";
                out_ << ",";
                
                //- category
                out_ << c.str();
                out_ << ",";
                
                //- type
                out_ <<  v->ptype_;
                out_ << ",";
                
                //- value
                out_ <<  v->pvalue_;
                
                //- end of row
                out_ << std::endl;
                
            }
        }
    }
    


};

#endif