

#ifndef RDM2ASP_H_98764532745
#define RDM2ASP_H_98764532745

#include "RDMParser.h"

class Rdm2ASP : public RdmFileWriter
{
public:
    
    
    //- Format:
    //- e.g.: raction(alternative("r1"), action(1;2;3;4;5;6), property(subject), type(building_component), value(window)).
    
    Rdm2ASP(std::string fn):
    RdmFileWriter(fn)
    {}
    
    virtual void write(ActionValueMapLeafHandler& h)
    {
        for(std::map<size_t, std::map<RdmPropertyValue*, std::vector<size_t> > >::iterator outerit = h.tree_action_value_m_.begin();
            outerit != h.tree_action_value_m_.end(); ++outerit)
        {
            
            for(std::map<RdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
                it != outerit->second.end(); ++it)
            {
                RdmPropertyValue* v = it->first;
                
                std::stringstream c;
                if(v->pcat_ == RdmPropertyType::Subject) c << "subject";
                else if(v->pcat_ == RdmPropertyType::Feature) c << "feature";
                else if(v->pcat_ == RdmPropertyType::Criterion) c << "criterion";
                else if(v->pcat_ == RdmPropertyType::Approach) c << "approach";
                
                out_ << "raction(";
                
                //- renovation alternative name
                out_ << "alternative(\"";
//                out_ << h.rname_;
                out_ << "r" << outerit->first;
                out_ << "\"),";
                
                //- actions
                out_ << "action(";
                std::vector<size_t>& vs = it->second;
                for(int i=0; i<vs.size(); ++i)
                {
                    if(i>0) out_ << ";";
                    out_ << vs[i];
                }
                out_ << "),";
                
                //- category
                out_ << "property(";
                out_ << c.str();
                out_ << "),";
                
                if(v->pcat_ != RdmPropertyType::Criterion)
                {
                    //- type
                    out_ << "type(";
                    out_ <<  v->ptype_;
                    out_ << "),";
                }
                
                //- value
                out_ << "value(";
                out_ <<  v->pvalue_;
                out_ << ")).";
                
                //- end of row
                out_ << std::endl;
                
            }
        }
    }
    


};

#endif