#!/bin/bash
../clingo -W none test_data/T2_n_10_m_20_k_10.lp 0 >> test_results/results_T2_n_10_m_20_k_10.txt
../clingo -W none test_data/T2_n_10_m_20_k_20.lp 0 >> test_results/results_T2_n_10_m_20_k_20.txt
../clingo -W none test_data/T2_n_10_m_20_k_30.lp 0 >> test_results/results_T2_n_10_m_20_k_30.txt
../clingo -W none test_data/T2_n_10_m_20_k_40.lp 0 >> test_results/results_T2_n_10_m_20_k_40.txt
../clingo -W none test_data/T2_n_10_m_20_k_50.lp 0 >> test_results/results_T2_n_10_m_20_k_50.txt
tput bel
