

------------------------------------------
Answer Set Programming Modulo `Space-Time'
------------------------------------------

==============================
Installation / Setup
==============================

- download Clingo version 5.1 from Potasco website and place in directory:
  "ASPMT-spacetime/"
  (we've included the binary for MacOS)

  https://potassco.org/clingo/

- install GPC wrapper for Python, run:
  "pip install Polygon2" (for Python version 2.*)
  "pip install Polygon3" (for Python version 3.*)

- you may also need standard packages "numpy" and "scipy" if they are not already installed.

==============================
Case Study: Fly Bowl Application
==============================

To run the examples:

cd ASPMT-spacetime/fly_bowl_application

../clingo fly_example_1.lp
../clingo fly_example_2.lp
../clingo fly_example_3.lp


==============================
Case Study: Cell Application
==============================

To run the examples:

cd ASPMT-spacetime/cell_application

../clingo cell_example_1.lp
../clingo cell_example_2.lp


==============================
Empirical Evaluation
==============================

We've included empirical evaluation tests T1-T4. Each test Ti (i=1,2,3,4) has a directory and corresponding files:

- test_data: ASP programs
- test_results: results for our experiments
- Ti_test_config.lp: configuration file used by all tests
- run_Ti.sh: script to run tests



