#!/bin/bash
echo ":: 0 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_1.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 1 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_2.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 2 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_0_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 1 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_2.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 2 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_1_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 2 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_2_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 3 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_3_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 4 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_4_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 5 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_5_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 6 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_6_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 7 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_7_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 8 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_8_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 9 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_9_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 10 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_10_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 11 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_11_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 12 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_12_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 13 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_13_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 14 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_14_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 15 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_15_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 16 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_16_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 17 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_17_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 18 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_18_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 19 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_19_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 20 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_20_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 21 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_21_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 22 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_22_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 23 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_23_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 24 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_24_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 25 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_25_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 26 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_26_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 27 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_27_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 28 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_28_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 29 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_29_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 30 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_30_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 31 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_31_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_31_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_31_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_31_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_31_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_31_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_31_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_31_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 32 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_32_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_32_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_32_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_32_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_32_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_32_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_32_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 33 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_33_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_33_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_33_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_33_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_33_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_33_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 34 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_34_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_34_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_34_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_34_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_34_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 35 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_35_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_35_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_35_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_35_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 36 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_36_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_36_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_36_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 37 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_37_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_37_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 38 of 40"
../clingo -W none test_data/T1_n_40_m_10_pairwise_38_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_10.txt
echo " -- 39 of 40"
echo ":: 39 of 40"
echo ":: 0 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_1.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 1 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_2.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 2 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_0_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 1 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_2.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 2 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_1_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 2 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_2_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 3 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_3_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 4 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_4_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 5 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_5_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 6 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_6_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 7 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_7_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 8 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_8_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 9 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_9_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 10 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_10_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 11 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_11_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 12 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_12_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 13 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_13_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 14 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_14_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 15 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_15_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 16 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_16_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 17 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_17_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 18 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_18_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 19 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_19_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 20 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_20_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 21 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_21_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 22 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_22_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 23 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_23_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 24 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_24_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 25 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_25_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 26 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_26_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 27 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_27_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 28 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_28_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 29 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_29_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 30 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_30_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 31 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_31_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_31_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_31_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_31_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_31_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_31_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_31_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_31_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 32 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_32_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_32_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_32_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_32_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_32_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_32_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_32_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 33 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_33_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_33_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_33_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_33_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_33_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_33_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 34 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_34_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_34_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_34_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_34_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_34_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 35 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_35_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_35_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_35_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_35_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 36 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_36_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_36_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_36_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 37 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_37_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_37_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 38 of 40"
../clingo -W none test_data/T1_n_40_m_20_pairwise_38_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_20.txt
echo " -- 39 of 40"
echo ":: 39 of 40"
echo ":: 0 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_1.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 1 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_2.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 2 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_0_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 1 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_2.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 2 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_1_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 2 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_2_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 3 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_3_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 4 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_4_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 5 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_5_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 6 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_6_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 7 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_7_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 8 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_8_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 9 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_9_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 10 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_10_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 11 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_11_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 12 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_12_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 13 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_13_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 14 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_14_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 15 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_15_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 16 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_16_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 17 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_17_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 18 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_18_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 19 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_19_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 20 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_20_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 21 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_21_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 22 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_22_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 23 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_23_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 24 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_24_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 25 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_25_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 26 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_26_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 27 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_27_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 28 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_28_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 29 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_29_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 30 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_30_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 31 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_31_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_31_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_31_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_31_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_31_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_31_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_31_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_31_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 32 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_32_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_32_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_32_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_32_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_32_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_32_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_32_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 33 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_33_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_33_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_33_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_33_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_33_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_33_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 34 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_34_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_34_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_34_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_34_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_34_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 35 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_35_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_35_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_35_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_35_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 36 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_36_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_36_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_36_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 37 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_37_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_37_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 38 of 40"
../clingo -W none test_data/T1_n_40_m_30_pairwise_38_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_30.txt
echo " -- 39 of 40"
echo ":: 39 of 40"
echo ":: 0 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_1.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 1 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_2.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 2 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_0_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 1 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_2.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 2 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_1_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 2 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_3.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 3 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_2_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 3 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_4.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 4 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_3_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 4 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_5.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 5 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_4_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 5 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_6.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 6 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_5_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 6 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_7.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 7 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_6_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 7 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_8.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_7_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 8 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_9.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_8_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 9 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_10.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_9_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 10 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_11.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_10_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 11 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_12.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_11_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 12 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_13.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_12_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 13 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_14.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_13_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 14 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_15.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_14_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 15 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_16.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_15_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 16 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_17.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_16_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 17 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_18.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_17_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 18 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_19.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_18_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 19 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_20.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_19_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 20 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_21.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_20_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 21 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_22.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_21_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 22 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_23.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_22_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 23 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_24.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_23_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 24 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_25.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_24_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 25 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_26.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_25_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 26 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_27.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_26_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 27 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_28.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_27_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 28 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_29.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_28_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 29 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_30.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_29_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 30 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_31.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_30_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 31 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_31_32.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_31_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_31_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_31_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_31_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_31_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_31_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_31_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 32 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_32_33.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_32_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_32_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_32_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_32_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_32_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_32_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 33 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_33_34.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_33_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_33_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_33_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_33_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_33_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 34 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_34_35.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_34_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_34_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_34_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_34_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 35 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_35_36.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_35_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_35_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_35_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 36 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_36_37.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_36_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_36_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 37 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_37_38.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_37_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 38 of 40"
../clingo -W none test_data/T1_n_40_m_40_pairwise_38_39.lp 0 >> test_results/results_pairwise_T1_n_40_m_40.txt
echo " -- 39 of 40"
echo ":: 39 of 40"
tput bel
