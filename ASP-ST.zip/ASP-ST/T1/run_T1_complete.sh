#!/bin/bash
echo ":: 0 of 9"
../clingo -W none test_data/T1_n_40_m_10_complete_0.lp 0 >> test_results/results_complete_T1_n_40_m_10.txt
echo ":: 1 of 9"
../clingo -W none test_data/T1_n_40_m_10_complete_1.lp 0 >> test_results/results_complete_T1_n_40_m_10.txt
echo ":: 2 of 9"
../clingo -W none test_data/T1_n_40_m_10_complete_2.lp 0 >> test_results/results_complete_T1_n_40_m_10.txt
echo ":: 3 of 9"
../clingo -W none test_data/T1_n_40_m_10_complete_3.lp 0 >> test_results/results_complete_T1_n_40_m_10.txt
echo ":: 4 of 9"
../clingo -W none test_data/T1_n_40_m_10_complete_4.lp 0 >> test_results/results_complete_T1_n_40_m_10.txt
echo ":: 0 of 19"
../clingo -W none test_data/T1_n_40_m_20_complete_0.lp 0 >> test_results/results_complete_T1_n_40_m_20.txt
echo ":: 1 of 19"
../clingo -W none test_data/T1_n_40_m_20_complete_1.lp 0 >> test_results/results_complete_T1_n_40_m_20.txt
echo ":: 2 of 19"
../clingo -W none test_data/T1_n_40_m_20_complete_2.lp 0 >> test_results/results_complete_T1_n_40_m_20.txt
echo ":: 3 of 19"
../clingo -W none test_data/T1_n_40_m_20_complete_3.lp 0 >> test_results/results_complete_T1_n_40_m_20.txt
echo ":: 4 of 19"
../clingo -W none test_data/T1_n_40_m_20_complete_4.lp 0 >> test_results/results_complete_T1_n_40_m_20.txt
echo ":: 0 of 29"
../clingo -W none test_data/T1_n_40_m_30_complete_0.lp 0 >> test_results/results_complete_T1_n_40_m_30.txt
echo ":: 1 of 29"
../clingo -W none test_data/T1_n_40_m_30_complete_1.lp 0 >> test_results/results_complete_T1_n_40_m_30.txt
echo ":: 2 of 29"
../clingo -W none test_data/T1_n_40_m_30_complete_2.lp 0 >> test_results/results_complete_T1_n_40_m_30.txt
echo ":: 3 of 29"
../clingo -W none test_data/T1_n_40_m_30_complete_3.lp 0 >> test_results/results_complete_T1_n_40_m_30.txt
echo ":: 4 of 29"
../clingo -W none test_data/T1_n_40_m_30_complete_4.lp 0 >> test_results/results_complete_T1_n_40_m_30.txt
echo ":: 0 of 39"
../clingo -W none test_data/T1_n_40_m_40_complete_0.lp 0 >> test_results/results_complete_T1_n_40_m_40.txt
echo ":: 1 of 39"
../clingo -W none test_data/T1_n_40_m_40_complete_1.lp 0 >> test_results/results_complete_T1_n_40_m_40.txt
echo ":: 2 of 39"
../clingo -W none test_data/T1_n_40_m_40_complete_2.lp 0 >> test_results/results_complete_T1_n_40_m_40.txt
echo ":: 3 of 39"
../clingo -W none test_data/T1_n_40_m_40_complete_3.lp 0 >> test_results/results_complete_T1_n_40_m_40.txt
echo ":: 4 of 39"
../clingo -W none test_data/T1_n_40_m_40_complete_4.lp 0 >> test_results/results_complete_T1_n_40_m_40.txt
tput bel
