

-------
1. Parse the action tree:
-------

COMMAND:
novadm Test.ndm Tree.lp

-------
2. Create the ASP query file:
-------

I've made three examples, you only run ONE query at a time:

Query1.lp: select one root node from each tree

Query2.lp: typology: door must have sliding mechanism and wood material

Query3.lp: two different typologies, each scenario must only have either typology 1 or typology 2

-------
3. Run clingo, put output in file 
-------

COMMAND:
clingo 3 Tree.lp NovaDMAsp3.lp Query1.lp attr_Test.lp &> ASPOutput.txt

NOTE: please double check the "pipe" command: "&>", it's different on Windows and Mac and I forget the Windows version...

NOTE: I assume we have the attributes, currently they're in the file:
attr_Test.lp

NOTE: this stops after 3 models (i.e. 3 scenarios).


-------
4. Run NoveDM to parse ASP output to a more readable format
-------

COMMAND:
novadm --asp-parse-models ASPOutput.txt ASPOutputParse.txt

-------

Have a look at "ASPOutputParse.txt" to see the final format. Note that "t0", "t1" etc. are tree IDs, so you can use them to determine which features and attributes belong to which subjects.

Cheers
Carl





