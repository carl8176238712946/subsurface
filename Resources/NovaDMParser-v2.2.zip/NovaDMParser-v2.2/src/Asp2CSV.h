// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#ifndef Asp2CSV_H_62573716253
#define Asp2CSV_H_62573716253


#include "NdmReader.h"

#include <cstdlib>

class Asp2CSV : FileReader
{
public:
    
    size_t model_count_;
    
    
    Asp2CSV() :
    model_count_(0)
    {}
    
    

    
    ///////////
    bool parseModels(std::string fn, std::string outf, bool opt_only)
    {
        
        model_count_ = 0;
        
        std::ifstream infile;
        
        if(!openFile(fn, infile))
        {
            return false;
        }
        
        NdmFileWriter fout(outf);
        
        std::string line;
        
        //- clingo starts to enumerate optimal models when the model count goes back to 1
        bool found_first_optimal_model = false;

        std::string test_string = "Answer:";
        size_t model_num = 0;
        
        while (safeGetline(infile, line))
        {
            //size_t pos = line.find(test_string);
            
//            std::cout << line << " (" << pos << ")" << std::endl;
//            std::cout << "Pos:" << pos << std::endl;
            
//            if(pos != std::string::npos)
            if(startsWith(line,test_string))
            {
                model_num++;
                
                if(opt_only && !found_first_optimal_model)
                {
                    //- grab the stated model number
                    size_t pos = line.find(test_string);
                    std::string given_model_num_str = line.substr(pos + test_string.size());
                    int given_model_num = strtod(given_model_num_str.c_str(), NULL);
                    
                    if(given_model_num < model_num)
                    {
                        //- found first optimal model
                        found_first_optimal_model = true;
                        model_num = 1;
                    } else
                    {
                        continue;
                    }
                }
                
                //std::cout << "SCENARIO " << model_num << std::endl;
                
//                fout.writespc("SCENARIO");
//                fout.writespc(model_num);
//                fout.nl();

                safeGetline(infile, line);
                
                parseModel(line, fout);
                
                fout.nl();
            }
            
        }
        
        fout.close();

        return true;
    }
    
    void parseModel(std::string m, NdmFileWriter& fout)
    {
//        std::cout << "Line: " << m << std::endl;

        std::vector<std::string> args;
        tokenise(m, args, ") ");

//        std::cout << "Tokens: " << m << std::endl;

        for(int i=0; i < args.size(); i++)
        {
//            std::string s = trim(args[i]);
            
            std::string s = args[i];
            
//            std::cout << "#" << i << ":[" << s << "]" << std::endl;

            if(s[s.size()-1] == ')')
                s = s.substr(0,s.size()-1);


//            std::cout << ">>#" << i << ":[" << s << "]" << std::endl;

            parseProperty(s, fout);

//            parseProperty(args[i]);
            
        }
        
//        tokenise(std::string s, std::vector<std::string>& args, std::string delim)
    }
    
    void parseProperty(std::string s, NdmFileWriter& fout)
    {
        size_t pos = s.find("(");
        
        if(pos == std::string::npos)
            return;
        
        s = s.substr(pos + 1);
        
        std::vector<std::string> args;
        tokenise(s, args, ",");
        
        for(int i=0; i < args.size(); i++)
        {
            fout.writespc(args[i]);
        }

        fout.nl();
    }
    
    
private:
};

#endif
