// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}

#ifndef RDM2ASP_H_98764532745
#define RDM2ASP_H_98764532745

#include "NdmWriter.h"

class Ndm2ASP : public NdmFileWriter
{
public:

    Ndm2ASP(std::string fn):
    NdmFileWriter(fn)
    {}
    
    /////
    
//    void reset()
//    {
//        tree_ = 0;
//        indent_ = 0;
//
//    }
    
    virtual void write(NdmReader& r)
    {
//        reset();
        
        
        for(int i=0; i<r.trees_.size(); ++i)
        {
//            tree_++;
            
            //std::cout << "\nTree " << i << ": " << std::endl;
            write(i, *(r.trees_[i]));
        }
    };
    
    void write(size_t t, NdmNode& n)
    {
        
//        std::stringstream ss;
//        ss << "tree("
        
        std::vector<size_t> pth;
        write_(t, &n, pth);
        out_.flush();
    }
    
    void write(std::vector<NdmAttributeAspectValue*>& attrs)
    {
        
        // attribute(type("price"), feature("door_mechanism"), value("hinges"), attribute_value(10)).
        
        for(int i=0; i < attrs.size(); i++)
        {
            NdmAttributeAspectValue* a = attrs[i];
            
            std::stringstream ss;
            ss << "attribute(";

            ss << "type(\"";
            ss << a->attr_name_;
            ss << "\"),";
            
            if(a->prop_.pcat_ == NdmPropertyType::Subject) ss << "subject(\"";
            else if(a->prop_.pcat_ == NdmPropertyType::Feature) ss << "feature(\"";
            else if(a->prop_.pcat_ == NdmPropertyType::Approach) ss << "approach(\"";
            else ss << "aspect(\"";
            
            ss << a->prop_.ptype_;
            ss << "\"),";
            
            ss << "value(\"";
            ss << a->prop_.pvalue_;
            ss << "\"),";

            ss << "attribute_value(";
            ss << a->attr_value_;
            ss << ")).";
            
            out_ << ss.str();
            out_ << std::endl;
        }
        
        out_.flush();

    }
    

private:
//    size_ tree_;
//    size_ indent_;


    
    std::string write_(size_t tree, NdmNode* n, std::vector<size_t>& nodePath)
    {
        
        // format:
        //      tree(node(n1), aspect(subject), type(building_component), value(window)).
        //      node_type(n1, and).
        //      parent(n1, n1_1).


        
        //makeIndent(ss);
        //        out_->operator<<(ss.str().c_str());
        //        out_->operator<<("- ");
        //        out_->operator<<(std::endl);
        //out_ << ss.str();
        
        
        std::string nd = makeNodeName(tree, nodePath);
        
        //- write node type
        std::stringstream ss;
        ss << "node_type(";
        ss << nd;
        ss << ",";
        
        if(n->getType() == NdmNode::Xor) ss << "xor";
        else if(n->getType() == NdmNode::And) ss << "and";
//        else if(n->getType() == NdmNode::Tree) ss << "* ";
        else ss << "\"(unrecognised node type)\"";
        
        ss << ").\n";
        
        out_ << ss.str();
        
        //- write values
        
//        out_ << "[";
        for(int i=0; i<n->valueCount(); ++i)
        {
//            if(i>0) out_ << ", ";
            write_(nd, n->value(i));
        }
        
//        out_ << "]";
//        out_ << std::endl;
        
        //- write children
        
//        indent_++;
        for(int i=0; i<n->childrenCount(); ++i)
        {
            nodePath.push_back(i);
            std::string chd = write_(tree, n->child(i), nodePath);
            nodePath.pop_back();
            
            std::stringstream ss2;
            ss2 << "parent(";
            ss2 << nd;
            ss2 << ",";
            ss2 << chd;
            ss2 << ").\n";
            
            out_ << ss2.str();
        }
        
        if(nodePath.size() == 0)
        {
            std::stringstream ss3;
            ss3 << "root_node(";
            ss3 << nd;
            ss3 << ").\n";
            
            out_ << ss3.str();
        }
        
        //- write node tree
        std::stringstream ss4;
        ss4 << "tree(t";
        ss4 << tree;
        ss4 << ",";
        ss4 << nd;
        ss4 << ").\n";
        out_ << ss4.str();

        
        return nd;
    }

    ///////////////
    void write_(std::string nd, NdmPropertyValue* v)
    {
        // format: subject(n0, "building_component","window").

        
        std::stringstream c;

//        c << "tree(node(";
//        c << nd;
//        c << "), aspect(";
        
        if(v->pcat_ == NdmPropertyType::Subject) c << "subject";
        else if(v->pcat_ == NdmPropertyType::Feature) c << "feature";
        else if(v->pcat_ == NdmPropertyType::Approach) c << "approach";
        else if(v->pcat_ == NdmPropertyType::Criterion) c << "criterion";
        
        c << "(";
        c << nd;
        c << ",";
        
        if(v->pcat_ == NdmPropertyType::Criterion || v->pcat_ == NdmPropertyType::Approach)
        {
            //            out_ << c.str() << "=" << v->pvalue_;
            //out_ << c.str() << ":" << v->pvalue_;
            
            c << "\"";
            c << v->pvalue_;
            c << "\").\n";
            
        } else
        {
            //out_ << c.str() << ":" << v->ptype_ << "=" << v->pvalue_;

            c << "\"";
            c << v->ptype_;

            c << "\",\"";
            c << v->pvalue_;
            c << "\").\n";

        }
        
        out_ << c.str();
    }
    
    ///////////////
    std::string makeNodeName(size_t tree, std::vector<size_t>& nodePath)
    {
        std::stringstream ss;
        ss << "t" << tree;
        ss << "_n0";
        
        for(int i=0; i < nodePath.size(); i++)
        {
            ss << "_n" << nodePath[i];
        }
        
        return ss.str();
    }
    
    
};

#endif