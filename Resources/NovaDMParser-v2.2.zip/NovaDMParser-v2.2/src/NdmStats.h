// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}

#ifndef NDM_STATS_H_1235712653
#define NDM_STATS_H_1235712653

#include "NdmReader.h"
#include <boost/multiprecision/cpp_dec_float.hpp>
//////////

class NormalFormConverter
{
public:

  void to_normal_form(NdmNode* n)
  {
    for(int i=0; i < n->childrenCount(); ++i)
    {
      to_normal_form(n->child(i));
    }

    for(int i=0; i < n->childrenCount(); ++i)
    {
      NdmNode* n2 = n->child(i);
      if(n->getType() == n2->getType())
      { //- merge nodes
        merge_node(n,n2);
        n->removeChild(i);
        n2->clear();
        i--;
      }
    }

  }

  void merge_node(NdmNode* n1, NdmNode* n2)
  { //- merge n2 into n1
    for(int i=0; i < n2->childrenCount(); ++i)
    {
      n1->addChild( *(n2->child(i)) );
    }

    for(int i=0; i < n2->valueCount(); ++i)
    {
      n1->addValue( *(n2->value(i)) );
    }
    
  }

  NdmNode* merge_trees(NdmReader& r)
  {
        //- create single root AND node
        NdmNode* root = builder_.getFreshNode();
        root->setType(NdmNode::And);
        //r.trees_.push_back(root);

        for(int i=0; i < r.trees_.size(); i++)
        {
          NdmNode* m = r.trees_[i];
          //- create option that tree is not (necessarily) selected
          //- by constructing intermediate Xor node with empty child node
          NdmNode* t1 = builder_.getFreshNode();
          t1->setType(NdmNode::Xor);
          NdmNode* t2 = builder_.getFreshNode();
          t1->addChild(*m);
          t1->addChild(*t2);
          root->addChild(*t1);
        }

        return root;
  }

private:

  NdmTreeBuilder builder_;


};


//////////

/*
class Component
{
public:
  void set(int v) //, int idnum)
  {
    v_ = v;
  }

  int v_;  //- number of configurations in the component
  //int id_; //- unique component id
  
  void clear()
  {
    v_ = 0;
    //id_ = 0;
  }
};
class ComponentArray
{
public:

  void addComponent(Component* c)
  {
    components_.push_back(c);
  }

  void clear()
  {
    components_.clear();
  }

private:
  std::vector<Component*> components_;
};


*/

class ComponentArray
{
public:

  ComponentArray():
    min_v(0),
    max_v(0),
    sum_v(0)
  {}

  void addComponent(int v)
  {
    components_.push_back(v);
  }

  void append(ComponentArray* arr2)
  {
    for(int i=0; i < arr2->size(); ++i)
    {
      components_.push_back(arr2->component(i));
    }
  }

  int size() {return components_.size();}
  int component(int i) {return components_[i];}

  void clear()
  {
    components_.clear();
    min_v = 0;
    max_v = 0;
    sum_v = 0;
  }

  std::string toString()
  {
    std::stringstream ss;
    ss << "[";
    for(int i=0; i < components_.size(); ++i)
    {
      if(i > 0) ss << ",";
      ss << components_[i];
    }
    ss << "]";
    return ss.str();
  }

  void update_stats()
  {
    for(int i=0; i < components_.size(); ++i)
    {
      int v = components_[i];
      if(i == 0)
      {
       min_v = v;
       max_v = v;
       sum_v = v;
      } else
      {
       min_v = std::min(v,min_v);
       max_v = std::max(v,max_v);
       sum_v += v;
      }
    }
  }

  int min_v;
  int max_v;
  int sum_v;


private:
  std::vector<int> components_;
};


class ComponentArraySet
{
public:

   ComponentArraySet():
    m(0),
    min_k(0),
    max_k(0),
    sum_k(0),
    mean_k(0),
    min_v(0),
    max_v(0),
    sum_v(0),
    mean_v(0)
  {}

  int size() {return component_arrays_.size();}
  ComponentArray* array(int i) {return component_arrays_[i];}

  void addComponentArray(ComponentArray* ca)
  {
    component_arrays_.push_back(ca);
  }

  void sumArraySet(ComponentArraySet* arrset2)
  {
    for(int i=0; i < arrset2->size(); ++i)
    {
      addComponentArray(arrset2->array(i));
    }
  }

  void joinArraySet(ComponentArraySet* arrset2, NdmFactory<ComponentArray>& fcArr)
  {
    //- append every array from arrset2 to every array in this set

    std::vector<ComponentArray*> new_ca;

    for(int i=0; i < component_arrays_.size(); ++i)
    {
     ComponentArray* ca1 = component_arrays_[i];
     for(int j=0; j < arrset2->size(); ++j)
     {
      ComponentArray* ca2 = arrset2->array(j);
      //ca->append(arrset2->array(j));

      ComponentArray* ca12 = fcArr.getFresh();
      ca12->append(ca1);
      ca12->append(ca2);

      new_ca.push_back(ca12);
     }
    }

    component_arrays_.clear();
    for(int i=0; i < new_ca.size(); ++i)
    {
      component_arrays_.push_back(new_ca[i]);
    }
  }
  
  std::string toString()
  {
    std::stringstream ss;
    ss  << "ComponentArraySet {" << std::endl;
    for(int i=0; i < component_arrays_.size(); ++i)
    {
      ss << component_arrays_[i]->toString();
      if(i < component_arrays_.size() - 1) ss << ",";
      ss << std::endl;
    }
    ss << "}" << std::endl;
    return ss.str();
  }

  void clear()
  {
    component_arrays_.clear();

    m = 0;

    min_k = 0;
    max_k = 0;
    sum_k = 0;
    mean_k = 0;

    min_v = 0;
    max_v = 0;
    sum_v = 0;
    mean_v = 0;

  }

  void update_stats()
  {
    m = component_arrays_.size();

    for(int i=0; i < component_arrays_.size(); ++i)
    {
      ComponentArray* ca = component_arrays_[i];
      ca->update_stats();
      
      int k = ca->size();

      if(i == 0)
      {
        min_k = k;
        max_k = k;
        sum_k = k;

        min_v = ca->min_v;
        max_v = ca->max_v;
        sum_v = ca->sum_v;
      } else 
      {
        min_k = std::min(k, min_k);
        max_k = std::max(k, max_k);
        sum_k += k;

        min_v = std::min(ca->min_v, min_v);
        max_v = std::max(ca->max_v, max_v);
        sum_v += ca->sum_v;
      }
    }

    mean_k = ((double)sum_k) / ((double) component_arrays_.size());
    mean_v = ((double)sum_v) / ((double) sum_k);
  }

  int m;

  int min_k;
  int max_k;
  int sum_k;
  double mean_k;

  int min_v;
  int max_v;
  int sum_v;
  double mean_v;


private:
  std::vector<ComponentArray*> component_arrays_;
};

class ComponentAnalyser
{
public:

  ComponentAnalyser():
  verbose_(false)
  {}

  ComponentArraySet* find_component_arrays(NdmNode* n)
  {
    ComponentArraySet* arrset = fcComponentArraySet_.getFresh();

    //if(n->getType() == NdmNode::Xor)
    //{
      //- create component
      int leaf_nds = leaf_node_count(n);
      if(leaf_nds > 0)
      {
        ComponentArray* carr = fcComponentArray_.getFresh();
        carr->addComponent(leaf_nds);
        arrset->addComponentArray(carr);
      }
    //}

    for(int i=0; i < n->childrenCount(); ++i)
    {
      NdmNode* n2 = n->child(i);
      if(!leaf_node(n2))
      {
        ComponentArraySet* arrset2 = find_component_arrays(n2);
        if(n->getType() == NdmNode::Xor)
        {
          arrset->sumArraySet(arrset2);
        } else if(n->getType() == NdmNode::And)
        {
          if(i == 0 && arrset->size() == 0)
          {
            arrset->sumArraySet(arrset2);
          } else
          {
            arrset->joinArraySet(arrset2, fcComponentArray_);
          }
        }
      }
    }

    //- for debugging
    if(verbose_)
    {
     std::cout << n->toString() << std::endl;
     std::cout << arrset->toString();
    }
    ////

    return arrset;

  }
  
  int leaf_node_count(NdmNode* n)
  {
    int leaf_nds = 0;
    for(int i=0; i < n->childrenCount(); ++i)
    {
      if(leaf_node(n->child(i)))
        leaf_nds++;
    }
    return leaf_nds;
  }

  bool leaf_node(NdmNode* n) {return n->childrenCount() == 0;}

  void setVerbose(bool v) {verbose_ = v;}
private:
//  std::vector<Component*> components_;

//  NdmFactory<Component>         fcComponent_;
  NdmFactory<ComponentArray>    fcComponentArray_;
  NdmFactory<ComponentArraySet> fcComponentArraySet_;

  bool verbose_;

/*
  int newComponent(int v)
  {
    Component* c = new Component(v,components_.size());
    components_.push_back(c);
    return c->id_;
  }
*/

};

//////////

class ActionTreeStats
{
public:
  int cur_node_count_;
  int cur_and_node_count_;
  int cur_xor_node_count_;
  int cur_leaf_node_count_;
  int cur_branching_xor_node_count_;

  int total_node_count_;
  int total_and_node_count_;
  int total_xor_node_count_;
  int total_leaf_node_count_;
  int total_branching_xor_node_count_;

  double mean_node_count_;
  double mean_and_node_count_;
  double mean_xor_node_count_;
  double mean_leaf_node_count_;
  double mean_branching_xor_node_count_;

  ActionTreeStats()
  {
    reset();
  }

  void reset()
  {
   cur_node_count_                = 0;
   cur_and_node_count_            = 0;
   cur_xor_node_count_            = 0;
   cur_leaf_node_count_           = 0;
   cur_branching_xor_node_count_  = 0;

   total_node_count_               = 0;
   total_and_node_count_           = 0;
   total_xor_node_count_           = 0;
   total_leaf_node_count_          = 0;
   total_branching_xor_node_count_ = 0;

   mean_node_count_                = 0;
   mean_and_node_count_            = 0;
   mean_xor_node_count_            = 0;
   mean_leaf_node_count_           = 0;
   mean_branching_xor_node_count_  = 0;

  }

  void record_current_and_reset()
  {
   total_node_count_               += cur_node_count_;
   total_and_node_count_           += cur_and_node_count_;
   total_xor_node_count_           += cur_xor_node_count_;
   total_leaf_node_count_          += cur_leaf_node_count_;
   total_branching_xor_node_count_ += cur_branching_xor_node_count_;

   cur_node_count_                = 0;
   cur_and_node_count_            = 0;
   cur_xor_node_count_            = 0;
   cur_leaf_node_count_           = 0;
   cur_branching_xor_node_count_  = 0;
  }

  void calculate_means(int k)
  {
   mean_node_count_                = total_node_count_ / ((double)k);
   mean_and_node_count_            = total_and_node_count_ / ((double)k);
   mean_xor_node_count_            = total_xor_node_count_ / ((double)k);
   mean_leaf_node_count_           = total_leaf_node_count_ / ((double)k);
   mean_branching_xor_node_count_  = total_branching_xor_node_count_ / ((double)k);
  }
  
};

//////////

class NdmStats
{
public:

    NdmStats():
    verbose_(false)
    {}
    
    /////
    
    void stats(NdmReader& r)
    {
        int gk = 0;
        int gv = 0;

        double gmv = 0;

        for(int i=0; i<r.trees_.size(); ++i)
        {
            NdmNode* n = r.trees_[i];
            int k = CAN_k(n);
            int v = CAN_v(n);

            double mk = CAN_mean_k(n);
            double mv = CAN_mean_v(n);

            std::cout << "Tree " << i
            << ": k=" << k << ", v=" << v
            << ", mean_k=" << mk << ", mean_v=" << mv
            << std::endl;
  
            gk += k;
            if(gv < v) gv = v;

            gmv += mv; 

            //write(i, *(r.trees_[i]));
        }

        gmv = gmv / r.trees_.size();

        std::cout << "\nGlobal: gk=" << gk << ", gv=" << gv
        << ", mean_gv=" << gmv << std::endl;

        ///////////////////
        std::cout << "\n===============" << std::endl;
        std::cout << "ACTION COUNT [original tree]:" << std::endl;
        std::cout << "===============" << std::endl;

        boost::multiprecision::cpp_dec_float_100 act_cnt_total = 1;

        for(int i=0; i<r.trees_.size(); ++i)
        {
            NdmNode* n = r.trees_[i];
            boost::multiprecision::cpp_dec_float_100 act_cnt = count_actions(n);

            std::cout << "\nTree " << i << ":" << std::endl;
            std::cout << " Digit representation: " 
             << std::setprecision(
                std::numeric_limits<boost::multiprecision::cpp_dec_float_100>::max_digits10)
             << std::defaultfloat
             << act_cnt << std::endl;

            std::cout << " Scientific notation:  "
             << std::setprecision(2)
             << std::scientific
             << act_cnt << std::endl;


            //std::cout << std::setprecision(
            //   std::numeric_limits<boost::multiprecision::cpp_dec_float_100>::max_digits10);
            //std::cout << std::scientific;

            //std::cout << "Tree " << i << ": Actions = "
            //<< std::scientific << act_cnt
            //<< act_cnt
            //<< std::endl;

            act_cnt_total *= (act_cnt + 1);
        }


        std::cout << "\nTotal actions:" << std::endl;
        std::cout << " Digit representation: " 
         << std::setprecision(
            std::numeric_limits<boost::multiprecision::cpp_dec_float_100>::max_digits10)
         << std::defaultfloat
         << act_cnt_total << std::endl;

        std::cout << " Scientific notation:  "
         << std::setprecision(2)
         << std::scientific
         << act_cnt_total << std::endl;

        std::cout << std::defaultfloat;

        ///////////////////
        std::cout << "\n===============" << std::endl;
        std::cout << "NODE COUNT [original tree]:" << std::endl;
        std::cout << "===============" << std::endl;

        display_count_nodes(r);

        std::cout << "\n===============" << std::endl;
        std::cout << "NODE COUNT [normal form tree]:" << std::endl;
        std::cout << "===============" << std::endl;

        NormalFormConverter nf;

        for(int i=0; i<r.trees_.size(); ++i)
        {
          nf.to_normal_form(r.trees_[i]);
        }

        display_count_nodes(r);

        if(verbose_)
        {
          std::cout << "\n===============" << std::endl;
          std::cout << "Tree in normal form:" << std::endl;
          std::cout << "===============" << std::endl;

          NdmConsoleWriter w;
          w.write(r);
        }


        //- MCA analysis
        std::cout << "\n===============" << std::endl;
        std::cout << "MCA Analysis:" << std::endl;
        std::cout << "===============" << std::endl;

        ComponentAnalyser comp_analyse;
        comp_analyse.setVerbose(verbose_);

        double mean_v2_sum = 0;
        double max_v2_sum = 0;

        int sum_m = 0;
        int prod_m = 1;

        int min_k = 0;
        double sum_mean_k = 0;
        int max_k = 0;

        int min_v = 0;
        double sum_mean_v = 0;
        int max_v = 0;



        for(int i=0; i<r.trees_.size(); ++i)
        {
          NdmNode* n = r.trees_[i];
          nf.to_normal_form(n);
          ComponentArraySet* arrset = comp_analyse.find_component_arrays(n);
          arrset->update_stats();

          std::cout << "Tree " << i << ":" << std::endl;
          std::cout << "  m = " << arrset->m << " (no. of component arrays)" << std::endl;
          std::cout << "  k (min, mean, max) = ("
              << arrset->min_k << ", "
              << arrset->mean_k << ", "
              << arrset->max_k << ") "
              << " (no. of components per array)" << std::endl;
          std::cout << "  v (min, mean, max) = ("
              << arrset->min_v << ", "
              << arrset->mean_v << ", "
              << arrset->max_v << ") "
              << " (no. of configurations per component)" << std::endl;

          mean_v2_sum += std::pow(arrset->mean_v,2);
          max_v2_sum  += std::pow(arrset->max_v,2);

          sum_m +=  arrset->m;
          prod_m *= arrset->m; 

          min_k = (i==0 ? arrset->min_k : std::min(min_k, arrset->min_k) );
          max_k = (i==0 ? arrset->max_k : std::max(max_k, arrset->max_k) );
          sum_mean_k += arrset->mean_k;

          min_v = (i==0 ? arrset->min_v : std::min(min_v, arrset->min_v) );
          max_v = (i==0 ? arrset->max_v : std::max(max_v, arrset->max_v) );
          sum_mean_v += arrset->mean_v;

        }

        std::cout << "\nSum mean v^2 = " << mean_v2_sum << std::endl;
        std::cout << "Sum max v^2  = " << max_v2_sum << std::endl;

        std::cout << "\nGlobal sum m  = " << sum_m << std::endl;
        std::cout << "\nGlobal prod m = " << prod_m << std::endl;
        std::cout << "Global k (min, mean, max) ="
          << " (" << min_k
          << ", " << (sum_mean_k / r.trees_.size())
          << ", " << max_k
          << ")"  << std::endl;
        std::cout << "Global v (min, mean, max) ="
          << " (" << min_v
          << ", " << (sum_mean_v / r.trees_.size())
          << ", " << max_v
          << ")"  << std::endl;


/*
        if(r.trees_.size() > 1)
        {
         std::cout << "\n===============" << std::endl;
         std::cout << "MCA Analysis on Merged Trees:" << std::endl;
         std::cout << "===============" << std::endl;

         NdmNode* mroot = nf.merge_trees(r);

         std::cout << "1" << std::endl;

         ComponentArraySet* arrset = comp_analyse.find_component_arrays(mroot);
         arrset->update_stats();

         std::cout << "2" << std::endl;

         std::cout << "Merged Tree:" << std::endl;
         std::cout << "  m = " << arrset->m << " (no. of component arrays)" << std::endl;
         std::cout << "  k (min, mean, max) = ("
              << arrset->min_k << ", "
              << arrset->mean_k << ", "
              << arrset->max_k << ") "
              << " (no. of components per array)" << std::endl;
         std::cout << "  v (min, mean, max) = ("
              << arrset->min_v << ", "
              << arrset->mean_v << ", "
              << arrset->max_v << ") "
              << " (no. of configurations per component)" << std::endl;
        }

*/


    };
    
   void setVerbose(bool v) {verbose_ = v;}


   ////////

   boost::multiprecision::cpp_dec_float_100 count_actions(NdmNode* n)
   {
     if(n->childrenCount() == 0)
     { //- if leaf 
       boost::multiprecision::cpp_dec_float_100 v = 1;
       return v;
     } else if(n->getType() == NdmNode::Xor)
     { //- sum of children actions

       boost::multiprecision::cpp_dec_float_100 v = 0;

       for(int i=0; i < n->childrenCount(); i++)
       {
         v += count_actions(n->child(i));
       }
       return v;
     } else 
     { //- cross product of actions

       boost::multiprecision::cpp_dec_float_100 v = 1;

       for(int i=0; i < n->childrenCount(); i++)
       {
         v *= count_actions(n->child(i));
       }
       return v;
     }
   }




private:

   bool verbose_;

   ////////
   // Count nodes

   void display_count_nodes(NdmReader& r)
   {
        ActionTreeStats ats;

        for(int i=0; i<r.trees_.size(); ++i)
        {
          count_nodes(ats, r.trees_[i]);

          std::cout << "Tree " << i << ":" << std::endl;
          std::cout << "  Nodes         = " << ats.cur_node_count_ << std::endl;
          std::cout << "  Xor Nodes     = " << ats.cur_xor_node_count_ << std::endl;
          std::cout << "  And Nodes     = " << ats.cur_and_node_count_ << std::endl;
          std::cout << "  Leaf Nodes    = " << ats.cur_leaf_node_count_ << std::endl;
          std::cout << "  Branching Xor = " << ats.cur_branching_xor_node_count_ << std::endl;

          ats.record_current_and_reset();
        }

        if(r.trees_.size() < 2)
          return;

        ats.calculate_means(r.trees_.size());

        std::cout << "===============" << std::endl;
        std::cout << "CUMULATIVE:" << std::endl;
        std::cout << "  Nodes         = " << ats.total_node_count_
                  << " (mean = " << ats.mean_node_count_ << ")" << std::endl;
        std::cout << "  Xor Nodes     = " << ats.total_xor_node_count_
                  << " (mean = " << ats.mean_xor_node_count_ << ")" << std::endl;
        std::cout << "  And Nodes     = " << ats.total_and_node_count_
                  << " (mean = " << ats.mean_and_node_count_ << ")" << std::endl;
        std::cout << "  Leaf Nodes    = " << ats.total_leaf_node_count_
                  << " (mean = " << ats.mean_leaf_node_count_ << ")" << std::endl;
        std::cout << "  Branching Xor = " << ats.total_branching_xor_node_count_
                  << " (mean = " << ats.mean_branching_xor_node_count_ << ")" << std::endl;
        std::cout << "===============" << std::endl;
   }

   void count_nodes(ActionTreeStats& ats, NdmNode* n)
   {
     ats.cur_node_count_++;

     if(n->childrenCount() == 0)
     {
       ats.cur_leaf_node_count_++;
     } else if(n->getType() == NdmNode::Xor)
     {
       ats.cur_xor_node_count_++;

       //- node is branching xor if has at least 2 branches
       //- (with at least one of those not being leaf)
       
       int leaf_nd = 0;
       for(int i=0; i < n->childrenCount(); ++i)
       {
         if(n->child(i)->childrenCount() == 0)
           leaf_nd++;
       }

       int k = n->childrenCount();

       if( (k > 1) && ((k - leaf_nd) > 0) )
         ats.cur_branching_xor_node_count_++;

     } else if(n->getType() == NdmNode::And)
     {
       ats.cur_and_node_count_++;
     }

     for(int i=0; i < n->childrenCount(); ++i)
     {
       count_nodes(ats, n->child(i));
     }
   }


   ////////

   int CAN_k(NdmNode* n)
   {
     int k=0;

     if(n->childrenCount() == 0)
     {
       //- if leaf 
       return 1;
     } else if(n->getType() == NdmNode::Xor)
     {
       for(int i=0; i < n->childrenCount(); i++)
       {
         int k_i = CAN_k(n->child(i));
         if(k < k_i) k = k_i;
       }
     } else if(n->getType() == NdmNode::And)
     {
       for(int i=0; i < n->childrenCount(); i++)
       {
         k += CAN_k(n->child(i));
       }
     }

     return k;
   }


   int CAN_v(NdmNode* n)
   {
     int v=0;

     //- if leaf 
     if(n->childrenCount() == 0)
     {
       return 1;
     } else if(n->getType() == NdmNode::Xor)
     {
       for(int i=0; i < n->childrenCount(); i++)
       {
         v += CAN_v(n->child(i));
       }
     } else if(n->getType() == NdmNode::And)
     {
       for(int i=0; i < n->childrenCount(); i++)
       {
         int v_i = CAN_v(n->child(i));
         if(v < v_i) v = v_i;
       }
     }

     return v;
   }

   //////

   double CAN_mean_k(NdmNode* n)
   {
     double k=0;

     //- if leaf 
     if(n->childrenCount() == 0)
     {
       return 1;
     } else
     {
       for(int i=0; i < n->childrenCount(); i++)
       {
         k += CAN_mean_k(n->child(i));
       }

       if(n->getType() == NdmNode::Xor)
       {
         k = (k / n->childrenCount());
       }
     }

     return k;
   }


   double CAN_mean_v(NdmNode* n)
   {
     double v=0;

     //- if leaf 
     if(n->childrenCount() == 0)
     {
       return 1;
     } else
     {
       for(int i=0; i < n->childrenCount(); i++)
       {
         v += CAN_mean_v(n->child(i));
       }

       if(n->getType() == NdmNode::And)
       {
         v = (v / n->childrenCount());
       }
     }

     return v;
   }

};

#endif

