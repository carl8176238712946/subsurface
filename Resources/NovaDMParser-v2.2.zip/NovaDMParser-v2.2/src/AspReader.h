// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#ifndef AspReader_H_364725826351845326843
#define AspReader_H_364725826351845326843


#include "NdmReader.h"
//#include "NdmWriter.h"

#include <cstdlib>

class PropertyStore
{
public:
    
    PropertyStore():
    prop_id_counter_(0)
    {}
    
    void clear()
    {
        prop_id_counter_ = 0;
        
        prop_ids_.clear();
        prop_tree_m.clear();
        typologies_.clear();
        subjects_.clear();
        approaches_.clear();
        features_.clear();
        attributes_.clear();
        fcPropVals_.clear();
        //typology_ = "undefined_typology";
    }

    
    std::string registerPropId(std::string s)
    {
        if(prop_ids_.find(s) == prop_ids_.end())
        {
            prop_ids_[s] = prop_id_counter_;
            prop_id_counter_++;
        }
        
        size_t v = prop_ids_[s];
        std::stringstream ss;
        ss << v;
//        std::string idv = "n" + std::to_string(v);
        std::string idv = "a" + ss.str();
        return idv;
    }
    
//    size_t getPropId(std::string s)
//    {
//        return prop_ids_[s];
//    }
    
    ////////////
    
    void writeToFile(NdmFileWriter& fout)
    {
//        fout.writespc("TYPOLOGY");
//        fout.writespc(typology_);
//        fout.nl();
        
        writeTypologyToFile(fout, typologies_);
        
//        writeToFile(fout, typologies_,  "TYPOLOGY");
        writeToFile(fout, subjects_,    "SUBJECT");
        writeToFile(fout, approaches_,  "APPROACH");
        writeToFile(fout, features_,    "FEATURE");
        writeToFile(fout, attributes_,  "ATTRIBUTE");
   
    }
    void writeTypologyToFile(NdmFileWriter& fout, std::vector<NdmPropertyValue*>& vs)
    {
        fout.nl();
        fout.writeln("TYPOLOGY");
        
        for(int i=0; i<vs.size(); i++)
        {
            NdmPropertyValue* p = vs[i];
            fout.writespc(p->ptype_);
            fout.nl();
        }
        
    }
    
    void writeToFile(NdmFileWriter& fout, std::vector<NdmPropertyValue*>& vs, std::string prefix)
    {
        fout.nl();
        fout.writeln(prefix);
        
        for(int i=0; i<vs.size(); i++)
        {
            NdmPropertyValue* p = vs[i];
            //std::cout << prefix << " " << prop_tree_m[p] << " " << p->ptype_ << " " << p->pvalue_ << std::endl;
            //fout.writespc(prefix);
            fout.writespc(p->prop_id_);
            fout.writespc(prop_tree_m[p]);
            fout.writespc(p->ptype_);
            fout.writespc(p->pvalue_);
            fout.nl();

        }
        
    }

    ////////////
    
    void print()
    {
        print(typologies_,  "TYPOLOGY");
        print(subjects_,    "SUBJECT");
        print(approaches_,  "APPROACH");
        print(features_,    "FEATURE");
        print(attributes_,  "ATTRIBUTE");
    }

    void print(std::vector<NdmPropertyValue*>& vs, std::string prefix)
    {
        for(int i=0; i<vs.size(); i++)
        {
            NdmPropertyValue* p = vs[i];
            std::cout << prefix << " " << p->prop_id_ << " " << prop_tree_m[p] << " " << p->ptype_ << " " << p->pvalue_ << std::endl;
        }
        
    }
    ////////////
    
    size_t prop_id_counter_;

    std::map<std::string, size_t> prop_ids_;
    std::map<NdmPropertyValue*, std::string> prop_tree_m;
    
    std::vector<NdmPropertyValue*> typologies_;
    std::vector<NdmPropertyValue*> subjects_;
    std::vector<NdmPropertyValue*> approaches_;
    std::vector<NdmPropertyValue*> features_;
    std::vector<NdmPropertyValue*> attributes_;
    
    NdmFactory<NdmPropertyValue> fcPropVals_;
    
    //std::string typology_;

    
    
};

class AspReader : FileReader
{
public:
    
    size_t model_count_;
    
    
    AspReader() :
    model_count_(0)
    {}
    
    ///////////
    bool countModels(std::string fn, bool opt_only)
    {
        model_count_ = 0;
        
        std::ifstream infile;
        
        if(!openFile(fn, infile))
        {
            return false;
        }
        
        std::string line;

        std::string test_string = "Models       :";
        std::string opt_test_string = "Optimal    :";
        
        
        while (safeGetline(infile, line))
        {
            size_t pos = line.find(test_string);
            
//            std::cout << line << " (" << pos << ")" << std::endl;
            
            if(pos != std::string::npos)
            {
                //- found it
                
                std::string md = line.substr(pos + test_string.size());
                
//                std::cout << "** [" << md << "]" << std::endl;
                
                model_count_ = (size_t) strtod(md.c_str(), NULL);

                if(!opt_only)
                    return true;
                else if(model_count_ > 0)
                    model_count_ = 1; //- at least one optimal model exists, we'll try to find the exact number next (below)
                
            }
            
            
            pos = line.find(opt_test_string);
            if(pos != std::string::npos)
            {
                std::string md = line.substr(pos + opt_test_string.size());
                model_count_ = (size_t) strtod(md.c_str(), NULL);
                return true;
            }

        }

        return true;
    }
    
    
    ///////////
    bool parseModels(std::string fn, std::string outf, bool opt_only)
    {
        
        model_count_ = 0;
        
        std::ifstream infile;
        
        if(!openFile(fn, infile))
        {
            return false;
        }
        
        NdmFileWriter fout(outf);
        
        std::string line;
        
        //- clingo starts to enumerate optimal models when the model count goes back to 1
        bool found_first_optimal_model = false;
        
        std::string test_string = "Answer:";
        size_t model_num = 0;
        
        while (safeGetline(infile, line))
        {
            
            //size_t pos = line.find(test_string);
            
//            std::cout << line << " (" << pos << ")" << std::endl;
//            std::cout << "Pos:" << pos << std::endl;
            
//            if(pos != std::string::npos)
            if(startsWith(line,test_string))
            {
                model_num++;
                
                if(opt_only && !found_first_optimal_model)
                {
                    //- grab the stated model number
                    size_t pos = line.find(test_string);
                    std::string given_model_num_str = line.substr(pos + test_string.size());
                    int given_model_num = strtod(given_model_num_str.c_str(), NULL);
                    
                    if(given_model_num < model_num)
                    {
                        //- found first optimal model
                        found_first_optimal_model = true;
                        model_num = 1;
                    } else
                    {
                        continue;
                    }
                }

                //std::cout << "SCENARIO " << model_num << std::endl;
                
                fout.writespc("SCENARIO");
                fout.writespc(model_num);
                fout.nl();

                safeGetline(infile, line);
                
                prop_store_.clear();
                parseModel(line);
//                prop_store_.print();
                prop_store_.writeToFile(fout);
                
                fout.nl();
            }
            
        }
        
        fout.close();

        return true;
    }
    
    void parseModel(std::string m)
    {
//        std::cout << "Line: " << m << std::endl;

        std::vector<std::string> args;
        tokenise(m, args, ") ");

//        std::cout << "Tokens: " << m << std::endl;

        for(int i=0; i < args.size(); i++)
        {
//            std::string s = trim(args[i]);
            
            std::string s = args[i];
            
//            std::cout << "#" << i << ":[" << s << "]" << std::endl;

            if(s[s.size()-1] == ')')
                s = s.substr(0,s.size()-1);


//            std::cout << ">>#" << i << ":[" << s << "]" << std::endl;

            parseProperty(s);

//            parseProperty(args[i]);
            
        }
        
//        tokenise(std::string s, std::vector<std::string>& args, std::string delim)
    }
    
    void parseProperty(std::string s)
    {
//        std::string typStr = "typology(";
        
//        if(startsWith(s,typStr))
//        {
//            s = s.substr(typStr.size());
//            prop_store_.typologies_ = s;
//            return;
//        }
        
        std::string typStr = "typology(";
        std::string subStr = "scenario_subject(";
        std::string feaStr = "scenario_feature(";
        std::string attStr = "scenario_cost(";
        std::string appStr = "scenario_approach(";
        
        NdmPropertyValue* p = prop_store_.fcPropVals_.getFresh();
        
        if(startsWith(s,typStr))
        {
            s = s.substr(typStr.size());
            p->pcat_ = NdmPropertyType::Typology;
            prop_store_.typologies_.push_back(p);
            p->ptype_ = s.substr(0,s.size());
            return;
            
        } else if(startsWith(s,subStr))
        {
            s = s.substr(subStr.size());
            p->pcat_ = NdmPropertyType::Subject;
            prop_store_.subjects_.push_back(p);
        } else if(startsWith(s,feaStr))
        {
            s = s.substr(feaStr.size());
            p->pcat_ = NdmPropertyType::Feature;
            prop_store_.features_.push_back(p);

        } else if(startsWith(s,attStr))
        {
            s = s.substr(attStr.size());
            p->pcat_ = NdmPropertyType::Attribute;
            prop_store_.attributes_.push_back(p);

        } else if(startsWith(s,appStr))
        {
            s = s.substr(appStr.size());
            p->pcat_ = NdmPropertyType::Approach;
            prop_store_.approaches_.push_back(p);
            
        } else {
            std::cerr << "Error parsing ASP model: unrecognised predicate: " << s << std::endl;
            return;
        }
        
        std::vector<std::string> args;
        tokenise(s, args, ",");

        //prop_store_.prop_tree_m[p] = args[1];
        p->prop_id_ = prop_store_.registerPropId(args[0]);
        prop_store_.prop_tree_m[p] = args[1];
        p->ptype_ = args[2];
        
        p->pvalue_ = (args.size() > 3? args[3] : "");

        
//        prop_store_.prop_tree_m[p] = args[0];
//        p->ptype_ = args[1];
//        
//        p->pvalue_ = (args.size() > 2? args[2] : "");
        
        
    }
    
    PropertyStore prop_store_;
    
    
    
    //////
    bool separateModels(std::string fn, std::string outf, bool opt_only, bool last_only)
    {
        
        model_count_ = 0;
        
        std::ifstream infile;
        
        if(!openFile(fn, infile))
        {
            return false;
        }
        
        
        std::string line;
        
        //- clingo starts to enumerate optimal models when the model count goes back to 1
        bool found_first_optimal_model = false;

        std::string test_string = "Answer:";
        size_t model_num = 0;
        
        while (safeGetline(infile, line))
        {
            if(startsWith(line,test_string))
            {
                model_num++;
             
                if(last_only)
                {
                  //- very crude implementation: keeps re-writing over the same file
                  //- until no more models are parsed
                  model_num = 0;

                } else if(opt_only && !found_first_optimal_model)
                {
                    //- grab the stated model number
                    size_t pos = line.find(test_string);
                    std::string given_model_num_str = line.substr(pos + test_string.size());
                    int given_model_num = strtod(given_model_num_str.c_str(), NULL);
                    
//                    std::cout << line << std::endl;
//                    std::cout << given_model_num_str << " " << given_model_num << "\n" << std::endl;

                    if(given_model_num < model_num)
                    {
                        //- found first optimal model
                        found_first_optimal_model = true;
                        model_num = 1;
                    } else
                    {
                        continue;
                    }
                }
                
//                std::string outfn = outf + std::to_string(model_num) + ".txt";

                std::stringstream ss;
                ss << outf << model_num << ".lp";
                std::string outfn = ss.str();
                
                NdmFileWriter fout(outfn);

                safeGetline(infile, line);
                
//                parseModel(line);
  
                //- write ASP facts in this model to file
                
                std::vector<std::string> args;
                tokenise(line, args, ") ");
                
                for(int i=0; i < args.size(); i++)
                {
                    std::string s = args[i];
                    
                    if(s[s.size()-1] == ')')
                        s = s.substr(0,s.size()-1);

                    fout.write(s);
                    fout.writeln(").");
                }
                
                fout.close();
            }
            
        }
        
        return true;
    }
    
    
    
private:
};

#endif
