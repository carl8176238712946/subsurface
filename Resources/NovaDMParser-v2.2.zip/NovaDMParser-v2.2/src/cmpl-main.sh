

##g++ NdmParserMain.cpp -o novadm

#clang++ NdmParserMain.cpp -o novadm

clang++ -std=c++11 NdmParserMain.cpp -o novadm


