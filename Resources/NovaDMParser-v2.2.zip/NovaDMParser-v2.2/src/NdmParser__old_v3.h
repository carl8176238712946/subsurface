// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#ifndef RDMPARSER_H_76318543451823764
#define RDMPARSER_H_76318543451823764

#include <vector>
#include <iostream>
#include <sstream>
#include <map>
//#include <fstream>

//////////////////////////////
// NdmFactory

template <class T> class NdmFactory
{
public:
    
    NdmFactory():
    next_(0)
    {}
    
    ~NdmFactory()
    {
        //        std::cout << "Deleting factory" << std::endl;
        typedef typename std::vector<T*>::iterator TListItr;
        for(TListItr it = store_.begin(); it != store_.end(); ++it)
        {
            delete (*it);
        }
    }
    
    void clear()
    {
        next_ = 0;
    }
    
    T* getFresh()
    {
        
        //        std::cout << "GET FRESH size=" << store_.size() << ", next_=" << next_ << std::endl;
        if(store_.size() == next_)
        {
            T* t = new T();
            store_.push_back(t);
            next_++;
            
            //            std::cout << " returning new " << t << std::endl;
            
            return t;
        }
        
        T* t = store_[next_];
        t->clear();
        next_ ++;
        
        //        std::cout << " returning old " << t << std::endl;
        
        return t;
        
    }
    
    size_t getNextIndex() {return next_;}
    
private:
    
    size_t next_;
    
    std::vector<T*> store_;
    
    //TList store_;
};


//////////////////////////////
// NdmPropertyType

class NdmPropertyType
{
public:
    enum Category
    {
        Undefined,
        Typology,
        Subject,
        Approach,
        Feature,
        Criterion,
        Attribute
    };
    
    std::string name_;
    Category category_;
    std::vector<std::string> values_;
};


//////////////////////////////
// NdmPropertyValue


class NdmPropertyValue
{
public:
    
    void clear()
    {
        pcat_ = NdmPropertyType::Undefined;
        ptype_ = "undefined_type";
        pvalue_ = "undefined_value";
        prop_id_ = "undefined_id";
    }
    
    void makeEqual(NdmPropertyValue& other)
    {
        prop_id_ = other.prop_id_;
        pcat_ = other.pcat_;
        ptype_ = other.ptype_;
        pvalue_ = other.pvalue_;
    }
    
    std::string prop_id_;
    NdmPropertyType::Category pcat_;
    std::string ptype_;
    std::string pvalue_;
};

class NdmAttributeAspectValue
{
public:
    //- convenience class that associates an aspect (e.g. feature, subject, etc.) with an attribute value
    
    void clear()
    {
        prop_.clear();
        attr_name_ = "undefined_attribute_name";
        attr_value_ = "undefined_attribute_value";
    }
    
    void makeEqual(NdmAttributeAspectValue& other)
    {
        prop_.makeEqual(other.prop_);
        attr_name_ = other.attr_name_;
        attr_value_ = other.attr_value_;
    }
    
    NdmPropertyValue prop_;
    std::string attr_name_;
    std::string attr_value_;

    
};


//////////////////////////////
// NdmNode


class NdmNode
{
public:
    
    enum NodeType
    {
        Xor,
        And,
        Tree
    };
    
    NdmNode():
    type_(Xor)
    {}
    
    ~NdmNode()
    {
        clear();
    }
    
    void clear()
    {
        children_.clear();
        values_.clear();
        type_ = Xor;
    }
    
    /////
    
    void addChild(NdmNode& n) {children_.push_back(&n);}
    size_t childrenCount() {return children_.size();}
    NdmNode* child(size_t i) {return children_[i];}
    
    /////
    
    void addValue(NdmPropertyValue& v) {values_.push_back(&v);}
    size_t valueCount() {return values_.size();}
    NdmPropertyValue* value(size_t i) {return values_[i];}
    
    /////
    
    void setType(NodeType t) {type_=t;}
    NodeType getType() {return type_;}
    
    /////
    
//    void setParent(NdmNode* n) {parent_ = n;}
//    NdmNode* getParent() {return parent_;}
    
private:
    
    std::vector<NdmNode*> children_;  //- no ownership
    std::vector<NdmPropertyValue*> values_;
    NodeType type_;
//    NdmNode* parent_;
    
};


//////////////////////////////
// NdmActionMap


//class NdmAction
//{
//public:
//    std::string rname_;
//    std::vector<std::string> ractions_;
//    NdmPropertyValue* pvalue_;
//};




//class NdmValueActionMap
//{
//    //- maps property values to actions
//    
//    std::map<NdmPropertyValue*, >
//};

class NdmPropertyCollector
{
public:
    
    NdmPropertyCollector():
    tree_id_(0)
    {}

    void pushValues(NdmNode& n)
    {
        for(int i=0; i<n.valueCount(); ++i)
        {
            values_.push_back(n.value(i));
        }
    }
    
    void popValues(NdmNode& n)
    {
        for(int i=0; i<n.valueCount(); ++i)
        {
            values_.pop_back();
        }
    }

    ///
    
    void pushValues(NdmPropertyCollector& n)
    {
        for(int i=0; i<n.values_.size(); ++i)
        {
            values_.push_back(n.values_[i]);
        }
    }
    
    void popValues(NdmPropertyCollector& n)
    {
        for(int i=0; i<n.values_.size(); ++i)
        {
            values_.pop_back();
        }
    }

    ///
    
    void clear()
    {
        values_.clear();
        tree_id_ = 0;
    }
    
    std::vector<NdmPropertyValue*> values_;
    
    size_t tree_id_;
    
};

////

class NdmLeafHandler
{
public:
    virtual void handleLeaf(NdmPropertyCollector& vs) = 0;
};

class NdmTreeWalker : public NdmLeafHandler
{
public:
    //- found complete action when:
    //-   - at a leaf node, and
    //-   - no more "And" children
    
    
    //- create a new walker for each "And" node
    
    void setLeafHandler(NdmLeafHandler& l) {leaf_handler_ = &l;}
    
//    void setNode(NdmNode& n) {node_ = &n;}
    
    void walk()
    {
        walk(*start_node_);
    }
    
    void walk(NdmNode& n)
    {
        values_.pushValues(n);
        
        if(n.childrenCount() == 0)
        {
            //- case: leaf
            leaf_handler_->handleLeaf(values_);

            
            
            ////////////////////////////////////////
        } else if(n.getType() == NdmNode::Xor)
        {
            //- case: Xor node
            for(int i=0; i<n.childrenCount(); ++i)
            {
                walk(*(n.child(i)));
          
            }

            ////////////////////////////////////////
        } else if(n.getType() == NdmNode::And)
        {
            //- case: And node
            
            for(int i=0; i<n.childrenCount(); ++i)
            {
                NdmTreeWalker* w = fcWalkers_.getFresh();
                w->setLeafHandler(*this);
                w->start_node_ = n.child(i);
                and_walkers_.push_back(w);
                
            }
            
            current_and_walker_ = 0;
            
            and_walkers_[current_and_walker_]->walk();
            
            and_walkers_.clear();
            fcWalkers_.clear();
            
            
            ////////////////////////////////////////
        } else if(n.getType() == NdmNode::Tree)
        {
            //- case: Tree node - every child starts a new tree
            
            
            for(int i=0; i<n.childrenCount(); ++i)
            {
                values_.tree_id_++;
                walk(*(n.child(i)));
                
            }
            
//            values_.tree_id_--;
        }

            
            
//            for(int i=0; i<n.childrenCount(); ++i)
//            {
//                NdmTreeWalker* w = fcWalkers_.getFresh();
//                w->setLeafHandler(*this);
//                w->start_node_ = n.child(i);
//                and_walkers_.push_back(w);
//                
//            }
//            
//            current_and_walker_ = 0;
//            
//            and_walkers_[current_and_walker_]->walk();
//            
//            and_walkers_.clear();
        
        
        
        values_.popValues(n);
        
    }
    
    virtual void handleLeaf(NdmPropertyCollector& vs)
    {
        
        values_.pushValues(vs);
        values_.tree_id_ += vs.tree_id_;

        current_and_walker_ ++;
        
        if(current_and_walker_ >= and_walkers_.size())
        {
            leaf_handler_->handleLeaf(values_);
        } else
        {
            NdmTreeWalker* w = and_walkers_[current_and_walker_];
           // w->reset();
            w->walk();
        }

        current_and_walker_--;
        
        values_.tree_id_ -= vs.tree_id_;
        values_.popValues(vs);

    }
    
    
    void clear()
    {
        reset();
        leaf_handler_ = NULL;
        start_node_ = NULL;
        tree_count_ = 0;
    }
    
    void reset()
    {
        values_.clear();
        fcWalkers_.clear();
        and_walkers_.clear();
        current_and_walker_ = 0;
    }
    
    NdmPropertyCollector values_;
    NdmLeafHandler* leaf_handler_;
    
    NdmNode* start_node_;
    
    NdmFactory<NdmTreeWalker> fcWalkers_;
    std::vector<NdmTreeWalker*> and_walkers_;
    size_t current_and_walker_;
    
    size_t tree_count_;
    
};





//////////////////////////////
// NdmTreeBuilder


class NdmTreeBuilder
{
public:
    
    void clear()
    {
        fcNdmNode_.clear();
        fcNdmPropertyValue_.clear();
    }
    
    NdmNode*            getFreshNode()              {return (NdmNode*)          fcNdmNode_.getFresh();    }
    NdmPropertyValue*   getFreshPropertyValue()     {return (NdmPropertyValue*) fcNdmPropertyValue_.getFresh();    }

    void addPropertyValue(NdmNode* n, NdmPropertyType::Category c, std::string ptyp, std::string pval)
    {
        NdmPropertyValue* v = getFreshPropertyValue();
        v->pcat_ = c;
        v->ptype_ = ptyp;
        v->pvalue_ = pval;
        
        n->addValue(*v);
    }
    
    

    
private:
    NdmFactory<NdmNode>             fcNdmNode_;
    NdmFactory<NdmPropertyValue>    fcNdmPropertyValue_;
};


////////////////////////////////
//// NdmWriter
//
//class NdmWriter
//{
//public:
//    
//    NdmWriter():
//    out_(std::cout)
//    {
//        indent_marker_ = " ";
//        indent_ = 0;
////        out_ = std::cout;
//    }
//    
//    void write(NdmNode& n)
//    {
//        indent_ = 0;
//        write_(&n);
//        out_.flush();
//    }
//
//    
//private:
//    
//    
//    void write_(NdmPropertyValue* v)
//    {
//        std::stringstream c;
//        if(v->pcat_ == NdmPropertyType::Subject) c << "subject";
//        else if(v->pcat_ == NdmPropertyType::Feature) c << "feature";
//        else if(v->pcat_ == NdmPropertyType::Approach) c << "approach";
//        else if(v->pcat_ == NdmPropertyType::Criterion) c << "criterion";
//        
//        if(v->pcat_ == NdmPropertyType::Criterion || v->pcat_ == NdmPropertyType::Approach)
//        {
////            out_ << c.str() << "=" << v->pvalue_;
//            out_ << c.str() << ":" << v->pvalue_;
//        } else
//        {
//            out_ << c.str() << ":" << v->ptype_ << "=" << v->pvalue_;
//        }
//    }
//    
//    void write_(NdmNode* n)
//    {
//        std::stringstream ss;
//        makeIndent(ss);
////        out_->operator<<(ss.str().c_str());
////        out_->operator<<("- ");
////        out_->operator<<(std::endl);
//
//        out_ << ss.str();
//
//        //- write node type
//        if(n->getType() == NdmNode::Xor) out_ << "- ";
//        else if(n->getType() == NdmNode::And) out_ << "+ ";
//        else if(n->getType() == NdmNode::Tree) out_ << "* ";
//        else out_ << "(unrecognised node type) ";
//        
//        //- write values
//        
//        out_ << "[";
//        for(int i=0; i<n->valueCount(); ++i)
//        {
//            if(i>0) out_ << ", ";
//            write_(n->value(i));
//        }
//
//        out_ << "]";
//        out_ << std::endl;
//
//        //- write children
//        
//        indent_++;
//        for(int i=0; i<n->childrenCount(); ++i)
//        {
//            write_(n->child(i));
//        }
//        indent_--;
//    }
//    
//    void makeIndent(std::stringstream& ss)
//    {
//        for(int i=0; i<indent_; ++i)
//        {
////            ss->operator<<(indent_marker_.c_str());
//            ss << indent_marker_;
//        }
//    }
//
//    size_t indent_;
//    std::string indent_marker_;
//    
//    std::ostream& out_;
//    
//
//};


//////////////////////////////
// PrinterLeafHandler

class PrinterLeafHandler : public NdmLeafHandler
{
public:
    PrinterLeafHandler()
    {
        walker_.setLeafHandler(*this);
    }
    
    void parse(NdmNode& n, std::string nm)
    {
        std::cout << "Renovation Alternative: " << nm << std::endl;
        
        action_count_ = 0;
        rname_ = nm;
        walker_.walk(n);
    }
    
    virtual void handleLeaf(NdmPropertyCollector& vs)
    {
        action_count_ ++;

        std::cout << "\n  Action: " << action_count_ << std::endl;

        for(int i=0; i<vs.values_.size(); ++i)
        {
            NdmPropertyValue* v = vs.values_[i];
            
            std::stringstream c;
            if(v->pcat_ == NdmPropertyType::Subject) c << "subject";
            else if(v->pcat_ == NdmPropertyType::Feature) c << "feature";
            else if(v->pcat_ == NdmPropertyType::Approach) c << "approach";
            else if(v->pcat_ == NdmPropertyType::Criterion) c << "criterion";

            if((v->pcat_ == NdmPropertyType::Criterion) || (v->pcat_ == NdmPropertyType::Approach))
            {
                std::cout << "  " << c.str() << ":" << v->pvalue_ << std::endl;
                
            }
            else
            {
                std::cout << "  " << c.str() << ":" << v->ptype_ << "=" << v->pvalue_ << std::endl;
            }
        }
    }

    NdmTreeWalker walker_;
    std::string rname_;
    size_t action_count_;
    
//    NdmPropertyType::Category pcat_;
//    std::string ptype_;
//    std::string pvalue_;

};


//////////////////////////////
// ActionValueMapLeafHandler


class ActionValueMapLeafHandler : public NdmLeafHandler
{
public:
    ActionValueMapLeafHandler()
    {
        walker_.setLeafHandler(*this);
    }
    
//    void parse(NdmNode& n, std::string nm)
    void parse(NdmNode& n, size_t tree_count)
    {
        //std::cout << "Renovation Alternative: " << nm << std::endl;
        
        //action_count_ = 0;
        tree_action_count_.clear();
        start_tree_count_ = tree_count;
//        rname_ = nm;
        walker_.walk(n);
    }
    
    virtual void handleLeaf(NdmPropertyCollector& vs)
    {
        size_t tree_id = start_tree_count_ + vs.tree_id_;
        
        last_tree_id_ = std::max(last_tree_id_, tree_id);
        
        if(tree_action_count_.find(tree_id) == tree_action_count_.end()) tree_action_count_[tree_id] = 0;
        tree_action_count_[tree_id]++;
        
//        action_count_ ++;
        
        //std::cout << "\n  Action: " << action_count_ << std::endl;
        
        for(int i=0; i<vs.values_.size(); ++i)
        {
            NdmPropertyValue* v = vs.values_[i];
            
            tree_action_value_m_[tree_id][v].push_back(tree_action_count_[tree_id]);
            
        }
    }
    
    void print()
    {
        for(std::map<size_t, std::map<NdmPropertyValue*, std::vector<size_t> > >::iterator outerit = tree_action_value_m_.begin();
            outerit != tree_action_value_m_.end(); ++outerit)
        {
            
            std::cout << "Renovation Alternative " << outerit->first << ":" << std::endl;
            
            for(std::map<NdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
                it != outerit->second.end(); ++it)
            {
                NdmPropertyValue* v = it->first;
                
                std::stringstream c;
                if(v->pcat_ == NdmPropertyType::Subject) c << "subject";
                else if(v->pcat_ == NdmPropertyType::Feature) c << "feature";
                else if(v->pcat_ == NdmPropertyType::Approach) c << "approach";
                else if(v->pcat_ == NdmPropertyType::Criterion) c << "criterion";
                
                if((v->pcat_ == NdmPropertyType::Criterion) || (v->pcat_ == NdmPropertyType::Approach))
                {
                    std::cout << "  " << c.str() << ":" << v->pvalue_ << "[";
                } else
                {
                    std::cout << "  " << c.str() << ":" << v->ptype_ << "=" << v->pvalue_ << "[";
                }
                
                std::vector<size_t>& vs = it->second;
                
                for(int i=0; i<vs.size(); ++i)
                {
                    if(i>0) std::cout << ", ";
                    std::cout << vs[i];
                }
                
                std::cout << "]" << std::endl;
                
            }
        }
    }

    std::map<size_t, std::map<NdmPropertyValue*, std::vector<size_t> > > tree_action_value_m_;

    NdmTreeWalker walker_;
//    std::string rname_;
//    size_t tree_count_;
    
    size_t start_tree_count_;
    size_t last_tree_id_;

    std::map<size_t, size_t> tree_action_count_;
//    size_t action_count_;
    
};


//////////////////////////////
// NdmStats

class NdmStats
{
public:
    
    class StatItem
    {
    public:
        size_t s_actions_;
        
        size_t s_subjects_;
        size_t s_feature_;
        size_t s_approaches_;
        size_t s_criteria_;
        
        size_t id_;
        
        void clear()
        {
            s_actions_  = 0;
            
            s_subjects_  = 0;
            s_feature_  = 0;
            s_approaches_  = 0;
            s_criteria_  = 0;
            
            id_ = 0;
        }
    };
    

    NdmStats()
    {
        clear();
    }
    
//    void setActionValueMap(ActionValueMapLeafHandler& avm) {h_ = &avm;}
    
    void clear()
    {
//        s_trees_  = 0;
        stat_item_.clear();
        items_.clear();
        fcStatItems_.clear();

//        s_actions_  = 0;
//        
//        s_subjects_  = 0;
//        s_feature_  = 0;
//        s_approaches_  = 0;
//        s_criteria_  = 0;
    }
    
    void printStats()
    {
        std::vector<std::string> lbls;
        lbls.push_back("Alt");
        lbls.push_back("   Actions");
        lbls.push_back(" Subjects");
        lbls.push_back(" Approaches");
        lbls.push_back(" Features");
        lbls.push_back(" Criteria");
        
        std::vector<size_t> lbl_sz;
        for(int i=0; i<lbls.size(); ++i)
        {
            lbl_sz.push_back(lbls[i].size());
        }

        std::cout << std::endl;
        std::cout << "=========================" << std::endl;
        std::cout << "Statistics:" << std::endl;
        std::cout << "  Alternatives: " << items_.size() << std::endl;
        std::cout << "  Actions:      " << stat_item_.s_actions_ << std::endl;
        std::cout << std::endl;
        std::cout << "  Subjects:   " << stat_item_.s_subjects_ << std::endl;
        std::cout << "  Approaches: " << stat_item_.s_approaches_ << std::endl;
        std::cout << "  Features:   " << stat_item_.s_feature_ << std::endl;
        std::cout << "  Criteria:   " << stat_item_.s_criteria_ << std::endl;
        std::cout << "=========================" << std::endl;
        std::cout << std::endl;
        std::cout << "-------------------------------------------" << std::endl;
        for(int i=0; i<lbls.size(); ++i)
        {
            //if(i > 0) std::cout << " ";
            std::cout << lbls[i];
        }
        std::cout << std::endl;
        std::cout << "-------------------------------------------" << std::endl;
        std::cout << std::endl;
        for(int i=0; i<items_.size(); ++i)
        {
            StatItem* si = items_[i];
            std::cout << right_align(si->id_, lbl_sz[0]);
            std::cout << right_align(si->s_actions_, lbl_sz[1]);

            std::cout << right_align(si->s_subjects_, lbl_sz[2]);
            std::cout << right_align(si->s_approaches_, lbl_sz[3]);
            std::cout << right_align(si->s_feature_, lbl_sz[4]);
            std::cout << right_align(si->s_criteria_, lbl_sz[5]);
            
            std::cout << std::endl;
        }
        std::cout << "-------------------------------------------" << std::endl;

        
    }
    
    std::string right_align(size_t s, size_t len)
    {
        std::stringstream ss;
        ss.width(len);
        ss.fill(' ');
        ss << s;
        return ss.str();
    }
    
//    ActionValueMapLeafHandler* h_; //- no ownership
    
    void updateStats(ActionValueMapLeafHandler& h)
    {
        
        for(std::map<size_t, std::map<NdmPropertyValue*, std::vector<size_t> > >::iterator outerit = h.tree_action_value_m_.begin();
            outerit != h.tree_action_value_m_.end(); ++outerit)
        {
            
//            s_trees_++;
            
            StatItem* si = fcStatItems_.getFresh();
            items_.push_back(si);

            si->id_ = outerit->first;
            si->s_actions_ = h.tree_action_count_[outerit->first];
            
            
            for(std::map<NdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
                it != outerit->second.end(); ++it)
            {
                NdmPropertyValue* v = it->first;
                
                if(v->pcat_ == NdmPropertyType::Subject)   si->s_subjects_++;
                else if(v->pcat_ == NdmPropertyType::Feature)   si->s_feature_++;
                else if(v->pcat_ == NdmPropertyType::Approach)  si->s_approaches_++;
                else if(v->pcat_ == NdmPropertyType::Criterion) si->s_criteria_++;
            }
            
            stat_item_.s_actions_    += si->s_actions_;
            stat_item_.s_subjects_   += si->s_subjects_;
            stat_item_.s_feature_    += si->s_feature_;
            stat_item_.s_approaches_ += si->s_approaches_;
            stat_item_.s_criteria_   += si->s_criteria_;

//            stat_item_.s_actions_ += h.tree_action_count_[outerit->first];
//            
//            
//            for(std::map<NdmPropertyValue*, std::vector<size_t> >::iterator it = outerit->second.begin();
//                it != outerit->second.end(); ++it)
//            {
//                NdmPropertyValue* v = it->first;
//                
//                if(v->pcat_ == NdmPropertyType::Subject)   stat_item_.s_subjects_++;
//                else if(v->pcat_ == NdmPropertyType::Feature)   stat_item_.s_feature_++;
//                else if(v->pcat_ == NdmPropertyType::Approach)  stat_item_.s_approaches_++;
//                else if(v->pcat_ == NdmPropertyType::Criterion) stat_item_.s_criteria_++;
//            }
        }
        
    }

    
    
    //- stats
    
//    size_t s_trees_;
    
    StatItem stat_item_;
    
    NdmFactory<StatItem> fcStatItems_;
    std::vector<StatItem*> items_;

//    size_t s_actions_;
//    
//    size_t s_subjects_;
//    size_t s_feature_;
//    size_t s_approaches_;
//    size_t s_criteria_;
    
    
    
};




//////////////////////////////
// NdmFileWriter



#endif