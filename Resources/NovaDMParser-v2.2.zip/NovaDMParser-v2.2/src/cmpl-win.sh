
#/Users/carlschultz/AARHUS/Projects/Masters_Students/Charu_Thesis/software/mingw-w64-bin_i686-darwin_20130622/bin/x86_64-w64-mingw32-g++ -static -static-libgcc -static-libstdc++ NdmParserMain.cpp -o novadm.exe


x86_64-w64-mingw32-g++ -std=c++11 -static -static-libgcc -static-libstdc++ -I/usr/local/Cellar/boost/1.73.0/include NdmParserMain.cpp -o novadm.exe


##/usr/local/Cellar/boost/1.73.0/include
