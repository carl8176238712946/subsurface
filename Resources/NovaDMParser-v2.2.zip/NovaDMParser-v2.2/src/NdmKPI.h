// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}

#ifndef NDM_KPI_H_15287361524
#define NDM_KPI_H_15287361524

#include "NdmReader.h"
#include "NdmWriter.h"

//////////////////////////////////////////
//////////////////////////////////////////

//- each instance represents a column of data in a KPI data table
//- i.e. each index is a scenario, each entry is KPI value for that scenario
class NdmKPIData
{
public:
  std::vector<double> data_;
  void clear() {  data_.clear(); }

//  NdmKPIData():
//  {}


};



/////////////////////////////////

class NdmKPIDatastore
{
public:
  NdmKPIDatastore():
  kpi_count_(-1),
  scenario_count_(0)
  //precision_(100),
  //dp_(4)
  {}

  //////////////////////////

  //void setPrecision(int pr) {precision_ = pr;}
  //void setDP(int dp) {dp_ = dp;}

  void reset()
  {
    for(int i=0; i < kpi_count_; i++)
    {
      kpi_columns_.clear();
      fcData_.clear();
      kpi_count_ = -1;
    }
  }

  //////////////////////////

  bool checkAndSetKPICount(int n)
  {
    if(n <= 0)
      return false;  //- must have positive KPI count

    if(kpi_count_ == -1)
    {  //- setting KPI count for the first time, initialise datastore
       kpi_count_ = n;
       
       for(int i=0; i < n; i++)
       {
         NdmKPIData* d = fcData_.getFresh();
         kpi_columns_.push_back(d);
       }

       return true;
    } else {
       return kpi_count_ == n;  //- KPI count must be consistent
    } 
  }

  //////////////////////////

  bool addDataRow(std::vector<double>& data)
  {
    if(data.size() != kpi_count_)
      return false;

    for(int i=0; i < data.size(); i++)
    {
      NdmKPIData* c = kpi_columns_[i];
      c->data_.push_back(data[i]);
    }

    scenario_count_++;

    return true;
  }

  //////////////////////////

  void writeToFile(std::string fn, int pr, int dp)
  {
    //std::cout << "Writing to file..." << std::endl;

    NdmFileWriter fw(fn);
    fw.set_double_output(pr, dp, false);

    fw.writeln(kpi_count_);

    for(int i=0; i < scenario_count_; i++)
    {
      fw.writespc(i);
      for(int j=0; j < kpi_columns_.size(); j++)
      {
        double d = kpi_columns_[j]->data_[i];
        fw.writeDblspc(d);
//        fw.writeDblspc(0);
      }
      fw.nl();
    }
  }


  std::string toString()
  {
    std::stringstream ss;
    ss << kpi_count_;
    ss << std::endl;

    for(int i=0; i < scenario_count_; i++)
    {
      ss << i;
      ss << " ";
      for(int j=0; j < kpi_columns_.size(); j++)
      {
        double d = kpi_columns_[j]->data_[i];
        ss << d;
        ss << " ";
      }
      ss << std::endl;
    }
    return ss.str();
  }

  int getKPICount() {return kpi_count_;}
  NdmKPIData* getKPIData(int i) {return kpi_columns_[i];}

private:
  int kpi_count_;
  int scenario_count_;
  //int precision_;
  //int dp_;

  NdmFactory<NdmKPIData> fcData_;
  std::vector<NdmKPIData*> kpi_columns_;
};

/////////////////////////////////

class NdmKPIStats
{
public:

  NdmKPIStats():
  kpi_count_(0)
  {}

  void clear()
  {
    min_.clear();
    max_.clear();
  }

  ////////////////////////////////////////

  void setStats(NdmKPIDatastore& ds)
  {
    kpi_count_ = ds.getKPICount();
    for(int i=0; i < ds.getKPICount(); i++)
    {
      NdmKPIData* d = ds.getKPIData(i);
      double cmin = 0;
      double cmax = 0;
      for(int j=0; j < d->data_.size(); j++)
      {
        double v = d->data_[j];
        if(j==0)
        {
          cmin = v;
          cmax = v;
        } else
        {
          cmin = (cmin < v ? cmin : v);
          cmax = (cmax > v ? cmax : v);
        }
      }
      min_.push_back(cmin);
      max_.push_back(cmax);
    }
  }

  ////////////////////////////////////////

  void normalise(NdmKPIDatastore& ds, double lb, double ub)
  {
    if(kpi_count_ != ds.getKPICount())
    {
      std::cerr << "Trying to normalise KPI datastore, but stats KPI count not equal to datastore KPI count." << std::endl;
      return;
    }

    for(int i=0; i < kpi_count_; i++)
    {
      NdmKPIData* d = ds.getKPIData(i);
      double cmin = min_[i];
      double cmax = max_[i];

      for(int j=0; j < d->data_.size(); j++)
      {
        if(cmax == cmin)
          d->data_[j] = cmin;
        else {
         double v = d->data_[j];
         d->data_[j] = (ub - lb) * (v - cmin) / (cmax - cmin) + lb;
        }
      }
    }
  }

  ////////////////////////////////////////

  //- intended to be used by filereaders to set up stats from a file
  void addMin(double cmin) { min_.push_back(cmin);}
  void addMax(double cmax) { max_.push_back(cmax);}
  bool updateKPICount()
  {  //- check that min/max have same size
     if(min_.size() != max_.size())
     {
       std::cerr << "Inconsistent KPIs assigned to min values and max values in KPI stats object." << std::endl;
       return false;
     }

     kpi_count_ = min_.size();
     return true;
  }

//  double getMin(int i) { return min_[i]; }
//  double getMax(int i) { return max_[i]; }

  void writeToFile(std::string fn, int pr, int dp)
  {
    NdmFileWriter fw(fn);

    fw.set_double_output(pr, dp, false);

    fw.write("%%KPI: ");
    for(int i=0; i < kpi_count_; i++)
    {
      fw.writespc(i);
    }

    fw.nl();
    fw.writespc("MIN");

    for(int i=0; i < kpi_count_; i++)
    {
      fw.writeDblspc(min_[i]);
    }

    fw.nl();
    fw.writespc("MAX");

    for(int i=0; i < kpi_count_; i++)
    {
      fw.writeDblspc(max_[i]);
    }

  }

/*
  void writeToFile(std::string fn)
  {
    NdmFileWriter fw(fn);
    fw.writeln("%%KPI MIN MAX");
    for(int i=0; i < kpi_count_; i++)
    {
      fw.writespc(i);
      fw.writeDblspc(min_[i]);
      fw.writeDblspc(max_[i]);
      fw.nl();
    }
  }
*/

private:
  int kpi_count_;
  std::vector<double> min_;
  std::vector<double> max_;

};


//////////////////////////////////////////
//////////////////////////////////////////

/*
class NdmKPIStatsWriter : FileWriter
{
public:
  NdmKPIStatsWriter():
  FileWriter
};
*/

//////////////////////////////////////////
//////////////////////////////////////////


class NdmKPIReader : FileReader
{
public:
  NdmKPIReader()
  {}

  bool parseKPI(std::string fn, NdmKPIDatastore& store)
  {
    std::ifstream infile;

    if(!FileReader::openFile(fn, infile))
        return false;

     bool parse_error = false;
     size_t line_num = 0;
     std::string line;

     while (safeGetline(infile, line))
     {
        line_num++;

//        std::cout << "LINE #" << line_num << ":[" << line << "]" << std::endl;
 //       std::cout << "LINE #" << line_num << " (trimmed size " << trim(line).size() <<"):[" << trim(line) << "]" << std::endl;

        line = trim(line);

        if(line.size() == 0)
        {
           continue;
        } else if(line[0] == '%')
        {
           continue; //- comment
        } else 
        {
          std::vector<std::string> toks;
          tokenise(line, toks, " ");

          if(toks.size() == 1)
          {  //- expecting first line to be the number of KPIs
             int n = toInt(toks[0]);
             if(!store.checkAndSetKPICount(n))
             {
              parse_fail("Invalid or inconsistent KPI count found", line_num, line);
              parse_error = true;
              break;
             }
          } else if(toks.size() > 1)
          {
            std::vector<double> data;
            for(int i=1; i < toks.size(); i++)  //- skip first (ignore scenario ID)
            {
              double d = toDouble(toks[i]);
              data.push_back(d);
            }

            if(!store.addDataRow(data))
            {
              parse_fail("Invalid or inconsistent KPI data row", line_num, line);
              parse_error = true;
              break;
            }
          }
        
        }
     }

     infile.close();

     if(parse_error)
     {
        store.reset();
        return false;
     }
     return true;

  }

  //////////////////////////////
  //////////////////////////////


  bool parseKPIStats(std::string fn, NdmKPIStats& stats)
  {
    stats.clear();

    std::ifstream infile;

    if(!FileReader::openFile(fn, infile))
        return false;

     bool parse_error = false;
     size_t line_num = 0;
     std::string line;

     while (safeGetline(infile, line))
     {
        line_num++;

        line = trim(line);

        if(line.size() == 0)
        {
           continue;
        } else if(line[0] == '%')
        {
           continue; //- comment
        } else 
        {
          std::vector<std::string> toks;
          tokenise(line, toks, " ");

          if(toks.size() > 0)
          {

           if(toks[0].compare("MIN") == 0)
           {
            for(int i=1; i < toks.size(); i++)
            {
              stats.addMin(toDouble(toks[i]));
            }
           } else if(toks[0].compare("MAX") == 0)
           {
            for(int i=1; i < toks.size(); i++)
            {
              stats.addMax(toDouble(toks[i]));
            }
           }
          }
        }
     }

     infile.close();

     if(!stats.updateKPICount())
     {
        stats.clear();
        return false;
     }
     return true;

  }



/*
  bool parseKPIStats(std::string fn, NdmKPIStats& stats)
  {
    stats.clear();

    std::ifstream infile;

    if(!FileReader::openFile(fn, infile))
        return false;

     bool parse_error = false;
     size_t line_num = 0;
     std::string line;

     while (safeGetline(infile, line))
     {
        line_num++;

        line = trim(line);

        if(line.size() == 0)
        {
           continue;
        } else if(line[0] == '%')
        {
           continue; //- comment
        } else 
        {
          std::vector<std::string> toks;
          tokenise(line, toks, " ");

          if(toks.size() == 3)
          {
            stats.addMin(toDouble(toks[1]));
            stats.addMax(toDouble(toks[2]));

            std::vector<double> data;
            for(int i=1; i < toks.size(); i++)  //- skip first (ignore scenario ID)
            {
              double d = toDouble(toks[i]);
              data.push_back(d);
            }
          }
        
        }
     }

     infile.close();

     if(!stats.updateKPICount())
     {
        stats.clear();
        return false;
     }
     return true;

  }
*/
   
private:


};

//////////////////////////////////////////
//////////////////////////////////////////



#endif