

Examples of how to use NovaDM KPI flags.

You should have two example KPI files: 
 * KPI_2_A.txt
 * KPI_2_B.txt

======================================================
(1) combine two KPI files together
novadm --combine-kpi KPI_2_A.txt KPI_2_B.txt KPI_2_AB.txt
./novadm --combine-kpi XD0.txt XD1.txt Test_Comb.txt

NOTE: can combine as many KPI files as you like, e.g.:
novadm --combine-kpi <KPI-filename-1> ... <KPI-filename-n> <output-filename>

======================================================
(2) generate min/max of a set of KPI files
novadm --gen-kpi-min-max KPI_2_A.txt KPI_2_B.txt Test_KPI_Min_Max.txt
./novadm --gen-kpi-min-max XD0.txt XD1.txt Test_Min_Max.txt

NOTE: can generate min/max across as many KPI files as you like:
novadm --combine-kpi <KPI-filename-1> ... <KPI-filename-n> <output-filename>

======================================================
(3) normalise a KPI file
novadm --normalise-kpi 0 100 Test_KPI_Min_Max.txt KPI_2_AB.txt Norm_KPI_2_AB.txt
./novadm --normalise-kpi 0 100 Test_Min_Max.txt Test_Comb.txt Test_Norm.txt

NOTE: This example normalises values to the interval [0,100]

Here is what each argument means:
novadm --normalise-kpi <norm-lower-bound> <norm-upper-bound> <KPI-min-max> <input-KPI-filename> <output-KPI-filename>
======================================================



COMMANDS:

./novadm --combine-kpi XD0.txt XD1.txt Test_Comb.txt
./novadm --gen-kpi-min-max XD0.txt XD1.txt Test_Min_Max.txt
./novadm --normalise-kpi 0 100 Test_Min_Max.txt Test_Comb.txt Test_Norm.txt
