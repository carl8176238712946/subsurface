======
Example:
This should display a welcome message with options (this step is just for fun, not needed in our Revit pipeline).

novadm

======
Example:
Print the tree in the example file. Please look inside the file "tree1.ndm" (this step is also just for fun, not needed in our Revit pipeline).

novadm --print tree_Kamari_test.ndm

======
Example (**):
Convert the tree to ASP facts. Again, please look inside the created file "myasp.lp" to see what it looks like.

novadm --asp tree_Kamari_test.ndm myasp

======
Example:
Run clingo on converted action tree with query, print results to the console. Please look inside the file "NovaDMAsp.lp" and see if you can understand some parts of it. Try uncommenting some different queries and "show" instructions in  "NovaDMAsp.lp" and see the effect.

clingo myasp.lp NovaDMAsp.lp 0

======
Example:
Run clingo again, but add some options to reduce printed text etc.

clingo --fast-exit --quiet=2,2,2 myasp.lp NovaDMAsp.lp 0

======
Example (**): 
As above, but now write output to file "asp_out.txt" (this is called "piping"). Please look inside "asp_out.txt". 

clingo --fast-exit --quiet=2,2,2 myasp.lp NovaDMAsp.lp 0 &> asp_out.txt

======
Example:
Run clingo with some optimisation.

clingo myasp.lp NovaDMAsp.lp --opt-mode=optN 3

======
Example (**):
Parse ASP output, extract the model count, and save in file "res.txt". Yet  again, please look inside "res.txt"

novadm --asp-count-models asp_out.txt res.txt
======

