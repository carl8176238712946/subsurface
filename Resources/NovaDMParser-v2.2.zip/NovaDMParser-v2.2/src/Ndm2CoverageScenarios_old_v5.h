// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#ifndef RDM2COVERAGESCENARIOS_H_91823746
#define RDM2COVERAGESCENARIOS_H_91823746

#include "NdmWriter.h"
#include <random>
#include <sstream>




class Ndm2CoverageScenarios :
 public NdmFileWriter,
 public NdmLeafHandler,
 public NdmWalkerListener
{
public:

    Ndm2CoverageScenarios(std::string fn):
    NdmFileWriter(fn),
    total_scenario_count(0),
    cardinality_(1),
    verbose_(false)
    {
        walker_.setLeafHandler(*this);
        walker_.setListener(*this);
    };
    
    void set_cardinality(size_t v) {cardinality_ = v;};

    /////
    void set_verbose(bool v) {verbose_ = v;};
    
    virtual void write(NdmReader& r)
    {

      if(verbose_) std::cout << "Writing coverage scenario\n" << std::endl;

      total_scenario_count = 0;
      
      for(int i=0; i < r.trees_.size(); i++)
      {

        //- for verbose info
        int cur_scenario_count = total_scenario_count;

        tabu_.clear();
        walker_.walk(*(r.trees_[i]));

        if(verbose_) std::cout << "Tree " << i << ": " << (total_scenario_count - cur_scenario_count) << " scenarios" << std::endl;

      }

      if(verbose_) std::cout << "Total scenario count: " << total_scenario_count << "\n" << std::endl;

    };    
    

    void print_node(NdmNode* n)
    {
      std::cout << "Node Type: " << n->getType() << std::endl;
      for(int i=0; i < n->valueCount(); i++)
      {
        std::cout << "  PCat: " << n->value(i)->pcat_ << ", PType: " << n->value(i)->ptype_ << ", PValue: " << n->value(i)->pvalue_ << std::endl;
      }
    }

    //- when an Xor node is visited for the first time
    //- it is enumerated as usual
    //- every other time the Xor node is visited, only 
    //- the first child is selected
    virtual bool visit_node(NdmNode& n)
    {

      //std::cout << "Visiting node: ";
      //print_node(&n);

      //- only interested in Xor nodes
      if(n.getType() != NdmNode::Xor)
        return true;

      //- check if node has been visited before
      for(int i=0; i < tabu_.size(); i++)
      {
        if(tabu_[i] == &n)
        {
          //std::cout << "\n TABU " << std::endl;
          return false;
        }
      }
 
      return true;
    };

    virtual void node_visited(NdmNode& n)
    {
      //std::cout << "\n AFTER" << std::endl;

      //- after Xor node visited, all children after
      //- first become tabu
      if(n.getType() == NdmNode::Xor)
      {
        for(int i=cardinality_; i < n.childrenCount(); i++)
        {
          tabu_.push_back(n.child(i));
        }
      }

    };



    void write_properties(NdmPropertyType::Category cat,
                          std::string label,
                          NdmPropertyCollector& vs)
    {
        std::stringstream ss;
        ss << "\n";
        ss << label;
        ss << "\n";
        out_ << ss.str();

        for(int i=0; i<vs.values_.size(); ++i)
        {
            NdmPropertyValue* v = vs.values_[i];

            if(v->pcat_ != cat)
              continue;

            std::stringstream c;
            c << "_ _ ";
            if(v->pcat_ == NdmPropertyType::Approach)
            {
              c << "\"";
              c << v->pvalue_;
              c << "\"\n";
            } else
            {
              c << "\"";
              c << v->ptype_;

              c << "\" \"";
              c << v->pvalue_;
              c << "\"\n";
            } 
            out_ << c.str();
        }

    }

    virtual void handleLeaf(NdmPropertyCollector& vs)
    {

        //- write scenario to file
        std::stringstream ss;
        ss << "SCENARIO ";
        ss << total_scenario_count;
        ss << "\n\n";
        out_ << ss.str();

        //std::cout << "\nLeaf!" << std::endl;
        //return;

        write_properties(NdmPropertyType::Subject,  "SUBJECT",  vs);
        write_properties(NdmPropertyType::Approach, "APPROACH", vs);
        write_properties(NdmPropertyType::Feature,  "FEATURE",  vs);

        out_ << "\n\n";
        out_.flush();

        total_scenario_count++;
    };

private:

    std::vector<NdmNode*> tabu_;

    NdmTreeWalker walker_;

    size_t total_scenario_count;

    bool verbose_;

    size_t cardinality_;





};

#endif