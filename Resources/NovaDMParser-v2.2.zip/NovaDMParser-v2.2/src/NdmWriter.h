// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#ifndef RDMWriter_H_728165476825346732
#define RDMWriter_H_728165476825346732

#include <iostream>
#include <fstream>
#include <iomanip>
#include "NdmReader.h"



class NdmFileWriter
{
public:
    NdmFileWriter(std::string fn):
    dp_(10),
    out_(fn.c_str())
    {}
    
//    ~NdmFileWriter()
//    {
//        close();
//    }
    
    void close() {out_.close();}
    
    virtual void write(ActionValueMapLeafHandler& h) {std::cerr << "(write method not implemented)" << std::endl;};
    virtual void write(NdmReader& r) {std::cerr << "(write method not implemented)" << std::endl;};
    virtual void write(std::string s) { out_ << s; }
    virtual void writespc(std::string s) { out_ << s << " "; }
    virtual void writespc(int s) { out_ << s << " "; }
    virtual void writeDblspc(double s) { out_ << round_to_dp(s) << " "; }
    virtual void nl() { out_ << std::endl; }
    virtual void writeln(std::string s) { out_ << s << std::endl; }
    virtual void writeln(int s) { out_ << s << std::endl; }
    virtual void writeDblln(double s) { out_ << round_to_dp(s) << std::endl; }
    
    virtual void set_double_output(int precision, int dp, bool scientific)
    {
      if(dp < 0)
      {
        std::cerr << "File writer error: trying to set negative decimal precision." << std::endl;
        dp_ = 0;
      } else
      {
         dp_ = dp;
      }
  

      out_ << std::setprecision(precision);
      if(scientific)
        out_ << std::scientific;
      else
        out_ << std::defaultfloat;
    }

    std::string round_to_dp(double x)
    { 
      //char buff[50];
      //sprintf(buff, "%.*g", dp_, x);
      //return atof(buff);


      std::stringstream ss;
      ss << std::defaultfloat;
      ss << std::setprecision(100);
      ss << x;
      std::string str = ss.str();
      std::size_t pos = str.find(".");

      //std::cout << "\nx=" << x << std::endl;
      //std::cout << "ss=" << ss.str() << std::endl;
      //std::cout << "str=" << str << std::endl;
      //std::cout << "pos=" << pos << std::endl;

    
      if(pos != std::string::npos)
      {
        if(dp_ == 0)
          str = str.substr(0, pos);
        else if((dp_ + 1) < (str.length() - pos))
          str = str.substr(0, pos + dp_ + 1);
      }
 
      //std::cout << "final_str=" << str << std::endl;

      return str;

      //double rd = atof(str.c_str());

      
      //std::cout << "final_double=" << rd << std::endl;

      //return rd;
      
    }


    int dp_;

    std::ofstream out_;
};


///////////////////////////////////////
///////////////////////////////////////
///////////////////////////////////////
///////////////////////////////////////


class NdmTreeFileWriter : NdmFileWriter
{
public:
    NdmTreeFileWriter(std::string fn):
    NdmFileWriter(fn),
    indent_(0),
    indent_marker_(" ")
    {}

    virtual void write(NdmReader& r)
    {
        for(int i=0; i<r.trees_.size(); ++i)
        {
            std::cout << "\n%% Tree " << i << ": " << std::endl;
            write(*(r.trees_[i]));
        }
    };

    void write(NdmNode& n)
    {
        indent_ = 0;
        write_(&n);
        out_.flush();
    }

private:
    
    
    void write_(NdmPropertyValue* v)
    {
        std::stringstream c;
        if(v->pcat_ == NdmPropertyType::Subject) c << "subject";
        else if(v->pcat_ == NdmPropertyType::Feature) c << "feature";
        else if(v->pcat_ == NdmPropertyType::Approach) c << "approach";
        else if(v->pcat_ == NdmPropertyType::Criterion) c << "criterion";
        
        if(v->pcat_ == NdmPropertyType::Criterion || v->pcat_ == NdmPropertyType::Approach)
        {
            //            out_ << c.str() << "=" << v->pvalue_;
            out_ << c.str() << ":" << v->pvalue_;
        } else
        {
            out_ << c.str() << ":" << v->ptype_ << "=" << v->pvalue_;
        }
    }
    
    void write_(NdmNode* n)
    {
        std::stringstream ss;
        makeIndent(ss);
        //        out_->operator<<(ss.str().c_str());
        //        out_->operator<<("- ");
        //        out_->operator<<(std::endl);
        
        out_ << ss.str();
        
        //- write node type
        if(n->getType() == NdmNode::Xor) out_ << "- ";
        else if(n->getType() == NdmNode::And) out_ << "+ ";
        else if(n->getType() == NdmNode::Tree) out_ << "* ";
        else out_ << "(unrecognised node type) ";
        
        //- write values
        
        out_ << "[";
        for(int i=0; i<n->valueCount(); ++i)
        {
            if(i>0) out_ << ", ";
            write_(n->value(i));
        }
        
        out_ << "]";
        out_ << std::endl;
        
        //- write children
        
        indent_++;
        for(int i=0; i<n->childrenCount(); ++i)
        {
            write_(n->child(i));
        }
        indent_--;
    }
    
    void makeIndent(std::stringstream& ss)
    {
        for(int i=0; i<indent_; ++i)
        {
            //            ss->operator<<(indent_marker_.c_str());
            ss << indent_marker_;
        }
    }
    
    size_t indent_;
    std::string indent_marker_;
    
    //std::ostream& out_;
    


};

//////////////////////////////
// NdmConsoleWriter

class NdmConsoleWriter
{
public:
    
    NdmConsoleWriter():
    out_(std::cout)
    {
        indent_marker_ = " ";
        indent_ = 0;
        //        out_ = std::cout;
    }
    
    
    virtual void write(NdmReader& r)
    {
        for(int i=0; i<r.trees_.size(); ++i)
        {
            std::cout << "\n%% Tree " << i << ": " << std::endl;
            write(*(r.trees_[i]));
        }
    };

    void write(NdmNode& n)
    {
        indent_ = 0;
        write_(&n);
        out_.flush();
    }
    
    
private:
    
    
    void write_(NdmPropertyValue* v)
    {
        std::stringstream c;
        if(v->pcat_ == NdmPropertyType::Subject) c << "subject";
        else if(v->pcat_ == NdmPropertyType::Feature) c << "feature";
        else if(v->pcat_ == NdmPropertyType::Approach) c << "approach";
        else if(v->pcat_ == NdmPropertyType::Criterion) c << "criterion";
        
        if(v->pcat_ == NdmPropertyType::Criterion || v->pcat_ == NdmPropertyType::Approach)
        {
            //            out_ << c.str() << "=" << v->pvalue_;
            out_ << c.str() << ":" << v->pvalue_;
        } else
        {
            out_ << c.str() << ":" << v->ptype_ << "=" << v->pvalue_;
        }
    }
    
    void write_(NdmNode* n)
    {
        std::stringstream ss;
        makeIndent(ss);
        //        out_->operator<<(ss.str().c_str());
        //        out_->operator<<("- ");
        //        out_->operator<<(std::endl);
        
        out_ << ss.str();
        
        //- write node type
        if(n->getType() == NdmNode::Xor) out_ << "- ";
        else if(n->getType() == NdmNode::And) out_ << "+ ";
        else if(n->getType() == NdmNode::Tree) out_ << "* ";
        else out_ << "(unrecognised node type) ";
        
        //- write values
        
        out_ << "[";
        for(int i=0; i<n->valueCount(); ++i)
        {
            if(i>0) out_ << ", ";
            write_(n->value(i));
        }
        
        out_ << "]";
        out_ << std::endl;
        
        //- write children
        
        indent_++;
        for(int i=0; i<n->childrenCount(); ++i)
        {
            write_(n->child(i));
        }
        indent_--;
    }
    
    void makeIndent(std::stringstream& ss)
    {
        for(int i=0; i<indent_; ++i)
        {
            //            ss->operator<<(indent_marker_.c_str());
            ss << indent_marker_;
        }
    }
    
    size_t indent_;
    std::string indent_marker_;
    
    std::ostream& out_;
    
    
};


#endif