// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}

#ifndef NDM_CONSTRAINTS_H_371756253
#define NDM_CONSTRAINTS_H_371756253

#include <set>

#include "NdmReader.h"

class NdmConstraint
{
public:

/*
  enum
  {
    
  } NdmConstraintComparator;
*/

  NdmConstraint():
  cat_(NdmPropertyType::Undefined),
  type_("undefined_type"),
  value_("undefined_value")
  {}

  void clear()
  {
    cat_ = NdmPropertyType::Undefined;
    type_ = "undefined_type";
    value_ = "undefined_value";
  }

  void set(NdmPropertyType::Category c, std::string t, std::string v)
  {
    cat_ = c;
    type_ = t;
    value_ = v;
  }


  bool applies(NdmNode* n)
  {
  
    for(int i=0; i < n->valueCount(); i++)
    {
      NdmPropertyValue* p = n->value(i);
      if(cat_ == NdmPropertyType::Approach &&
         p->pcat_ == cat_ && p->ptype_.compare(type_) != 0)
      {
        return true;
      } else if(cat_ != NdmPropertyType::Approach && p->pcat_ == cat_ &&
                p->ptype_.compare(type_) == 0 && p->pvalue_.compare(value_) == 0)
      {
        return true;
      } 

    }
  
    return false;
  }

  std::string toString()
  {
    std::stringstream ss;

    ss << type_;

    if(cat_ != NdmPropertyType::Approach)
    {
      ss << " = ";
      ss << value_;
    }

    return ss.str();
  }

private:
  NdmPropertyType::Category cat_;
  std::string type_;
  std::string value_;


};

class NdmConstraintStore
{
public:

  void addAlwaysConstraint(NdmPropertyType::Category c, std::string t, std::string v)
  {
    NdmConstraint* con = fcConstraints_.getFresh();
    con->set(c,t,v);
    always_constraints_.push_back(con);
  }

  void addNeverConstraint(NdmPropertyType::Category c, std::string t, std::string v)
  {
    NdmConstraint* con = fcConstraints_.getFresh();
    con->set(c,t,v);
    never_constraints_.push_back(con);
  }

  void reset()
  {
    always_constraints_.clear();
    never_constraints_.clear();
    fcConstraints_.clear();
  }

  bool alwaysApplies(NdmNode* n)
  {
    return applies(n, always_constraints_);
  }

  bool neverApplies(NdmNode* n)
  {
    return applies(n, never_constraints_);
  }

  std::string toString()
  {
    std::stringstream ss;
    ss << "ALWAYS" << std::endl;
    consToString(ss, always_constraints_);
    ss << "NEVER" << std::endl;
    consToString(ss, never_constraints_);
    return ss.str();
  }

/*
  bool alwaysApplies(NdmNode* n, std::vector<NdmConstraint*>& cons)
  {
    for(int i=0; i < always_constraints.size(); i++)
    {
      NdmConstraint* c = always_constraints[i];
      if(c->applies(n))
       return true;
    }
    return false;
  }
*/

private:

  NdmFactory<NdmConstraint> fcConstraints_;
  std::vector<NdmConstraint*> always_constraints_;
  std::vector<NdmConstraint*> never_constraints_;

  /////

  bool applies(NdmNode* n, std::vector<NdmConstraint*>& cons)
  {
    //std::cout << "Checking applies..." << std::endl;
    //std::cout << "Node: " << n->toString();

    for(int i=0; i < cons.size(); i++)
    {
      NdmConstraint* c = cons[i];
      if(c->applies(n))
       return true;
    }
    return false;
  }

  /////

  void consToString(std::stringstream& ss, std::vector<NdmConstraint*>& cons)
  {
    for(int i=0; i < cons.size(); i++)
    {
      NdmConstraint* c = cons[i];
      ss << c->toString();
      ss << std::endl;
    }
  }


};



//////////////////////////////////////////
//////////////////////////////////////////


class NdmConstraintReader : FileReader
{
public:
  NdmConstraintReader()
  {}

  bool parseConstraints(std::string fn, NdmConstraintStore& store)
  {
    std::ifstream infile;

    if(!FileReader::openFile(fn, infile))
        return false;

     bool parse_error = false;
     size_t line_num = 0;
     std::string line;

     //bool in_always_block = true;
     bool in_never_block = false;

     while (safeGetline(infile, line))
     {
        line_num++;

//        std::cout << "LINE #" << line_num << ":[" << line << "]" << std::endl;
 //       std::cout << "LINE #" << line_num << " (trimmed size " << trim(line).size() <<"):[" << trim(line) << "]" << std::endl;

        line = trim(line);

        if(line.size() == 0)
        {
           continue;
        } else if(line[0] == '%')
        {
           continue; //- comment
        } else if(line.compare("ALWAYS") == 0)
        {
           in_never_block = false;
        } else if(line.compare("NEVER") == 0)
        {
           in_never_block = true;
        } else 
        {
          std::vector<std::string> toks;
          tokenise(line, toks, ":");
        
          //- first token is category
          if(toks.size() != 2)
          {
            parse_fail("Expected <aspect category>:<aspect content>", line_num, line);
            parse_error = true;
            break;
          }

          NdmPropertyType::Category cat = parseCategory(trim(toks[0]));

          std::string aspect = trim(toks[1]);
          toks.clear();

          tokenise(aspect, toks, "=");

          std::string typ = toks[0];
          std::string val = (toks.size() > 1 ? toks[1] : "");

          if(!in_never_block)
          {
            store.addAlwaysConstraint(cat, typ, val);
          } else 
          {
            store.addNeverConstraint(cat, typ, val);
          }
        }
     }

     infile.close();

     if(parse_error)
     {
        store.reset();
        //clear();
        return false;
     }
     return true;

  }
   
private:
    NdmPropertyType::Category parseCategory(std::string s)
    {
        if((s.compare("subject") == 0) || (s.compare("s") == 0))
            return NdmPropertyType::Subject;
        else if((s.compare("feature") == 0) || (s.compare("f") == 0))
            return NdmPropertyType::Feature;
        else if((s.compare("approach") == 0) || (s.compare("a") == 0))
            return NdmPropertyType::Approach;
        else
            return NdmPropertyType::Undefined;
    }

};

//////////////////////////////////////////
//////////////////////////////////////////

class NdmConstraintSolver
{
public:

    NdmConstraintSolver()
    {
      //- test: add some test constraints
      //constraint_store_.addAlwaysConstraint(NdmPropertyType::Feature, "a", "1");
      //constraint_store_.addAlwaysConstraint(NdmPropertyType::Feature, "a", "2");
      //constraint_store_.addNeverConstraint( NdmPropertyType::Feature, "b", "2");
    }
    
    /////
    /////
    
    bool apply(NdmReader& r) //, std::vector<NdmNode*>& con_trees)
    {
      //con_trees.clear();

      green_.clear();
      red_.clear();
      inconsistent_.clear();

      for(int i=0; i<r.trees_.size(); ++i)
      {
        //- colour nodes green/red if always/never apply
        apply(r.trees_[i]);

        //- propagate colours
        propagate(r.trees_[i]);

        //- check for contradictions
        update_inconsistent_set();

        if(inconsistent_.size() > 0)
        {
          return false; //succ = false;
          
        } 

      }

      //- construct new tree
      std::vector<NdmNode*> new_trees;

      bool green_tree = false;

      //- prune red nodes from tree
      for(int i=0; i<r.trees_.size(); ++i)
      {
        NdmNode* n = r.trees_[i];
        if(is_red(n)) //- whole tree will be removed
          continue;

        //NdmNode* m = builder_.recursiveCloneNode(r.trees_[i]);

        recursive_prune_children(n);
        new_trees.push_back(n);
        
        if(is_green(n))
          green_tree = true;
      }


      //- if no tree roots are green, then can just prune existing trees
      r.trees_.clear();

      if(!green_tree || new_trees.size() == 1)
      {
        for(int i=0; i < new_trees.size(); i++)
        {
          //con_trees.push_back(new_trees[i]);
          r.trees_.push_back(new_trees[i]); 
        }
      } else
      {
        //- create single root AND node
        NdmNode* root = builder_.getFreshNode();
        root->setType(NdmNode::And);
        r.trees_.push_back(root);

        for(int i=0; i < new_trees.size(); i++)
        {
          NdmNode* m = new_trees[i];
          if(is_green(m))
          {
            //- if tree is green then add directly as a child
            root->addChild(*m);
          } else
          {
            //- create option that tree is not (necessarily) selected
            //- by constructing intermediate Xor node with empty child node
            NdmNode* t1 = builder_.getFreshNode();
            t1->setType(NdmNode::Xor);
            NdmNode* t2 = builder_.getFreshNode();
            t1->addChild(*m);
            t1->addChild(*t2);
            root->addChild(*t1);
          }
        }
        
      }

      return true;
    }

  

  std::string toString()
  {
    std::stringstream ss;
    ss << "Constraint Store: " << std::endl;
    ss << "===================" << std::endl;
    ss << constraint_store_.toString();
    ss << "===================" << std::endl;

    std::set<NdmNode*>::iterator it;

    ss << "\nGreen Nodes: " << std::endl;
    ss << "===================" << std::endl;
    for (it=green_.begin(); it!=green_.end(); ++it)
    {
      ss << (*it)->toString();
    }
    ss << "===================" << std::endl;

    ss << "\nRed Nodes: " << std::endl;
    ss << "===================" << std::endl;
    for (it=red_.begin(); it!=red_.end(); ++it)
    {
      ss << (*it)->toString();
    }
    ss << "===================" << std::endl;

    ss << "\nInconsistent Nodes: " << std::endl;
    ss << "===================" << std::endl;
    for (it=inconsistent_.begin(); it!=inconsistent_.end(); ++it)
    {
      ss << (*it)->toString();
    }
    ss << "===================" << std::endl;


    return ss.str();
    
  }

  NdmConstraintStore* getConstraintStore() {return &constraint_store_;}

private:
  void apply(NdmNode* n)
  {
    if(constraint_store_.alwaysApplies(n))
      green_.insert(n);

    if(constraint_store_.neverApplies(n))
      red_.insert(n);

    for(int i=0; i < n->childrenCount(); i++)
    {
      apply(n->child(i));
    }
  }

  void propagate(NdmNode* n)
  {
    for(int i=0; i < n->childrenCount(); i++)
    {
      propagate(n->child(i));
    }


    if(n->getType() == NdmNode::Xor)
    {

     //- Rule 2: (xor nodes) If a child if green then
     //-  all other children are coloured red

     for(int i=0; i < n->childrenCount(); i++)
     {
       if(is_green(n->child(i)))
       {
         colour_all_red_except(n,i);
       }     
     }

     //- Rule 3: (xor nodes) If all children are red then
     //-  node is red

     bool all_red = false;

     for(int i=0; i < n->childrenCount(); i++)
     {
       if(is_red(n->child(i)))
       {
         all_red = true; //- at least one must be red...
       }

       if(!is_red(n->child(i)))
       {
         all_red = false; //- if any are NOT red...
         break;
       }     
     }

     if(all_red) red_.insert(n);

   }

    //- Rule 1: If any child is green then node is coloured green
    for(int i=0; i < n->childrenCount(); i++)
    {
      if(is_green(n->child(i)))
      {
        green_.insert(n);
        break;
      }
    }

  }

  void colour_all_red_except(NdmNode* n, int k)
  {
    for(int i=0; i < n->childrenCount(); i++)
    {
      if(i == k) continue;
      red_.insert(n->child(i));
    }
  }

  bool is_green(NdmNode* n)
  {
    return green_.find(n) != green_.end();
  }

  bool is_red(NdmNode* n)
  {
    return red_.find(n) != red_.end();
  }

  void update_inconsistent_set()
  {
    inconsistent_.clear();
    set_intersection(green_.begin(),green_.end(),
                     red_.begin(),  red_.end(),
                     std::inserter(inconsistent_,inconsistent_.begin()));
  }
  ////

  void recursive_prune_children(NdmNode* n)
  {
    for(int i=0; i < n->childrenCount(); i++)
    {
      NdmNode* m = n->child(i);
      if(is_red(m))
      {
        n->removeChild(i);
        i--;
      } else
      {
        recursive_prune_children(m);
      }
    }
  }

  NdmConstraintStore constraint_store_;

  std::set<NdmNode*> green_;
  std::set<NdmNode*> red_;
  std::set<NdmNode*> inconsistent_;

  NdmTreeBuilder builder_;

};

#endif