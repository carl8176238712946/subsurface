// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#ifndef RDM2COVERAGESCENARIOS_H_91823746
#define RDM2COVERAGESCENARIOS_H_91823746

#include "NdmWriter.h"
#include <random>
#include <sstream>


class TabuWalkerListener : public NdmWalkerListener
{
public:
  std::vector<NdmNode*> seen_;

  void clear()
  {
    seen_.clear();
  }

  virtual bool visit_node(NdmNode& n)
  {
    //- only interested in Xor nodes
    if(n.getType() != NdmNode::Xor)
      return true;

    //- check if node has been visited before
    for(int i=0; i < seen_.size(); i++)
    {
      if(seen_[i] == &n)
        return false;
    }
 
    seen_.push_back(&n);
    return true;
  }
}

//////////////////////////////
// PrinterLeafHandler

class ScenarioLeafHandler : public NdmLeafHandler
{
public:
    ScenarioLeafHandler()
    {
        walker_.setLeafHandler(*this);
        walker_.setListener(&listener_);
    }
    
    void parse(NdmNode& n)
    {
        walker_.walk(n);
    }
    
    virtual void handleLeaf(NdmPropertyCollector& vs)
    {

        for(int i=0; i<vs.values_.size(); ++i)
        {
            NdmPropertyValue* v = vs.values_[i];
            
            std::stringstream c;
            if(v->pcat_ == NdmPropertyType::Subject) c << "subject";
            else if(v->pcat_ == NdmPropertyType::Feature) c << "feature";
            else if(v->pcat_ == NdmPropertyType::Approach) c << "approach";
            else if(v->pcat_ == NdmPropertyType::Criterion) c << "criterion";

            if((v->pcat_ == NdmPropertyType::Criterion) || (v->pcat_ == NdmPropertyType::Approach))
            {
                std::cout << "  " << c.str() << ":" << v->pvalue_ << std::endl;
                
            }
            else
            {
                std::cout << "  " << c.str() << ":" << v->ptype_ << "=" << v->pvalue_ << std::endl;
            }
        }
    }

    NdmTreeWalker walker_;
    TabuWalkerListener listener_;
};



class Ndm2CoverageScenarios : public NdmFileWriter
{
public:

    Ndm2CoverageScenarios(std::string fn):
    NdmFileWriter(fn),
    verbose_(false)
    {}
    
    /////
    void set_verbose(bool v) {verbose_ = v;}
    
    virtual void write(NdmReader& r)
    {

      std::cout << "Writing coverage scenario\n" << std::endl;


    };    
    

private:

    size_t total_scenario_count;

    bool verbose_;







};

#endif