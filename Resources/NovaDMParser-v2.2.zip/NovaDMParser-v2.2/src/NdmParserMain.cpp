// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#include "NdmParser.h"
//#include "Ndm2CSV.h"
#include "Ndm2ASP.h"
#include "NdmReader.h"
#include "NdmWriter.h"
#include "AspReader.h"
#include "Asp2CSV.h"
#include "Ndm2RandomScenarios.h"
#include "Ndm2CoverageScenarios.h"
#include "NdmStats.h"
#include "NdmConstraints.h"
#include "NdmKPI.h"
#include "NdmPlot.h"


static int VERSION = 2;
static int VERSION_LOWER = 2;



///


class NdmMainOptions
{
public:
    
    NdmMainOptions()
    {
        write_tree_asp = false;
        write_attr_asp = false;
//        write_csv = false;
        print_to_console = false;
        write = false;
        verbose = false;
        stats = false;
        asp_count_models = false;
        asp_parse_models = false;
        asp_to_csv = false;
        sep_asp_models = false;
        opt_only = false;
        select_random = false;
        select_random_count = 0;
        select_coverage = false;
        select_coverage_cardinality = 0;
        constraints = false;
        last_only = false;
        gen_kpi_min_max = false;
        combine_kpi = false;
        normalise_kpi = false;
        attr_format = false;
        scatterplot = false;

    }
    
    bool isOption(std::string s)
    {
        return
            s.size() > 2
        &&  s[0] == '-'
        &&  s[1] == '-'
        ;
    }
    
    bool parseOption(std::string s)
    {
        if(s.compare("--opt-only") == 0)
        {
            opt_only = true;
            return true;
        }

        if(s.compare("--plot") == 0)
        {
            scatterplot = true;
            return true;
        }

        if(s.compare("--attr-format") == 0)
        {
            attr_format = true;
            return true;
        }

        if(s.compare("--normalise-kpi") == 0)
        {
            normalise_kpi = true;
            return true;
        }

        if(s.compare("--combine-kpi") == 0)
        {
            combine_kpi = true;
            return true;
        }


        if(s.compare("--gen-kpi-min-max") == 0)
        {
            gen_kpi_min_max = true;
            return true;
        }

        if(s.compare("--last-only") == 0)
        {
            last_only = true;
            return true;
        }

        if(s.compare("--tree-asp") == 0)
        {
            write_tree_asp = true;
            write = true;
            return true;
        }
        
        if(s.compare("--attr-asp") == 0)
        {
            write_attr_asp = true;
            write = true;
            return true;
        }

//        if(s.compare("--csv") == 0)
//        {
//            write_csv = true;
//            write = true;
//            return true;
//        }

        if(s.compare("--print") == 0)
        {
            print_to_console = true;
            return true;
        }

        if(s.compare("--verbose") == 0)
        {
            verbose = true;
            return true;
        }

        if(s.compare("--asp-count-models") == 0)
        {
            asp_count_models = true;
            write = true;
            return true;
        }

        if(s.compare("--asp-parse-models") == 0)
        {
            asp_parse_models = true;
            write = true;
            return true;
        }

        if(s.compare("--asp-to-csv") == 0)
        {
            asp_to_csv = true;
            write = true;
            return true;
        }

        if(s.compare("--sep-asp-models") == 0)
        {
            sep_asp_models = true;
            write = true;
            return true;
        }

        if(s.compare("--select-random") == 0)
        {
            select_random = true;
            write = true;
            return true;
        }

        if(s.compare("--select-coverage") == 0)
        {
            select_coverage = true;
            write = true;
            return true;
        }

        
        if(s.compare("--stats") == 0)
        {
            stats = true;
            return true;
        }

        if(s.compare("--constraints") == 0)
        {
            constraints = true;
            write = true;
            return true;
        }


        return false;

    }
    
    bool write;
    bool write_tree_asp;
    bool write_attr_asp;
//    bool write_csv;
    bool print_to_console;
    bool verbose;
    bool asp_count_models;
    bool asp_parse_models;
    bool asp_to_csv;
    bool sep_asp_models;
    bool opt_only;
    bool select_random;
    bool select_coverage;
    bool stats;
    bool constraints;
    bool last_only;
    bool gen_kpi_min_max;
    bool combine_kpi;
    bool normalise_kpi;
    bool attr_format;
    bool scatterplot;

    size_t select_random_count;
    size_t select_coverage_cardinality;

};

void display_usage()
{
    std::cout << std::endl;
    std::cout << "NovaDM Action Tree Parser" << std::endl;
    std::cout << "Version " << VERSION << "." << VERSION_LOWER << std::endl;
    std::cout << std::endl;
    std::cout << "Usage: " << std::endl;
    std::cout << "  novadm <options> <input-file> <output-file>" << std::endl;
    std::cout << std::endl;
    std::cout << "Options: " << std::endl;
    std::cout << " --tree-asp           Generate ASP from NovaDM action tree file." << std::endl;
    std::cout << " --attr-asp           Generate ASP from NovaDM attribute file." << std::endl;
    std::cout << " --attr-format        Output generated scenarios in attribute format." << std::endl;
    std::cout << "                      Use with --select-random." << std::endl;
    std::cout << " --select-random <n> <f>" << std::endl;
    std::cout << "                      Generate n random scenarios from an action tree." << std::endl;
    std::cout << "                      Must provide file <f> with attribute list" << std::endl;
    std::cout << " --select-coverage <n> <f>" << std::endl;
    std::cout << "                      Generate n-ary coverage scenarios from an action" << std::endl;
    std::cout << "                      tree. Must provide file <f> with attribute list" << std::endl;
    std::cout << " --asp-count-models   Count models in ASP output." << std::endl;
    std::cout << " --asp-parse-models   Parse models in ASP output as renovation scenarios." << std::endl;
    std::cout << " --opt-only           Only parse optimal ASP models." << std::endl;
    std::cout << " --last-only          Only parse last ASP model (note: currently only" << std::endl;
    std::cout << "                         supported for --sep-asp-models)." << std::endl;
    std::cout << " --asp-to-csv         Convert ASP output as CSV file." << std::endl;
    std::cout << " --sep-asp-models     Separate ASP models into individual ASP programs." << std::endl;
    std::cout << " --print              Print parsed action tree to the console." << std::endl;
    std::cout << " --verbose            Display debugging messages during parsing." << std::endl;
    std::cout << " --stats              Calculate and print metrics for action trees." << std::endl;
    std::cout << " --combine-kpi        Combine KPI value files (run to see usage)." << std::endl;
    std::cout << " --gen-kpi-min-max    Record min/max KPI values (run to see usage)." << std::endl;
    std::cout << " --normalise-kpi      Normalise KPI values (run to see usage)." << std::endl;
    std::cout << " --plot               Generate scatterplot data files (run to see usage)." << std::endl;
    std::cout << std::endl;
    

}

bool has_only_digits(const std::string s){
  return s.find_first_not_of( "0123456789" ) == std::string::npos;
}

int main(int argc, char* argv[])
{
    
    NdmMainOptions opt;
    
    if(argc == 1)
    {
        display_usage();
        return 0;
    }
    
    //- collect options
    int j=1;
    int i=1;  //- last option TODO this needs refactoring
    for(; j<argc; ++j)
    {
        std::string s(argv[j]);
        if(opt.isOption(s))
        {
            if(!opt.parseOption(s))
            {
                std::cerr << "Unrecognised option '" << s << "'" << std::endl;
                display_usage();
                return 0;
            }
        } else 
        {
          if(i == 1) i = j;
        }

//else {
          //  break;
        //}
        
    }
    
    if(opt.verbose)
    {
        std::cout << "Options: " << argc << std::endl;

    }
    
    //    std::cout << "Index after options: " << i << std::endl;
    

    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////

    if(opt.scatterplot)
    {
      //- novadm --plot <KPI_filename> <Cluster_filename> <Output_Filename>  

      if(argc < 4)
      {
        std::cerr << "Expecting more arguments, usage: " << std::endl;
        std::cerr << "novadm --plot <KPI_filename> <Cluster_filename> <Output_Filename>";
        std::cerr << std::endl;

        return 0;
      }

      std::string kpifn = argv[2];
      std::string clufn = argv[3];
      std::string outfn = argv[4];

      NdmPlot plot;

      plot.setVerbose(opt.verbose);

      if(!plot.parseKPIFile(kpifn))
        return 0;

      plot.parseClustersGnuplot(clufn, outfn);

      return 0;
    }

    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////

    if(opt.gen_kpi_min_max)
    {
      //- expects:
      //- novadm --gen-kpi-min-max <KPI-filename-1> ... <KPI-filename-n> <output-filename>
      if(argc < 4)
      {
        std::cerr << "Expecting more filenames when processing KPI files, example usage: " << std::endl;
        std::cerr << "novadm --gen-kpi-min-max <KPI-filename-1> ... <KPI-filename-n> <output-filename>" << std::endl;

        return 0;
      }

      //- parse files

      NdmKPIDatastore kpi_ds;
      NdmKPIReader r;

      for(int i=2; i < argc - 1; i++)
      {
        r.parseKPI(argv[i], kpi_ds);
      }

      //- create output file
      NdmKPIStats stats;
      stats.setStats(kpi_ds);
      stats.writeToFile(argv[argc - 1], 100, 4);

      //std::cout << kpi_ds.toString();

      return 0;
    }

    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////

    if(opt.combine_kpi)
    {
      //- expects:
      //- novadm --combine-kpi <KPI-filename-1> ... <KPI-filename-n> <output-filename>
      if(argc < 4)
      {
        std::cerr << "Expecting more filenames when processing KPI files, example usage: " << std::endl;
        std::cerr << "novadm --combine-kpi <KPI-filename-1> ... <KPI-filename-n> <output-filename>" << std::endl;

        return 0;
      }

      //- parse files

      NdmKPIDatastore kpi_ds;
      NdmKPIReader r;

      for(int i=2; i < argc - 1; i++)
      {
        r.parseKPI(argv[i], kpi_ds);
      }

      //- create output file
      kpi_ds.writeToFile(argv[argc - 1], 100, 4);

      return 0;
    }


    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////

    if(opt.normalise_kpi)
    {
      //- expects:
      //- novadm --normalise-kpi <norm-lower-bound> <norm-upper-bound> <KPI-min-max> <input-KPI-filename> <output-KPI-filename>
      if(argc != 7)
      {
        std::cerr << "Expected arguments not found, example usage: " << std::endl;
        std::cerr << "novadm --normalise-kpi <norm-lower-bound> <norm-upper-bound> <KPI-min-max> <input-KPI-filename> <output-KPI-filename>" << std::endl;

        return 0;
      }

  
      double lb = std::stod(argv[2]);
      double ub = std::stod(argv[3]);
      //int pr = std::stoi(argv[4]);
      //int dp = std::stoi(argv[5]);
      std::string fn_minmax(argv[4]);
      std::string fn_inkpi(argv[5]);
      std::string fn_outkpi(argv[6]);

      //- parse files

      NdmKPIDatastore kpi_ds;
      NdmKPIStats stats;

      NdmKPIReader r;
      r.parseKPIStats(fn_minmax, stats);
      r.parseKPI(fn_inkpi, kpi_ds);

      stats.normalise(kpi_ds, lb, ub);

      //- create output file
      kpi_ds.writeToFile(fn_outkpi, 100, 4);

      return 0;
    }


    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////

    if(!opt.write && (argc <= i))
    {
        std::cerr << "Expecting <input-filename> after options (please run 'novadm' for usage)." << std::endl;
        return 0;
    }
    


    std::string attr_fn = "";
    std::string con_fn = "";

    if(opt.select_random)
    {
      if(!has_only_digits(argv[i]))
      {
        std::cerr << "Expecting number of random scenarios to generate (positive integer, please run 'novadm' for usage)." << std::endl;
        return 0;
      }
      opt.select_random_count = std::stoi( argv[i] );
      i++;
      attr_fn = argv[i];
      i++;
    }
    
    if(opt.select_coverage)
    {
      if(!has_only_digits(argv[i]))
      {
        std::cerr << "Expecting cardinality of coverage (positive integer >= 1, please run 'novadm' for usage)." << std::endl;
        return 0;
      }
      opt.select_coverage_cardinality = std::stoi( argv[i] );
      i++;
      attr_fn = argv[i];
      i++;
    }

    if(opt.constraints)
    {
      con_fn = argv[i];
      i++;
    }


    if(opt.write && (argc <= i + 1))
    {
        std::cerr << "Expecting <input-filename> <output-filename> after options (please run 'novadm' for usage)." << std::endl;
        return 0;
    }
    
    //- input file
    std::string infile(argv[i]);
    
    //- output file
    std::string outfile(opt.write ? argv[i+1] : "");
    
    
    ///
    if(opt.asp_count_models)
    {
        
        AspReader r;
        bool succ = r.countModels(infile, opt.opt_only);
        
        std::stringstream ss;
        ss << "MODELS ";
        ss << r.model_count_;
        
        NdmFileWriter w(outfile);
        w.writeln(ss.str());
        w.close();

        return 0;
    }

    ///
    if(opt.asp_parse_models)
    {
        
        AspReader r;
        bool succ = r.parseModels(infile, outfile, opt.opt_only);
        
//        std::stringstream ss;
//        ss << "MODELS ";
//        ss << r.model_count_;
        
//        NdmFileWriter w(outfile);
//        w.writeln(ss.str());
//        w.close();
        
        return 0;
    }

    if(opt.asp_to_csv)
    {
        Asp2CSV r;
        bool succ = r.parseModels(infile, outfile, opt.opt_only);
        return 0;
    }
    
    if(opt.sep_asp_models)
    {
        AspReader r;
        bool succ = r.separateModels(infile, outfile, opt.opt_only, opt.last_only);
        return 0;
    }
    

    ///////
    
    if(opt.write_attr_asp)
    {
        std::vector<NdmAttributeAspectValue*> attrs;
        NdmAttributeReader r;
        if(!r.parseAttributes(infile, attrs))
        {
            return 0;
        }
        
        std::stringstream ss;
        ss << outfile;
        ss << ".lp";
        Ndm2ASP w(ss.str());
        w.write(attrs);
        w.close();
        return 0;
    }
    
    ///////
    
    
    if(opt.verbose)
        std::cout << "\nReading file " << infile << "..." << std::endl;
    
    NdmReader r;
    if(!r.readFile(infile))
    {
        return 0;
    }
    if(opt.verbose)
        std::cout << "Done!" << std::endl;
    
    if(opt.print_to_console)
    {
        if(opt.verbose)
            std::cout << "\nPrinting to console..." << std::endl;
        
        NdmConsoleWriter w;
        
        ///

        w.write(r);
        
        //for(int i=0; i<r.trees_.size(); ++i)
        //{
        //    std::cout << "\nTree " << i << ": " << std::endl;
        //    w.write(*(r.trees_[i]));
        //}
    }
    
    ///
    if(opt.write_tree_asp)
    {
        std::stringstream ss;
        ss << outfile;
        ss << ".lp";
//        NdmFileWriter* w = new Ndm2ASP(ss.str());
        Ndm2ASP w(ss.str());
        w.write(r);
        w.close();
    }

    if(opt.select_random)
    {
        NdmAttributeReader ar;
        NdmAttributeMap am;
        ar.parseAttributes(attr_fn, am);

        //std::stringstream ss2;
        //ss2 << outfile;
        //NdmFileWriter w(ss2.str());

        Ndm2RandomScenarios rs;
        rs.set_verbose(opt.verbose);
        rs.set_scenario_count(opt.select_random_count);
        rs.set_attribute_map(&am);
        rs.write(r,outfile,opt.attr_format);
        //rs.close();

        //Ndm2RandomScenarios rs(ss2.str());
        //rs.set_verbose(opt.verbose);
        //rs.set_scenario_count(opt.select_random_count);
        //rs.set_attribute_map(&am);
        //rs.write(r);
        //rs.close();

        std::cout << "Attribute order: " << std::endl;
        am.print_types();
    }

    if(opt.select_coverage)
    {
        NdmAttributeReader ar;
        NdmAttributeMap am;
        ar.parseAttributes(attr_fn, am);

        std::stringstream ss2;
        ss2 << outfile;
        Ndm2CoverageScenarios w(ss2.str());
        w.set_cardinality(opt.select_coverage_cardinality);
        w.set_verbose(opt.verbose);
        w.set_attribute_map(&am);
        w.write(r);
        w.close();

        std::cout << "Attribute order: " << std::endl;
        am.print_types();

    }

    if(opt.stats)
    {
      NdmStats s;
      s.setVerbose(opt.verbose);
      s.stats(r);
    }

    if(opt.constraints)
    {
      
      NdmConstraintSolver s;
      NdmConstraintReader cr;
      bool parse_succ = cr.parseConstraints(con_fn, *(s.getConstraintStore()));

      if(!parse_succ)
        return 0;

      bool succ = s.apply(r);

      if(opt.verbose)
      {
        std::cout << s.toString() << std::endl; 
        NdmTreeFileWriter w(outfile);
        if(succ) w.write(r);
      }
    }

    return 0;
}





//int main(int argc, char* argv[])
//{
//    std::cout << "Options: " << argc << std::endl;
//    
//    NdmMainOptions opt;
//    
//    if(argc == 1)
//    {
//        display_usage();
//        return 0;
//    }
// 
//    //- collect options
//    int i=1;
//    for(; i<argc; ++i)
//    {
//        std::string s(argv[i]);
//        if(opt.isOption(s))
//        {
//            if(!opt.parseOption(s))
//            {
//                std::cerr << "Unrecognised option '" << s << "'" << std::endl;
//                display_usage();
//                return 0;
//            }
//        } else {
//            break;
//        }
//        
//    }
//    
////    std::cout << "Index after options: " << i << std::endl;
//    
//    if(!opt.write && (argc <= i))
//    {
//        std::cerr << "Expecting <input-filename> after options (please run 'rdm-parser' for usage)." << std::endl;
//        return 0;
//    }
//
//    
//    if(opt.write && (argc <= i + 1))
//    {
//        std::cerr << "Expecting <input-filename> <output-filename> after options (please run 'rdm-parser' for usage)." << std::endl;
//        return 0;
//    }
//    
//    //- input file
//    std::string infile(argv[i]);
//
//    //- output file
//    std::string outfile(opt.write ? argv[i+1] : "");
//    
//    
//    ///////
//    
//
//    if(opt.verbose)
//        std::cout << "\nReading file " << infile << "..." << std::endl;
//
//    NdmReader r;
//    if(!r.readFile(infile))
//    {
//        return 0;
//    }
//    if(opt.verbose)
//        std::cout << "Done!" << std::endl;
//
//    if(opt.print_to_console)
//    {
//        if(opt.verbose)
//            std::cout << "\nPrinting to console..." << std::endl;
//
//        NdmWriter w;
//        
//        ///
//        
//        for(int i=0; i<r.trees_.size(); ++i)
//        {
//            std::cout << "\nTree " << i << ": " << std::endl;
//            w.write(*(r.trees_[i]));
//        }
//    }
//    
//    ///
//    
//    if(opt.write || opt.stats)
//    {
//        
//        std::vector<NdmFileWriter*> writers;
//        
//        if(opt.write_asp)
//        {
//            std::stringstream ss;
//            ss << outfile;
//            ss << ".lp";
//            NdmFileWriter* w = new Ndm2ASP(ss.str());
//            writers.push_back(w);
//        }
//
//        
//        if(opt.write_csv)
//        {
//            std::stringstream ss;
//            ss << outfile;
//            ss << ".csv";
//            NdmFileWriter* w = new Ndm2CSV(ss.str());
//            writers.push_back(w);
//        }
//
//        NdmStats stats;
//        
//        size_t tree_cnt = 0;
//        
//        for(int i=0; i<r.trees_.size(); ++i)
//        {
//            if(opt.verbose)
//                std::cout << "\nAction-Value Map Walker for tree " << i << ": " << std::endl;
//            
//            ActionValueMapLeafHandler avm;
////            std::stringstream ss;
////            ss << "r";
////            ss << i;
//            avm.parse(*(r.trees_[i]), tree_cnt);
//            tree_cnt = avm.last_tree_id_ + 1;
//            
//            if(opt.verbose)
//                avm.print();
//            
//            if(opt.stats)
//                stats.updateStats(avm);
//            
//            for(int j=0; j<writers.size(); ++j)
//            {
//                writers[j]->write(avm);
//            }
//            
////            std::cout << "\nWriting ASP ... ";
////            r2asp.write(avm);
////            std::cout << "Done!" << std::endl;
//            
//        }
//        
//        for(int j=0; j<writers.size(); ++j)
//        {
//            writers[j]->close();
//        }
//        
//        if(opt.stats)
//            stats.printStats();
//
//
//    }
//        //r2asp.close();
//    
//    return 0;
//}
//
//
