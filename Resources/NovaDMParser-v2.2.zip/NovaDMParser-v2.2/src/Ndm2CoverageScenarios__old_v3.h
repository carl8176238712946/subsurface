// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#ifndef RDM2COVERAGESCENARIOS_H_91823746
#define RDM2COVERAGESCENARIOS_H_91823746

#include "NdmWriter.h"
#include <random>
#include <sstream>

/*
class CoverageScenarioHandler : public NdmLeafHandler
{
public:
    virtual void handleXor(NdmTreeWalker& w, NdmNode& n)
    {
       std::cout << "Cov node ..." << std::endl;

       print_node(&n);

       //- case: Xor node
       for(int i=0; i<n.childrenCount(); ++i)
       {
          w.walk(*(n.child(i)));
       }
    }

  void print_node(NdmNode* n)
  {
    std::cout << "Node Type: " << n->getType() << std::endl;
    for(int i=0; i < n->valueCount(); i++)
    {
      std::cout << "  PCat: " << n->value(i)->pcat_ << ", PType: " << n->value(i)->ptype_ << ", PValue: " << n->value(i)->pvalue_ << std::endl;
    }
  }

private:

};
*/

class Ndm2CoverageScenarios : public NdmFileWriter
{
public:

    Ndm2CoverageScenarios(std::string fn):
    NdmFileWriter(fn),
    verbose_(false)
    {}
    
    /////
    void set_verbose(bool v) {verbose_ = v;}
    
    virtual void write(NdmReader& r)
    {

      std::cout << "Writing coverage scenario\n" << std::endl;

/*
      CoverageScenarioHandler handler;
      NdmTreeWalker walker;
      walker.setLeafHandler(&handler);

      for(int j=0; j<r.trees_.size(); ++j)
      {
        walker.walk(*(r.trees_[j]));
      }

*/

/*
      for(int i = 0; i < total_scenario_count; i++)
      {
        //std::cout << "SCENARIO " << i << std::endl;

        subjects_.clear();
        features_.clear();
        approaches_.clear();

        for(int j=0; j<r.trees_.size(); ++j)
        {
            int tree_ac = action_count[r.trees_[j]];
            double prob = tree_ac / (tree_ac + 1.0);
            
            if(random_decision(prob))
            {
              //std::cout << "TREE " << j << std::endl;
              walk_(j, r.trees_[j]);
            }
        }

        //std::cout << "Finished walk" << std::endl;

        //- write scenario to file
        std::stringstream ss;
        ss << "SCENARIO ";
        ss << i;
        ss << "\n\n";
        out_ << ss.str();

        write_("SUBJECT",  subjects_);
        write_("APPROACH", approaches_);
        write_("FEATURE",  features_);

        out_ << "\n\n";
        out_.flush();
      }
*/

    };    
    

private:

    //CoverageScenarioHandler handler_;

    std::vector<NdmNode*> subjects_;
    std::vector<NdmNode*> features_;
    std::vector<NdmNode*> approaches_;

    std::random_device rd;
    std::mt19937 gen;

    size_t total_scenario_count;

    bool verbose_;

    std::map<NdmNode*, long> action_count;
    //long total_actions;


    void write_(std::string label, std::vector<NdmNode*>& nodes)
    {
        std::stringstream ss;
        ss << "\n";
        ss << label;
        ss << "\n";
        out_ << ss.str();
     
        for(int i=0; i < nodes.size(); i++)
        {
         NdmNode* n = nodes[i];
         for(int j=0; j < n->valueCount(); j++)
         {
          NdmPropertyValue* v = n->value(j);

          std::stringstream c;
          c << "_ _ ";
          if(v->pcat_ == NdmPropertyType::Approach)
          {
            c << "\"";
            c << v->pvalue_;
            c << "\"\n";
          } else
          {
            c << "\"";
            c << v->ptype_;

            c << "\" \"";
            c << v->pvalue_;
            c << "\"\n";

          } 
          out_ << c.str();
         }
        } 
    }




};

#endif