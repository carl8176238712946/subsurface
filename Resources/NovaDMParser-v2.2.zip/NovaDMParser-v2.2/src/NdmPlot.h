// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}


#ifndef NdmPlot_H_8617235871265
#define NdmPlot_H_8617235871265

//#include "NdmParser.h"

#include "NdmWriter.h"
#include "NdmWriter.h"

///////////////////////////////////

class NdmPlot
{
public:
  NdmPlot():
  verbose_(false)
  {}

  void setVerbose(bool v) {verbose_ = v;}

  bool parseKPIFile(std::string fn)
  {
    if(verbose_)
      std::cout << "Parsing KPI file: " << fn << std::endl;

    std::ifstream infile;
    FileReader r;

    scenario_kpi_values_.clear();

    if(!r.openFile(fn, infile))
    {
      return false;
    }

    std::string line;
    //bool parse_error = false;

    while (r.safeGetline(infile, line))
    {
        line = r.trim(line);

        if(line.size() == 0)
        {
           continue;
        } else if(line[0] == '%')
        {
           continue; //- comment
        } else 
        {
          std::vector<std::string> toks;
          r.tokenise(line, toks, " ");
          if(toks.size() == 1)
          {  //- expecting first line to be the number of KPIs
             continue;
          } else if(toks.size() > 1)
          {
            int sc = r.toInt(toks[0]); //- scenario id
            std::stringstream ss;    //- reassemble remaining KPI vals into a string
            for(int i=1; i < toks.size(); i++)
            {
              ss << toks[i];
              ss << " ";
            }
            scenario_kpi_values_[sc] = ss.str();
          }
        }
    }

    //parse_fail("msg", line_num, line);
    //if(parse_error)
    //{
    //  scenario_kpi_values_.clear();
    //  return false;
    //} else

    if(verbose_)
      print_KPI();

    return true;
  }

  ////////////////////////////////////

  void print_KPI()
  {
    std::cout << "KPI Data:" << std::endl;
    std::map<int, std::string>::iterator it;
    for(it = scenario_kpi_values_.begin(); it != scenario_kpi_values_.end(); ++it)
    {
      std::cout << it->first;
      std::cout << ": ";
      std::cout << it->second << std::endl;
    }
  }

  ////////////////////////////////////

  bool parseClustersGnuplot(std::string infn, std::string outfn)
  {
    if(scenario_kpi_values_.size() == 0)
    {
      std::cerr << "Trying to parse clusters but no KPI values loaded." << std::endl;
      return false;
    }

    std::ifstream infile;
    FileReader r;

    if(!r.openFile(infn, infile))
    {
      return false;
    }

    NdmFileWriter fw(outfn);

    std::string line;
    bool parse_error = false;

    while (r.safeGetline(infile, line))
    {
        line = r.trim(line);

        if(line.size() == 0)
        {
           continue;
        } else if(line[0] == '%')
        {
           continue; //- comment
        } else 
        {
          std::vector<std::string> toks;
          r.tokenise(line, toks, " ");

          if(toks.size() == 2 && toks[0].compare("CLUSTER") == 0)
          { //- new cluster
            fw.writeln(""); //- gnuplot format separates datasets by two empty lines
            fw.writeln("");
            fw.write("##");
            fw.writeln(line);
          } else if(toks.size() == 1)
          { //- scenario ID
            int sc = r.toInt(toks[0]); //- scenario id

            if(scenario_kpi_values_.find(sc) == scenario_kpi_values_.end())
            {
               std::stringstream ss;
               ss << "Failed to find scenario #";
               ss << sc;
               ss << " from parsed KPI file.";
               r.parse_fail(ss.str(), r.getLineNumber(), line);
               parse_error = true;
               break;
            }
            fw.writeln(scenario_kpi_values_[sc]);
          }
        }
    }
    
    
    if(parse_error)
    {
      return false;
    } else

    return true;

  } 

private:

  //- scenario id --> N KPI values (as a string)
  std::map<int, std::string> scenario_kpi_values_;

  bool verbose_;
};




/*
class NdmScatterplot
{
public:
  int x_;
  int y_;
  int width_;
  int height_;
  int margin_;
  int x_marker_length_;
  int y_marker_length_;
  
  NdmScatterplot():
  x_(0),
  y_(0),
  width_(100),
  height_(100),
  margin_(20),
  x_marker_length_(20),
  y_marker_length_(20)
  {}

  void draw(std::string fn)
  {
    std::stringstream fnss;
    fnss << fn;
    fnss << ".svg";
    NdmFileWriter f(fnss.str());

    //- SVG file header
    {
      std::stringstream ss;
      ss << "<svg viewBox=\"";
      ss << (x_ - margin_);
      ss << " ";
      ss << (y_ - margin_);
      ss << " ";
      ss << (width_ + 2*margin_);
      ss << " ";
      ss << (height_ + 2*margin_);
      ss << "\" xmlns=\"http://www.w3.org/2000/svg\">";
      f.writeln(ss.str());
    }
    
    //- font styles
    {
      std::stringstream ss;
      ss << "<style> ";
      ss << ".axis { font: italic 6px serif; fill: black; } ";
      ss << ".axis_numbers { font: 3px serif; fill: black; } </style>";
      ss << " </style>";
      f.writeln(ss.str());
    }

    //- draw axes
    {
      std::stringstream ss;
//      ss << "<line x1=\"0\" y1=\"50\" x2=\"100\" y2=\"50\" stroke=\"black\" stroke-dasharray=\"10 10\" stroke-width=\"0.5\"/>";

        //- horizontal
        ss << "<line x1=\"";
        ss << x_;
        ss << "\" y1=\"";
        ss << (y_ + height_);
        ss << "\" x2=\"";
        ss << (x_ + width_);
        ss << "\" y2=\"";
        ss << (y_ + height_);
        ss << "\" stroke=\"black\" stroke-width=\"0.5\"/>";
        ss << std::endl;

        //- vertical
        ss << "<line x1=\"";
        ss << x_;
        ss << "\" y1=\"";
        ss << (y_ + height_);
        ss << "\" x2=\"";
        ss << x_;
        ss << "\" y2=\"";
        ss << y_;
        ss << "\" stroke=\"black\" stroke-width=\"0.5\"/>";
        ss << std::endl;

        f.writeln(ss.str());
    }

    //- draw marker lines
    {
      std::stringstream ss;

      //- vertical
      for(int i=x_; i <= width_; i += x_marker_length_)
      {
        ss << "<line x1=\"";
        ss << i;
        ss << "\" y1=\"";
        ss << (y_ + height_);
        ss << "\" x2=\"";
        ss << i;
        ss << "\" y2=\"";
        ss << y_;
        ss << "\" stroke=\"grey\" stroke-width=\"0.2\" stroke-dasharray=\"3 2\"/>";
        ss << std::endl;
      }

      //- horizontal
      for(int i=y_; i <= height_; i += y_marker_length_)
      {
        ss << "<line x1=\"";
        ss << x_;
        ss << "\" y1=\"";
        ss << i;
        ss << "\" x2=\"";
        ss << (x_ + width_);
        ss << "\" y2=\"";
        ss << i;
        ss << "\" stroke=\"grey\" stroke-width=\"0.2\" stroke-dasharray=\"3 2\"/>";
        ss << std::endl;
      }

      f.writeln(ss.str());

    }

    f.writeln("<text x=\"20\" y=\"35\" class=\"axis\">My</text>");

    //- SVG file footer
    f.writeln("</svg>");


  }

private:
};

*/

#endif