// {{{ GPL License

// This file is part NovaDM parser v1.0
// Copyright (C) 2018  Carl Schultz
// Copyright (C) 2018  Ali Kamari
// Copyright (C) 2018  Poul Henning Kirkegaard

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// }}}

/*

  Randomly generates scenarios from the scenario space
  based on a given action tree 

*/

#ifndef RDM2RANDOMSELECT_H_46376453
#define RDM2RANDOMSELECT_H_46376453

#include "NdmWriter.h"
#include <random>
#include <sstream>

class Ndm2RandomScenarios : public NdmFileWriter
{
public:

    Ndm2RandomScenarios(std::string fn):
    NdmFileWriter(fn),
    total_scenario_count(0),
    rd(),
    gen(rd()),
    verbose_(false)
    //total_actions(0)
    {}
    
    /////
    void set_verbose(bool v) {verbose_ = v;}
    
    void set_scenario_count(size_t n) {total_scenario_count = n;}

    virtual void write(NdmReader& r)
    {
      /* count actions per tree to assign correct random sampling probabilities */

      //std::vector<long> tree_action_counts;
      //long total_actions = 0;
      long total_actions = 0;
      for(int i=0; i < r.trees_.size(); i++)
      {
        long cnt = calculate_register_action_counts(r.trees_[i]);
        total_actions += cnt;
        //calculate_register_action_counts(r.trees_[i]);
      }

      if(verbose_)
      {
        std::cout << "\nAction tree probabilities:" << std::endl;
        std::cout << "Total actions: " << total_actions << "\n";
        for(int i=0; i < r.trees_.size(); i++)
        {
          recursive_print(r.trees_[i], true, total_actions, 0);
        }

      }

/*
      if(verbose_)
      {
        std::cout << "\nAction tree probabilities:" << std::endl;

        for(int i=0; i < r.trees_.size(); i++)
        {
          double prob = tree_action_counts[i] / ((double)total_actions);
          std::cout << "  Tree #" << i << ": " << tree_action_counts[i] << "\t(" << (prob * 100) << "%)" << std::endl;
        }

        std::cout << "Total action count:" << total_actions << "\n" << std::endl;

      }
*/

      for(int i = 0; i < total_scenario_count; i++)
      {
        //std::cout << "SCENARIO " << i << std::endl;

        subjects_.clear();
        features_.clear();
        approaches_.clear();

        for(int j=0; j<r.trees_.size(); ++j)
        {
            //double prob = tree_action_counts[j] / ((double)total_actions);
            double prob = action_count[r.trees_[j]] / ((double)total_actions);
            
            if(random_decision(prob))
            {
              //std::cout << "TREE " << j << std::endl;
              walk_(j, r.trees_[j]);
            }
        }

        //std::cout << "Finished walk" << std::endl;

        //- write scenario to file
        std::stringstream ss;
        ss << "SCENARIO ";
        ss << i;
        ss << "\n\n";
        out_ << ss.str();

        write_("SUBJECT",  subjects_);
        write_("APPROACH", approaches_);
        write_("FEATURE",  features_);

        out_ << "\n\n";
        out_.flush();
      }
    };    
    

private:

    std::vector<NdmNode*> subjects_;
    std::vector<NdmNode*> features_;
    std::vector<NdmNode*> approaches_;

    std::random_device rd;
    std::mt19937 gen;

    size_t total_scenario_count;

    bool verbose_;

    std::map<NdmNode*, long> action_count;
    //long total_actions;

    /* prob is a value between [0,1] */
    bool random_decision(double prob)
    {
      std::uniform_int_distribution<int> dist(0, 10000);
      return dist(gen) < (prob * 10000);
    }

    /* select 1 from n choices (includes n) */
    long dice_roll(long lower, long upper)
    {
       //assert (lower <= upper);

       std::uniform_int_distribution<int> dist(lower, upper);
       return dist(gen);
    }

    int select_random_child(NdmNode* n)
    {
      //assert (n->childrenCount() > 0);

      long act_cnt = 0; /* accumulate child actions for random selection */
      long act_sel = dice_roll(1, action_count[n]);
      for(int i=0; i < n->childrenCount(); i++)
      {
         act_cnt += action_count[n->child(i)];
         if(act_cnt >= act_sel)
           return i;
      }

      std::cerr << "Error: ran out of children during random selection. Accumulated action count: " << act_cnt << ", total action count at node: " << action_count[n] << ", random select: " << act_sel << std::endl;
      
      return 0;
    }
    
    
    /* recursively count actions from given node */

    long calculate_register_action_counts(NdmNode* n)
    {
      if(n->childrenCount() == 0)
      {
        action_count[n] = 1;
        return 1;
      }

      //std::vector<int> chd_actions;
      long cnt = 0;
      for(int i=0; i < n->childrenCount(); i++)
      {
        long t = calculate_register_action_counts(n->child(i));
        //chd_actions.push_back(t);

        if(i == 0)
          cnt = t;
        else if(n->getType() == NdmNode::Xor)
            cnt += t;
        else if(n->getType() == NdmNode::And)
            cnt *= t;
        else
        {
          std::cerr << "Error: unexpected node type: " << n->getType() << std::endl;
          return 0;
        }
      }
      
      action_count[n] = cnt;
  
      return cnt;
      
    }

    /* randomly walk down tree - note: no ownership of NdmNode */
    void walk_(size_t tree, NdmNode* n)
    {
        //std::cout << "Walking node from tree " << tree << std::endl;

        //std::cout << "Walking node : " << << ", from tree " << tree << std::endl;

        //print_node(n);

        for(int i=0; i<n->valueCount(); ++i)
        {
           NdmPropertyValue* v = n->value(i);

           if(v->pcat_ == NdmPropertyType::Subject)
             subjects_.push_back(n);
           else if(v->pcat_ == NdmPropertyType::Feature)
             features_.push_back(n);
           else if(v->pcat_ == NdmPropertyType::Approach)
             approaches_.push_back(n);
           else if(v->pcat_ == NdmPropertyType::Undefined)
           {} //- do nothing
           else
             std::cerr << "Error: did not recognise node's property value type: " << v->pcat_ << " (tree " << tree << ")" << std::endl;
        }

        if(n->childrenCount() == 0)
        {
          return;
        }
        else if(n->getType() == NdmNode::Xor)
        {
          /* randomly select just one child to walk down */
          //int chd_nd = dice_roll(0, n->childrenCount() - 1);
          int chd_nd = select_random_child(n);
          walk_(tree, n->child(chd_nd));
        }
        else if(n->getType() == NdmNode::And)
        {
          /* continue traversing all children */
          for(int i=0; i<n->childrenCount(); ++i)
          {
            walk_(tree, n->child(i));
          }
        }
        else
        {
           std::cerr << "Error: did not recognise node type: " << n->getType() << " (tree " << tree << ")" << std::endl;

        }
    }

    void write_(std::string label, std::vector<NdmNode*>& nodes)
    {
        std::stringstream ss;
        ss << "\n";
        ss << label;
        ss << "\n";
        out_ << ss.str();
     
        for(int i=0; i < nodes.size(); i++)
        {
         NdmNode* n = nodes[i];
         for(int j=0; j < n->valueCount(); j++)
         {
          NdmPropertyValue* v = n->value(j);

          std::stringstream c;
          c << "_ _ ";
          if(v->pcat_ == NdmPropertyType::Approach)
          {
            c << "\"";
            c << v->pvalue_;
            c << "\"\n";
          } else
          {
            c << "\"";
            c << v->ptype_;

            c << "\" \"";
            c << v->pvalue_;
            c << "\"\n";

          } 
          out_ << c.str();
         }
        } 
    }

  void recursive_print(NdmNode* n, bool xor_parent, long ttl_act_cnt, int depth)
  {
    double pc = 100 * action_count[n] / ((double)ttl_act_cnt);

    std::stringstream ss;
    for(int i=0; i < depth; i++)
      ss << " ";

    std::cout << ss.str();
    
    if(n->getType() == NdmNode::And)
      std::cout << "+ [";
    else if(n->getType() == NdmNode::Xor)
      std::cout << "- [";
    else
      std::cout << "o [";

    for(int j=0; j < n->valueCount(); j++)
    {
      if(j > 0)
      {
        std::cout << ",\n";
        std::cout << ss.str();
        std::cout << "   ";
      }
      NdmPropertyValue* v = n->value(j);
      if(v->pcat_ == NdmPropertyType::Approach)
        std::cout << "approach: ";
      else if(v->pcat_ == NdmPropertyType::Subject)
        std::cout << "subject: ";
      else if(v->pcat_ == NdmPropertyType::Feature)
        std::cout << "feature: ";
      else
        std::cout << ": ";

      if(v->pcat_ == NdmPropertyType::Subject || v->pcat_ == NdmPropertyType::Feature)
        std::cout << v->ptype_ << "=";
      
      std::cout << v->pvalue_;
   
    }

    std::cout << "]";

    std::cout << "\t";
    std::cout << "Actions: " << action_count[n];
    if(xor_parent) std::cout << " (" << pc << "%)";
    std::cout << "\n";

    //std::cout << ss.str();
    std::cout << std::flush;
    
    for(int i=0; i < n->childrenCount(); i++)
      recursive_print(n->child(i), n->getType() == NdmNode::Xor, action_count[n], depth + 1);

  } 

  void print_node(NdmNode* n)
  {
    std::cout << "Node Type: " << n->getType() << std::endl;
    for(int i=0; i < n->valueCount(); i++)
    {
      std::cout << "  PCat: " << n->value(i)->pcat_ << ", PType: " << n->value(i)->ptype_ << ", PValue: " << n->value(i)->pvalue_ << std::endl;
    }
  }

  void quick_ran_test()
  {
        //- quick test to check dice rolls
        std::cout << "\n\nDICE ROLL TEST \n\n" << std::endl;
        std::vector<int> rolls;
        for(int i=0; i < 20; i++) rolls.push_back(0);
        for(int i = 0; i < 10000; i++)
        {
          int rl = dice_roll(0, 10); 
          rolls[rl]++;
        }
        int sum = 0;
        for(int i=0; i < rolls.size(); i++)
        {
          std::cout << "  #" << i << ": " << rolls[i] << std::endl;
          sum += rolls[i];
        }
        std::cout << "TOTAL SUM: " << sum << std::endl;
        ////////
  }
};

#endif