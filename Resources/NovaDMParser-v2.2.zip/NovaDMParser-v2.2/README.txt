

=====
NovaDM Parser version 1.0
Copyright (C) 2018

Carl Schultz, Ali Kamari, Poul Henning Kirkegaard
=====


This is a prototype parser to demonstrate action trees in NovaDM. The
parser is written C++, and should compile with most standard C++ compilers.

E.g. navigate to the "src" folder are run:
g++ NdmParserMain.cpp -o novadm

Please consult the "doc" file for light tutorials on the action tree language.

=====
Examples
=====

To see options run:
./novadm

We provide sample action trees in the folder "tests".

Example: to see some statistics for "tree1.ndm":
./novadm --stats ../tests/tree1.ndm


Example: check how they parser interprets the action tree (useful
         for debugging):
./novadm --print ../tests/tree1.ndm


Example: generate a CSV file with all action information
         (this will create a file "tree1.csv" in the same folder
         as "novadm"):
./novadm --csv ../tests/tree1.ndm tree1


Example: generate a CSV file with all action information, and also
         display some debug information during the parsing process:
./novadm --csv --verbose ../tests/tree1.ndm tree1


Example: generate an ASP file with all action information
         (this will create a file "tree1.lp" in the same folder
         as "novadm"):
./novadm --asp ../tests/tree1.ndm tree1

Example: View stats for the comprehensive Kamari A-Z subject-feature
         knowledge-base:
./novadm --stats ../tests/Kamari_A_Z_Subject_Feature_KB.ndm


Example: Generate CSV file for the Kamari A-Z subject-feature
         knowledge-base:
./novadm --csv ../tests/Kamari_A_Z_Subject_Feature_KB.ndm Kamari_KB





