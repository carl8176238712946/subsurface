

Lambda Prolog QS


To install:

  1) install Ocaml GPC:

    https://github.com/johnwhitington/camlgpc

  2) Ensure OPAM Ocaml package manager is installed

    https://opam.ocaml.org/doc/Install.html

  3) In the Lamda Prolog QS source directory run:

    make

  This creates an executable "elpi" that is extended to support spatial reasoning.

To run:

  ./elpi qs.elpi

For example queries please see the file:

QUERY_EXAMPLES.TXT