Lambda Prolog (QS) is copyrighted 2019 by:
  - Beidi Li (beidi.li@eng.au.dk)
  - Carl Schultz (cschultz@eng.au.dk)
  - Mehul Bhatt (Mehul.Bhatt@oru.se)

Lambda Prolog is implemented using ELPI.

ELPI is copyright 2014-2017 by:
  - Claudio Sacerdoti Coen <sacerdot@cs.unibo.it>
  - Enrico Tassi <Enrico.Tassi@inria.fr>

Patricia trees (elpi_ptmap.ml) is copyright by Jean-Christophe Filliatre.

We thank the following people for their contributions to ELPI:
  - Cvetan Dunchev
  - Ferruccio Guidi
  - Marco Maggesi
